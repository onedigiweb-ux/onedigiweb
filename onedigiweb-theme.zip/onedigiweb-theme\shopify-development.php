﻿<?php
/**
 * Template Name: Shopify Development
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- ============================================================
       MARKETING INTEGRATIONS (Analytics, AdSense, Pinterest, Ads)
  ============================================================ -->
  <!-- Google Tag (gtag.js) - Google Analytics & Google Ads -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-XXXXXXXXXX'); // Replace with Google Analytics Measurement ID
    gtag('config', 'AW-YYYYYYYYY');  // Replace with Google Ads Conversion ID
  </script>
  <!-- Google AdSense -->
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-ZZZZZZZZZZZZZZZZ" crossorigin="anonymous"></script>
  <!-- Pinterest Tag -->
  <script>
    !function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(Array.prototype.slice.call(arguments))};var n=window.pintrk;n.queue=[],n.version="3.0";var t=document.createElement("script");t.async=!0,t.src=e;var r=document.getElementsByTagName("script")[0];r.parentNode.insertBefore(t,r)}}("https://s.pinterest.com/js/pinit.js");
    pintrk('load', 'PARTNER_ID'); // Replace with Pinterest Partner ID
    pintrk('page');
  </script>
  <noscript>
    <img height="1" width="1" style="display:none;" alt="" src="https://ct.pinterest.com/v3/?event=init&tid=PARTNER_ID&noscript=1" />
  </noscript>
  <!-- ============================================================ -->
  
  <meta name="description" content="ONEDIGIWEB offers expert Shopify development in India. Custom Shopify themes, store setup, apps integration, Shopify SEO and Shopify Plus development." />
  <meta name="keywords" content="Shopify Developer India, Shopify Store Setup, Shopify Expert India" />
  <meta name="robots" content="index, follow" />
  <meta name="author" content="ONEDIGIWEB Marketing Solution" />
  <meta name="theme-color" content="#5B21B6" />
  <link rel="canonical" href="https://onedigiweb.com/shopify-development.html" />
  <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" />
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-32x32.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/apple-touch-icon.png" />
  <meta property="og:title" content="Shopify Store Development Services in India | ONEDIGIWEB" />
  <meta property="og:description" content="ONEDIGIWEB offers expert Shopify development in India. Custom Shopify themes, store setup, apps integration, Shopify SEO and Shopify Plus development." />
  <meta property="og:image" content="assets/images/og-image.png" />
  <meta property="og:type" content="website" />
  <meta name="twitter:card" content="summary_large_image" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" />
  <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>" />
  <script type="application/ld+json">
  {"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://onedigiweb.com/"},{"@type":"ListItem","position":2,"name":"Services","item":"https://onedigiweb.com/#services"},{"@type":"ListItem","position":3,"name":"Shopify Development","item":"https://onedigiweb.com/shopify-development.html"}]}
  </script>
  <script type="application/ld+json">
  {"@context":"https://schema.org","@type":"Service","name":"Shopify Development","provider":{"@type":"LocalBusiness","name":"ONEDIGIWEB Marketing Solution","telephone":"+918512821525","email":"onedigiweb@gmail.com"},"description":"ONEDIGIWEB offers expert Shopify development in India. Custom Shopify themes, store setup, apps integration, Shopify SEO and Shopify Plus development.","areaServed":"India"}
  </script>
  <script type="application/ld+json">
  {"@context":"https://schema.org","@type":"FAQPage","mainEntity":[{"@type":"Question","name":"What is Shopify Development?","acceptedAnswer":{"@type":"Answer","text":"Shopify Development helps businesses improve online visibility and reach more customers through targeted digital strategies."}},{"@type":"Question","name":"How much does Shopify Development cost?","acceptedAnswer":{"@type":"Answer","text":"Pricing starts from Rs. 9,999/month. Contact ONEDIGIWEB for a free consultation and custom quote."}}]}
  </script>
  <style>
    .sp-hero{background:linear-gradient(135deg,#0F172A 0%,#1E1035 50%,#0C1340 100%);padding:120px 0 80px;}
    .sp-breadcrumb{display:flex;align-items:center;gap:8px;font-size:13px;color:rgba(255,255,255,0.5);margin-bottom:20px;flex-wrap:wrap;}
    .sp-breadcrumb a{color:rgba(255,255,255,0.5);transition:color .2s;}
    .sp-breadcrumb a:hover{color:var(--accent);}
    .sp-breadcrumb span{color:rgba(255,255,255,0.3);}
    .sp-hero-badge{display:inline-flex;align-items:center;gap:8px;padding:6px 16px;border-radius:50px;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);color:rgba(255,255,255,0.8);font-size:13px;font-weight:500;margin-bottom:20px;}
    .sp-hero-icon{font-size:18px;font-weight:800;color:var(--accent);background:rgba(6,182,212,0.1);padding:8px 16px;border-radius:8px;margin-bottom:16px;display:inline-block;}
    .sp-hero h1{font-family:var(--font);font-size:clamp(28px,5vw,56px);font-weight:900;color:white;line-height:1.15;margin-bottom:16px;letter-spacing:-0.5px;}
    .sp-hero h2{font-size:clamp(15px,2.5vw,21px);color:rgba(255,255,255,0.7);font-weight:500;line-height:1.6;margin-bottom:28px;max-width:640px;}
    .sp-hero-btns{display:flex;gap:12px;flex-wrap:wrap;}
    .sp-services{background:var(--light);padding:80px 0;}
    .sv-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;}
    .sv-item{display:flex;align-items:center;gap:10px;padding:16px 18px;background:white;border:1px solid var(--border);border-radius:12px;font-size:15px;font-weight:500;color:var(--dark);transition:var(--ease);}
    .sv-item:hover{border-color:var(--p2);color:var(--p1);transform:translateY(-3px);box-shadow:var(--sh-card);}
    .sv-item span{color:var(--p2);font-weight:700;}
    .sp-why{background:white;padding:80px 0;}
    .sp-why-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;}
    .sp-why-card{padding:28px;border-radius:var(--r-lg);border:1px solid var(--border);text-align:center;transition:var(--ease);}
    .sp-why-card:hover{border-color:rgba(91,33,182,0.3);box-shadow:var(--sh-hover);transform:translateY(-4px);}
    .sp-why-icon{font-size:36px;margin-bottom:12px;}
    .sp-why-card h3{font-family:var(--font);font-size:17px;font-weight:700;color:var(--dark);margin-bottom:8px;}
    .sp-why-card p{font-size:14px;color:var(--gray);line-height:1.6;}
    .sp-cta-sec{background:var(--g-main);padding:80px 0;text-align:center;}
    .sp-cta-sec h2{font-family:var(--font);font-size:clamp(24px,4vw,42px);font-weight:900;color:white;margin-bottom:12px;}
    .sp-cta-sec p{font-size:18px;color:rgba(255,255,255,0.75);margin-bottom:32px;}
    .sp-cta-btns{display:flex;justify-content:center;gap:14px;flex-wrap:wrap;}
    .btn-white{background:white;color:var(--p1);padding:15px 32px;border-radius:50px;font-family:var(--font);font-size:16px;font-weight:700;transition:var(--ease);display:inline-block;}
    .btn-white:hover{transform:translateY(-3px);box-shadow:0 8px 30px rgba(0,0,0,0.2);}
    .sp-footer-mini{background:var(--dark);padding:30px 0;text-align:center;}
    .sp-footer-mini p{color:rgba(255,255,255,0.75);font-size:13px;}
    .sp-footer-mini a{color:var(--accent);}
    @media(max-width:768px){.sv-grid{grid-template-columns:1fr 1fr;}.sp-why-grid{grid-template-columns:1fr;}.sp-hero-btns{flex-direction:column;}}
    @media(max-width:480px){.sv-grid{grid-template-columns:1fr;}}
  </style>
<?php wp_head(); ?>
</head>
<body>

<!-- COMPONENT: HEADER -->
<header class="header" id="header">
  <nav class="navbar container">

    <!-- Logo -->
    <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="260" height="74" class="logo-img"></a>

    <!-- Nav Menu -->
    <ul class="nav-menu" id="navMenu" role="menubar">
      <li class="nav-item"><a href="#home" class="nav-link active" role="menuitem">Home</a></li>
      <li class="nav-item has-mega">
        <a href="#services" class="nav-link nav-link-arrow" role="menuitem">Services</a>
                        <div class="mega-menu tabbed-mega-menu" role="menu">
          <div class="mega-inner container">
            
            <!-- Top Category Tabs -->
            <div class="tmm-tabs-container">
              <div class="tmm-tabs">
                <button class="tmm-tab active" data-target="tmm-seo"><i class="fa-solid fa-magnifying-glass"></i> SEO Services</button>
                <button class="tmm-tab" data-target="tmm-dm"><i class="fa-solid fa-bullhorn"></i> Digital Marketing</button>
                <button class="tmm-tab" data-target="tmm-web"><i class="fa-solid fa-code"></i> Website Development</button>
                <button class="tmm-tab" data-target="tmm-app"><i class="fa-solid fa-mobile-screen"></i> App Marketing</button>
                <button class="tmm-tab" data-target="tmm-cm"><i class="fa-solid fa-pen-nib"></i> Content Marketing</button>
                <button class="tmm-tab" data-target="tmm-ppc"><i class="fa-solid fa-mouse-pointer"></i> Google Ads / PPC</button>
                <button class="tmm-tab" data-target="tmm-ar"><i class="fa-solid fa-chart-pie"></i> Analytics & Reporting</button>
                <button class="tmm-tab" data-target="tmm-gd"><i class="fa-solid fa-bezier-curve"></i> Graphic Design</button>
                <button class="tmm-tab" data-target="tmm-sd"><i class="fa-solid fa-laptop-code"></i> Software Development</button>
              </div>
            </div>

            <div class="tmm-body">
              <!-- Left side: Services List -->
              <div class="tmm-content-area">
                
                <!-- SEO -->
                <div class="tmm-content active" id="tmm-seo">
                  <div class="tmm-links-grid">
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>SEO Services</span></a>
                    <a href="local-seo-services.html" class="tmm-link"><i class="fa-solid fa-map-location-dot"></i><span>Local SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-gears"></i><span>Technical SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-cart-arrow-down"></i><span>Ecommerce SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Enterprise SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-robot"></i><span>AI SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-stethoscope"></i><span>SEO audit</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-link"></i><span>Link Building</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-triangle-exclamation"></i><span>Google Penalty Recovery</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-truck-fast"></i><span>SEO Migration</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-language"></i><span>Multilingual SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-globe"></i><span>International SEO</span></a>
                  </div>
                </div>

                <!-- Digital Marketing -->
                <div class="tmm-content" id="tmm-dm">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-brands fa-google"></i><span>Google Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-meta"></i><span>Meta Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-youtube"></i><span>YouTube Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-instagram"></i><span>Instagram Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-facebook"></i><span>Facebook Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-linkedin"></i><span>LinkedIn Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope-open-text"></i><span>Email Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-bullhorn"></i><span>Content Marketing</span></a>
                    <a href="lead-generation-services.html" class="tmm-link"><i class="fa-solid fa-magnet"></i><span>Lead Generation</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-shield-halved"></i><span>Online Reputation Management</span></a>
                  </div>
                </div>

                <!-- Website Development -->
                <div class="tmm-content" id="tmm-web">
                  <div class="tmm-links-grid">
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Business Website</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building-user"></i><span>Corporate Website</span></a>
                    <a href="wordpress-development.html" class="tmm-link"><i class="fa-brands fa-wordpress"></i><span>WordPress</span></a>
                    <a href="ecommerce-development.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Ecommerce Website</span></a>
                    <a href="shopify-development.html" class="tmm-link"><i class="fa-brands fa-shopify"></i><span>Shopify</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-react"></i><span>React</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-n"></i><span>Next.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-laravel"></i><span>Laravel</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-php"></i><span>Custom PHP</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-node-js"></i><span>Node.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-screwdriver-wrench"></i><span>Website Maintenance</span></a>
                  </div>
                </div>

                <!-- App Marketing -->
                <div class="tmm-content" id="tmm-app">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>App Store Optimization</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-download"></i><span>App Install Campaigns</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-star"></i><span>App Reviews & Ratings</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-chart-line"></i><span>App Analytics</span></a>
                  </div>
                </div>

                <!-- Content Marketing -->
                <div class="tmm-content" id="tmm-cm">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-pen-fancy"></i><span>Blog Writing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-file-lines"></i><span>Copywriting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-video"></i><span>Video Scripting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope"></i><span>Newsletter Writing</span></a>
                  </div>
                </div>

                <!-- Google Ads / PPC -->
                <div class="tmm-content" id="tmm-ppc">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-dollar"></i><span>Search Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Display Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Shopping Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-rotate-left"></i><span>Remarketing</span></a>
                  </div>
                </div>

                <!-- Analytics & Reporting -->
                <div class="tmm-content" id="tmm-ar">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-pie"></i><span>Google Analytics 4</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-column"></i><span>Custom Dashboards</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-filter"></i><span>Conversion Tracking</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>Data Audits</span></a>
                  </div>
                </div>

                <!-- Graphic Design -->
                <div class="tmm-content" id="tmm-gd">
                  <div class="tmm-links-grid">
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-bezier-curve"></i><span>Logo Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-award"></i><span>Brand Identity</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-object-group"></i><span>UI/UX Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Social Media Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-rectangle-list"></i><span>Banner Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-book-open"></i><span>Brochure Design</span></a>
                  </div>
                </div>

                <!-- Software Development -->
                <div class="tmm-content" id="tmm-sd">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-laptop-code"></i><span>Custom Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-users-gear"></i><span>CRM Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-network-wired"></i><span>ERP Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-android"></i><span>Android App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-apple"></i><span>iOS App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>Flutter App</span></a>
                  </div>
                </div>
              </div>

              <!-- Right Side CTA Card -->
              <div class="tmm-cta">
                <div class="tmm-cta-card">
                  <div class="tmm-cta-title">Grow Your Business with ONEDIGIWEB</div>
                  <div class="tmm-cta-bullets">
                    <span><i class="fa-solid fa-check"></i> Free Consultation</span>
                    <span><i class="fa-solid fa-check"></i> Expert Team</span>
                    <span><i class="fa-solid fa-check"></i> Custom Strategy</span>
                    <span><i class="fa-solid fa-check"></i> Transparent Pricing</span>
                  </div>
                  <div class="tmm-cta-actions">
                    <button class="btn btn-tmm-quote open-quote-trigger" onclick="document.getElementById('quotePopup').style.display='flex'">Get Free Quote</button>
                    <a href="https://wa.me/918512821525" class="btn btn-tmm-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a>
                  </div>
                  <div class="tmm-cta-footer"><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 100+ Projects</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 24x7 Support</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> Fast Delivery</span></div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </li>
      <li class="nav-item"><a href="#pricing" class="nav-link" role="menuitem">Pricing</a></li>
      <li class="nav-item"><a href="#portfolio" class="nav-link" role="menuitem">Portfolio</a></li>
      <li class="nav-item"><a href="#contact" class="nav-link" role="menuitem">Contact</a></li>
    </ul>

    <!-- Nav CTA -->
    <div class="nav-cta">
      <a href="tel:+918512821525" class="nav-cta-call">
        <i class="fa-solid fa-phone"></i> +91 8512821525
      </a>
      <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." target="_blank" class="nav-cta-wa">
        <i class="fa-brands fa-whatsapp"></i> WhatsApp
      </a>
      <button class="nav-cta-quote open-quote-trigger">
        <i class="fa-solid fa-rocket"></i> Free Consultation
      </button>
    </div>

    <!-- Hamburger -->
    <button class="hamburger" id="hamburger" aria-label="Toggle Menu" aria-expanded="false">
      <span class="ham-line"></span>
      <span class="ham-line"></span>
      <span class="ham-line"></span>
    </button>
  </nav>
</header>
<!-- END COMPONENT: HEADER -->

<section class="sp-hero">
  <div class="container">
    <nav class="sp-breadcrumb" aria-label="Breadcrumb"><a href="index.html">Home</a><span>&rsaquo;</span><a href="index.html#services">Services</a><span>&rsaquo;</span><span>Shopify Development</span></nav>
    <div class="sp-hero-icon">[SHOPIFY]</div>
    <div class="sp-hero-badge">Trusted by 250+ Clients &nbsp;&middot;&nbsp; 500+ Projects Done</div>
    <h1>Shopify Store Development Services in India</h1>
    <h2>Launch and Grow Your Shopify Store With Expert Shopify Developers</h2>
    <div class="sp-hero-btns">
      <button class="btn btn-hero-primary" onclick="document.getElementById('quotePopup').style.display='flex'">Get Free Consultation</button>
      <a href="https://wa.me/918512821525" class="btn btn-hero-wa" target="_blank">WhatsApp Now</a>
      <a href="tel:+918512821525" class="btn btn-hero-call">Call Now</a>
    </div>
  </div>
</section>

<section class="sp-services">
  <div class="container">
    <div class="section-header"><div class="section-pill">What's Included</div><h2 class="section-heading">Our <span class="grad-text">Shopify Development</span> Packages</h2><p class="section-sub">Comprehensive solutions to achieve your business goals</p></div>
    <div class="sv-grid">
      <div class="sv-item"><span>&#10003;</span> Shopify Store Setup</div>
      <div class="sv-item"><span>&#10003;</span> Custom Shopify Theme</div>
      <div class="sv-item"><span>&#10003;</span> Shopify App Integration</div>
      <div class="sv-item"><span>&#10003;</span> Shopify SEO</div>
      <div class="sv-item"><span>&#10003;</span> Shopify Speed Optimization</div>
      <div class="sv-item"><span>&#10003;</span> Shopify Migration</div>
      <div class="sv-item"><span>&#10003;</span> Shopify Plus</div>
      <div class="sv-item"><span>&#10003;</span> Dropshipping Setup</div>
    </div>
  </div>
</section>

<section class="sp-why">
  <div class="container">
    <div class="section-header"><div class="section-pill">Why ONEDIGIWEB</div><h2 class="section-heading">Why Choose <span class="grad-text">Our Agency?</span></h2></div>
    <div class="sp-why-grid">
      <div class="sp-why-card"><div class="sp-why-icon">&#127942;</div><h3>5+ Years Experience</h3><p>Expert team with proven track record delivering results across industries.</p></div>
      <div class="sp-why-card"><div class="sp-why-icon">&#128202;</div><h3>Data-Driven Strategy</h3><p>Every decision backed by analytics for maximum ROI and business growth.</p></div>
      <div class="sp-why-card"><div class="sp-why-icon">&#128640;</div><h3>500+ Projects Done</h3><p>Successfully delivered 500+ projects for 250+ happy clients across India.</p></div>
      <div class="sp-why-card"><div class="sp-why-icon">&#128336;</div><h3>24/7 Support</h3><p>Round-the-clock support via WhatsApp, email and phone for all clients.</p></div>
      <div class="sp-why-card"><div class="sp-why-icon">&#128176;</div><h3>Affordable Pricing</h3><p>Premium quality services at competitive prices with transparent billing.</p></div>
      <div class="sp-why-card"><div class="sp-why-icon">&#128200;</div><h3>Proven ROI</h3><p>Our clients see an average 5x return on investment within 6 months.</p></div>
    </div>
  </div>
</section>


<!-- ============================================================
     PORTFOLIO
============================================================ -->
<section class="section portfolio-section" id="portfolio" aria-label="Portfolio">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Portfolio</div>
      <h2 class="section-heading">Our <span class="grad-text">Work &amp; Results</span></h2>
      <p class="section-sub">Real projects, real results - see what we've delivered for our clients</p>
    </div>
    <div class="ptabs" role="tablist">
      <button class="ptab active" data-filter="all" role="tab">All Projects</button>
      <button class="ptab" data-filter="seo" role="tab">SEO</button>
      <button class="ptab" data-filter="web" role="tab">Websites</button>
      <button class="ptab" data-filter="ads" role="tab">Google Ads</button>
      <button class="ptab" data-filter="social" role="tab">Social Media</button>
    </div>
    <div class="port-grid">
      <div class="port-card port-item" data-cat="seo">
        <div class="port-thumb" style="background:linear-gradient(135deg,#5B21B6,#7C3AED)">
          <div class="pt-icon"><i class="fa-solid fa-magnifying-glass-chart" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Dental Clinic SEO</h4><p>300% Traffic Increase in 6 months</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">SEO</div><p>Ranked 15 keywords on Google Page 1, tripled organic traffic</p></div>
      </div>
      <div class="port-card port-item" data-cat="web">
        <div class="port-thumb" style="background:linear-gradient(135deg,#06B6D4,#0891B2)">
          <div class="pt-icon"><i class="fa-solid fa-laptop-code" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Ecommerce Website</h4><p>500+ Products, 2x Conversion Rate</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Website</div><p>Custom WooCommerce store with payment gateway integration</p></div>
      </div>
      <div class="port-card port-item" data-cat="ads">
        <div class="port-thumb" style="background:linear-gradient(135deg,#EA4335,#FBBC04)">
          <div class="pt-icon"><i class="fa-brands fa-google" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Google Ads Campaign</h4><p>Rs.2L Ad Spend = Rs.18L Revenue</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Google Ads</div><p>Real estate campaign with 9x ROAS in 3 months</p></div>
      </div>
      <div class="port-card port-item" data-cat="social">
        <div class="port-thumb" style="background:linear-gradient(135deg,#E1306C,#833AB4)">
          <div class="pt-icon"><i class="fa-brands fa-instagram" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Instagram Growth</h4><p>0 to 50K Followers in 4 months</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Social Media</div><p>Fashion brand Instagram account managed to explosive growth</p></div>
      </div>
      <div class="port-card port-item" data-cat="seo">
        <div class="port-thumb" style="background:linear-gradient(135deg,#10B981,#059669)">
          <div class="pt-icon"><i class="fa-solid fa-location-dot" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Local SEO - Restaurant</h4><p>#1 on Google Maps in 90 Days</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Local SEO</div><p>Restaurant ranked #1 for 8 local keywords, 40% more footfall</p></div>
      </div>
      <div class="port-card port-item" data-cat="web">
        <div class="port-thumb" style="background:linear-gradient(135deg,#F59E0B,#EF4444)">
          <div class="pt-icon"><i class="fa-solid fa-mobile-screen" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Mobile App Development</h4><p>10K+ Downloads in First Month</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">App Dev</div><p>React Native delivery app with real-time tracking and payments</p></div>
      </div>
    </div>
  </div>
</section>

<section class="faq-section section">
  <div class="container">
    <div class="section-header"><div class="section-pill">FAQs</div><h2 class="section-heading">Frequently Asked <span class="grad-text">Questions</span></h2></div>
    <div class="faq-list">
      <div class="faq-item"><button class="faq-q">What is Shopify Development and how does it help my business?<span class="faq-ico">+</span></button><div class="faq-a"><p>Shopify Development helps businesses improve their online presence and reach more customers through targeted digital strategies. ONEDIGIWEB provides expert Shopify Development services customized to your specific business goals and budget.</p></div></div>
      <div class="faq-item"><button class="faq-q">How long does it take to see results from Shopify Development?<span class="faq-ico">+</span></button><div class="faq-a"><p>Results depend on the specific service. Paid ads (Google Ads, Meta Ads) show immediate results, while SEO typically shows significant improvements in 3-6 months. We provide regular reports so you can track progress every step of the way.</p></div></div>
      <div class="faq-item"><button class="faq-q">What is your pricing for Shopify Development?<span class="faq-ico">+</span></button><div class="faq-a"><p>Our Shopify Development packages start from Rs. 9,999/month depending on your requirements and business size. We believe in transparent pricing with no hidden charges. Contact us for a free consultation and custom quote.</p></div></div>
      <div class="faq-item"><button class="faq-q">Do you provide monthly reports?<span class="faq-ico">+</span></button><div class="faq-a"><p>Yes! We provide detailed monthly performance reports with key metrics, rankings, traffic data, and actionable insights. Our team is also available for strategy calls to discuss results and next steps.</p></div></div>
    </div>
  </div>
</section>

<section class="sp-cta-sec">
  <div class="container">
    <h2>Ready to Grow Your Business?</h2>
    <p>Get a FREE consultation with our Shopify Development expert today!</p>
    <div class="sp-cta-btns">
      <button class="btn-white" onclick="document.getElementById('quotePopup').style.display='flex'">Get Free Quote Now</button>
      <a href="https://wa.me/918512821525" class="btn btn-hero-wa" target="_blank">WhatsApp Us</a>
    </div>
  </div>
</section>

<footer class="sp-footer-mini">
  <p>&copy; 2026 <a href="index.html">ONEDIGIWEB Marketing Solution</a>. All Rights Reserved. &nbsp;|&nbsp; <a href="privacy-policy.html">Privacy Policy</a> &nbsp;|&nbsp; <a href="terms-and-conditions.html">Terms &amp; Conditions</a> &nbsp;|&nbsp; <a href="refund-policy.html">Refund Policy</a> &nbsp;|&nbsp; <a href="disclaimer.html">Disclaimer</a> &nbsp;|&nbsp; <a href="about-us.html">About Us</a></p>
</footer>

<div class="popup-overlay quote-popup-overlay" id="quotePopup" style="display:none" role="dialog" aria-modal="true" aria-label="Free Strategy Session Form">
  <div class="nq-popup-box">
    <button class="popup-x" id="closeQuotePopup"><i class="fa-solid fa-xmark"></i></button>
    <div class="nq-header">
      <div class="nq-label">FREE SEO CONSULTATION</div>
      <div class="nq-icon-wrap"><i class="fa-solid fa-chart-column"></i></div>
    </div>
    <h3 class="nq-title">Ready to rank higher?</h3>
    
    <form class="nq-form" id="quoteForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
      <input type="hidden" name="_subject" value="New Lead -  Inquiry | ONEDIGIWEB" />
      <input type="hidden" name="_captcha" value="false" />
      <input type="hidden" name="_template" value="table" />
      <input type="hidden" name="_next" value="https://onedigiweb.com/thank-you.html" />
      <input type="text" name="_honey" style="display:none" />
      <input type="hidden" name="Submission Date & Time" class="sub-date-time-field" value="" />
      
      <div class="nq-field">
        <input type="text" id="qfName" name="Name" placeholder="Name" required />
      </div>
      <div class="nq-field">
        <input type="email" id="qfEmail" name="Email" placeholder="Email" required />
      </div>
      <div class="nq-field">
        <input type="tel" id="qfPhone" name="Mobile Number" placeholder="Phone" required />
      </div>
      <div class="nq-field">
        <input type="url" id="qfWebsite" name="Website" placeholder="Website" />
      </div>
      
      <button type="submit" class="nq-submit" id="qfSubmitBtn">
        Get a Free SEO Consultation <i class="fa-solid fa-arrow-right"></i>
      </button>
      
      <div class="nq-footer-text">No pressure. No generic sales pitch.</div>
    </form>
  </div>
</div>

<!-- Premium Newsletter Popup -->
<div class="popup-overlay" id="newsletterPopup" style="display:none" role="dialog" aria-modal="true" aria-label="Newsletter Subscription">
  <div class="newsletter-popup-box">
    <!-- Left Side -->
    <div class="np-left">
      <div class="qp-brand">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" style="width: 200px; height: auto; max-width: 100%; object-fit: contain;">
      </div>
      <h3>Stay Updated With Digital Marketing Trends</h3>
      <p>Subscribe to receive the latest SEO tips, Google Ads updates, website development insights, exclusive offers and digital marketing news directly in your inbox.</p>
    </div>
    <!-- Right Side -->
    <div class="np-right">
      <div class="np-card" style="position:relative;">
        <button class="qp-close" id="closeNewsletterPopup" style="top:12px; right:12px;"><i class="fa-solid fa-xmark"></i></button>
        <form class="np-form" id="newsletterPopupForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
          <input type="hidden" name="_subject" value="New Subscriber - Premium Newsletter | ONEDIGIWEB" />
          <input type="hidden" name="_captcha" value="false" />
          <input type="hidden" name="_template" value="table" />
          <input type="text" name="_honey" style="display:none" />
          <div class="np-field">
            <label><i class="fa-solid fa-user"></i> Full Name *</label>
            <input type="text" name="Subscriber Name" placeholder="Enter your name" required />
          </div>
          <div class="np-field">
            <label><i class="fa-solid fa-envelope"></i> Email Address *</label>
            <input type="email" name="Subscriber Email" placeholder="your@email.com" required />
          </div>
          <div class="np-field">
            <label><i class="fa-solid fa-phone"></i> Mobile Number (Optional)</label>
            <input type="tel" name="Subscriber Phone" placeholder="Enter mobile number" />
          </div>
          <button type="submit" class="np-submit" style="border:none; width:100%;">Subscribe Now</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Floating Glass FABs (Desktop/Mobile) -->
<div class="glass-fabs" id="glassFabs">
  <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." class="gfab gfab-wa" target="_blank" title="WhatsApp">
    <div class="gfab-pulse"></div>
    <i class="fa-brands fa-whatsapp" style="font-size:22px"></i>
    <span>WhatsApp</span>
  </a>
  <a href="tel:+918512821525" class="gfab gfab-call" title="Call Now">
    <i class="fa-solid fa-phone" style="font-size:18px"></i>
    <span>Call Now</span>
  </a>
  <button class="gfab gfab-top" id="backTop" onclick="window.scrollTo({top:0,behavior:'smooth'})\" title="Back to Top">
    <i class="fa-solid fa-chevron-up" style="font-size:16px"></i>
    <span>Back to Top</span>
  </button>
</div>

<script src="script.js"></script>
<?php wp_footer(); ?>
</body>
</html>


