﻿<?php
/**
 * Template Name: About Us
 */
?>
<?php get_header(); ?>


<section class="policy-hero">
  <div class="container">
    <div class="section-pill">About Us</div>
    <h1>About ONEDIGIWEB</h1>
    <p>Empowering Brands with Data-Driven Digital Marketing Solutions</p>
  </div>
</section>

<section>
  <div class="container policy-content">
    <p>Welcome to <strong>ONEDIGIWEB Marketing Solution</strong>, one of India's fastest-growing digital marketing and website development agencies. We are dedicated to providing cutting-edge solutions designed to help businesses optimize their online presence, attract high-quality leads, and increase sales.</p>

    <h2>Our Mission & Vision</h2>
    <p>At ONEDIGIWEB, our mission is to empower small, medium, and large enterprise businesses with custom-tailored marketing funnels and premium websites. We strive to offer transparent pricing, data-backed results, and persistent innovation to keep your business ahead of the competition in an ever-evolving digital landscape.</p>

    <h2>Why Choose ONEDIGIWEB?</h2>
    <ul>
      <li><strong>Result-Oriented Approach:</strong> We focus on metrics that matterâ€”conversions, leads, and ROIâ€”rather than vanity metrics.</li>
      <li><strong>Dedicated Expert Team:</strong> Our specialists have years of industry experience across SEO, Google Ads, WordPress, and Custom PHP development.</li>
      <li><strong>Transparent Communication:</strong> We provide real-time updates and detailed weekly/monthly reports so you always know your campaign status.</li>
      <li><strong>Custom Strategy:</strong> No two businesses are alike; we craft unique marketing and dev strategies specifically designed for your goals.</li>
    </ul>

    <h2>Our Core Services</h2>
    <p>We provide a comprehensive ecosystem of digital services under one roof:</p>
    <ul>
      <li><strong>Search Engine Optimization (SEO):</strong> Organic growth strategies to rank your brand #1 on Google.</li>
      <li><strong>Paid Advertising (PPC):</strong> Highly optimized Google Ads and Social Media ad campaigns.</li>
      <li><strong>Web Development:</strong> Clean, responsive business websites, WooCommerce stores, and custom software.</li>
      <li><strong>Branding & Design:</strong> Custom logo designs, marketing collateral, and UI/UX design.</li>
    </ul>

    <h2>Contact Our Team</h2>
    <p>Ready to start your digital growth journey? Get in touch with us today:</p>
    <ul>
      <li>Email: <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a></li>
      <li>Phone: <a href="tel:+918512821525">+91 8512821525</a></li>
      <li>Address: Delhi NCR, India</li>
    </ul>
  </div>
</section>


<?php get_footer(); ?>
