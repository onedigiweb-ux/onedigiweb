﻿<!-- COMPONENT: FOOTER -->
<footer class="footer" id="footer" aria-label="Footer">
  <div class="footer-main container">
    <div class="footer-grid">

      <!-- Brand Column -->
      <div class="footer-brand">
        <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="220" height="63" class="logo-img"></a>
        <div class="footer-brand-tagline">Grow &bull; Rank &bull; Convert</div>
        <div class="footer-brand-services">SEO | Digital Marketing | Website Development</div>
        <p>India's trusted digital marketing agency helping businesses grow online with proven, data-driven strategies and dedicated round-the-clock support.</p>
        <div class="footer-brand-contacts">
          <a href="tel:+918512821525" class="fbc-item"><i class="fa-solid fa-phone"></i> +91 8512821525</a>
          <a href="mailto:onedigiweb@gmail.com" class="fbc-item"><i class="fa-solid fa-envelope"></i> onedigiweb@gmail.com</a>
          <a href="https://wa.me/918512821525" class="fbc-item" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp: +91 8512821525</a>
        </div>
        <div class="footer-socials">
          <a href="https://www.facebook.com/onedigiweb" target="_blank" class="fs-link fs-fb" title="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="https://www.instagram.com/onedigiweb" target="_blank" class="fs-link fs-ig" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://www.linkedin.com/company/onedigiweb" target="_blank" class="fs-link fs-li" title="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
          <a href="https://www.youtube.com/@onedigiweb" target="_blank" class="fs-link fs-yt" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
          <a href="https://wa.me/918512821525" target="_blank" class="fs-link fs-wa" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
        </div>
      </div>

      <!-- Quick Links -->
      <div class="footer-col">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="#home"><i class="fa-solid fa-house fa-xs"></i> Home</a></li>
          <li><a href="#services"><i class="fa-solid fa-briefcase fa-xs"></i> Services</a></li>
          <li><a href="#pricing"><i class="fa-solid fa-tags fa-xs"></i> Pricing</a></li>
          <li><a href="#portfolio"><i class="fa-solid fa-images fa-xs"></i> Portfolio</a></li>
          <li><a href="#contact"><i class="fa-solid fa-envelope fa-xs"></i> Contact</a></li>
        </ul>
      </div>

      <!-- Services Links -->
      <div class="footer-col">
        <h4>Our Services</h4>
        <ul>
          <li><a href="seo-services.html"><i class="fa-solid fa-magnifying-glass fa-xs"></i> SEO Services</a></li>
          <li><a href="google-ads-services.html"><i class="fa-brands fa-google fa-xs"></i> Google Ads</a></li>
          <li><a href="social-media-marketing.html"><i class="fa-solid fa-share-nodes fa-xs"></i> Social Media Marketing</a></li>
          <li><a href="website-development.html"><i class="fa-solid fa-laptop-code fa-xs"></i> Website Development</a></li>
          <li><a href="ecommerce-development.html"><i class="fa-solid fa-cart-shopping fa-xs"></i> Ecommerce Development</a></li>
          <li><a href="app-development.html"><i class="fa-solid fa-mobile-screen fa-xs"></i> App Development</a></li>
          <li><a href="graphic-design-services.html"><i class="fa-solid fa-pen-nib fa-xs"></i> Graphic Design</a></li>
          <li><a href="lead-generation-services.html"><i class="fa-solid fa-chart-line fa-xs"></i> Lead Generation</a></li>
        </ul>
      </div>

      <!-- Contact + CTA -->
      <div class="footer-col">
        <h4>Contact Us</h4>
        <ul class="fc-contact">
          <li><a href="mailto:onedigiweb@gmail.com"><i class="fa-solid fa-envelope"></i> onedigiweb@gmail.com</a></li>
          <li><a href="tel:+918512821525"><i class="fa-solid fa-phone"></i> +91 8512821525</a></li>
          <li><a href="https://wa.me/918512821525" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a></li>
          <li><span><i class="fa-solid fa-clock"></i> Mon&ndash;Sat: 9AM&ndash;7PM</span></li>
        </ul>
        <button onclick="document.getElementById('quotePopup').style.display='flex'" class="footer-cta">
          <i class="fa-solid fa-rocket"></i> Get Free Quote
        </button>
      </div>
    </div>
  </div>

  <!-- Footer Bottom -->
  <div class="footer-bottom">
    <div class="container footer-bottom-inner">
      <p>&copy; 2026 ONEDIGIWEB Marketing Solution. All Rights Reserved.</p>
      <div class="footer-policy-links">
        <a href="privacy-policy.html">Privacy Policy</a>
        <span>&bull;</span>
        <a href="terms-and-conditions.html">Terms &amp; Conditions</a>
        <span>&bull;</span>
        <a href="refund-policy.html">Refund Policy</a>
        <span>&bull;</span>
        <a href="disclaimer.html">Disclaimer</a>
        <span>&bull;</span>
        <a href="about-us.html">About Us</a>
      </div>
    </div>
  </div>
</footer>

<!-- END COMPONENT: FOOTER -->

<!-- ============================================================
     FLOATING GLASS FABs (Desktop)
============================================================ -->
<!-- COMPONENT: POPUPS -->
<!-- Floating Glass FABs (Desktop/Mobile) -->
<div class="glass-fabs" id="glassFabs">
  <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." class="gfab gfab-wa" target="_blank" title="WhatsApp">
    <div class="gfab-pulse"></div>
    <i class="fa-brands fa-whatsapp" style="font-size:22px"></i>
    <span>WhatsApp</span>
  </a>
  <a href="tel:+918512821525" class="gfab gfab-call" title="Call Now">
    <i class="fa-solid fa-phone" style="font-size:18px"></i>
    <span>Call Now</span>
  </a>
  <button class="gfab gfab-top" id="backTop" onclick="window.scrollTo({top:0,behavior:'smooth'})" title="Back to Top">
    <i class="fa-solid fa-chevron-up" style="font-size:16px"></i>
    <span>Back to Top</span>
  </button>
</div>

<!-- Mobile Sticky Bar -->
<div class="mobile-sticky-bar" id="mobileStickyBar">
  <a href="tel:+918512821525" class="msb-btn msb-call"><i class="fa-solid fa-phone"></i> Call Now</a>
  <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." class="msb-btn msb-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
  <button class="msb-btn msb-quote open-quote-trigger"><i class="fa-solid fa-file-invoice"></i> Get Quote</button>
</div>

<!-- Free Strategy Session Popup -->
<div class="popup-overlay quote-popup-overlay" id="quotePopup" style="display:none" role="dialog" aria-modal="true" aria-label="Free Strategy Session Form">
  <div class="nq-popup-box">
    <button class="popup-x" id="closeQuotePopup"><i class="fa-solid fa-xmark"></i></button>
    <div class="nq-header">
      <div class="nq-label">FREE SEO CONSULTATION</div>
      <div class="nq-icon-wrap"><i class="fa-solid fa-chart-column"></i></div>
    </div>
    <h3 class="nq-title">Ready to rank higher?</h3>
    
    <form class="nq-form" id="quoteForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
      <input type="hidden" name="_subject" value="New Lead - FREE SEO Consultation Request" />
      <input type="hidden" name="_captcha" value="false" />
      <input type="hidden" name="_template" value="table" />
      <input type="hidden" name="_next" value="https://onedigiweb.com/thank-you.html" />
      <input type="text" name="_honey" style="display:none" />
      <input type="hidden" name="Submission Date & Time" class="sub-date-time-field" value="" />
      
      <div class="nq-field">
        <input type="text" id="qfName" name="Name" placeholder="Name" required />
      </div>
      <div class="nq-field">
        <input type="email" id="qfEmail" name="Email" placeholder="Email" required />
      </div>
      <div class="nq-field">
        <input type="tel" id="qfPhone" name="Mobile Number" placeholder="Phone" required />
      </div>
      <div class="nq-field">
        <input type="url" id="qfWebsite" name="Website" placeholder="Website" />
      </div>
      
      <button type="submit" class="nq-submit" id="qfSubmitBtn">
        Get a Free SEO Consultation <i class="fa-solid fa-arrow-right"></i>
      </button>
      
      <div class="nq-footer-text">No pressure. No generic sales pitch.</div>
    </form>
  </div>
</div>

<!-- Success / Thank You Popup -->
<div class="popup-overlay" id="thankYouPopup" style="display:none">
  <div class="popup-box ty-popup-box" style="max-width:500px;">
    <button class="popup-x" onclick="document.getElementById('thankYouPopup').style.display='none';document.body.style.overflow=''"><i class="fa-solid fa-xmark"></i></button>
    <div class="ty-animation">
      <div class="ty-circle"><i class="fa-solid fa-check" style="font-size:36px;color:white"></i></div>
    </div>
    <h3>&#127881; Thank You!</h3>
    <p>Your request has been submitted successfully.<br>Our team will contact you shortly on your phone number or email.</p>
    <div class="ty-info">
      <div class="ty-info-item"><i class="fa-solid fa-phone" style="color:var(--accent)"></i><span>+91 8512821525</span></div>
      <div class="ty-info-item"><i class="fa-solid fa-envelope" style="color:var(--accent)"></i><span>onedigiweb@gmail.com</span></div>
      <div class="ty-info-item"><i class="fa-solid fa-clock" style="color:var(--accent)"></i><span>Response within 24 hours</span></div>
    </div>
    <div class="wpb-btns">
      <a href="https://wa.me/918512821525?text=Hi! I just claimed my free digital strategy session on ONEDIGIWEB." class="btn btn-hero-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp</a>
      <button onclick="document.getElementById('thankYouPopup').style.display='none';document.body.style.overflow=''" class="btn btn-hero-call">Close Window</button>
    </div>
  </div>
</div>

<!-- Premium Newsletter Popup -->
<div class="popup-overlay" id="newsletterPopup" style="display:none" role="dialog" aria-modal="true" aria-label="Newsletter Subscription">
  <div class="newsletter-popup-box">
    <!-- Left Side -->
    <div class="np-left">
      <div class="qp-brand">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" style="width: 200px; height: auto; max-width: 100%; object-fit: contain;">
      </div>
      <h3>Stay Updated With Digital Marketing Trends</h3>
      <p>Subscribe to receive the latest SEO tips, Google Ads updates, website development insights, exclusive offers and digital marketing news directly in your inbox.</p>
    </div>
    <!-- Right Side -->
    <div class="np-right">
      <div class="np-card" style="position:relative;">
        <button class="qp-close" id="closeNewsletterPopup" style="top:12px; right:12px;"><i class="fa-solid fa-xmark"></i></button>
        <form class="np-form" id="newsletterPopupForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
          <input type="hidden" name="_subject" value="New Subscriber - Premium Newsletter | ONEDIGIWEB" />
          <input type="hidden" name="_captcha" value="false" />
          <input type="hidden" name="_template" value="table" />
          <input type="text" name="_honey" style="display:none" />
          
          <div class="np-field">
            <label><i class="fa-solid fa-user"></i> Full Name *</label>
            <input type="text" name="Subscriber Name" placeholder="Enter your name" required />
          </div>
          <div class="np-field">
            <label><i class="fa-solid fa-envelope"></i> Email Address *</label>
            <input type="email" name="Subscriber Email" placeholder="your@email.com" required />
          </div>
          <div class="np-field">
            <label><i class="fa-solid fa-phone"></i> Mobile Number (Optional)</label>
            <input type="tel" name="Subscriber Phone" placeholder="Enter mobile number" />
          </div>
          <button type="submit" class="np-submit" style="border:none; width: 100%;">Subscribe Now</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="script.js"></script>
<?php wp_footer(); ?>
</body>
</html>












