﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
  <meta name="description" content="The page you are looking for does not exist. Back to ONEDIGIWEB Marketing Solution." />
  <meta name="robots" content="noindex, nofollow" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
  <style>
    body {
      background: var(--dark);
      color: white;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      font-family: var(--font-body);
      padding: 24px;
    }
    .error-container {
      max-width: 600px;
    }
    .error-code {
      font-family: var(--font);
      font-size: clamp(80px, 15vw, 150px);
      font-weight: 900;
      line-height: 1;
      background: var(--g-wide);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 20px;
      animation: pulse 2s infinite;
    }
    h1 {
      font-family: var(--font);
      font-size: clamp(24px, 4vw, 36px);
      font-weight: 800;
      margin-bottom: 16px;
    }
    p {
      color: rgba(255,255,255,0.7);
      font-size: 16px;
      line-height: 1.6;
      margin-bottom: 32px;
    }
    .btn-wrap {
      display: flex;
      gap: 16px;
      justify-content: center;
      flex-wrap: wrap;
    }
    @keyframes pulse {
      0%, 100% { transform: scale(1); opacity: 1; }
      50% { transform: scale(1.05); opacity: 0.8; }
    }
  </style>
  <!-- Favicons -->
  <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" />
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-32x32.png" />
  <link rel="icon" type="image/png" sizes="48x48" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-48x48.png" />
  <link rel="icon" type="image/png" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-180x180.png" />
  <link rel="icon" type="image/png" sizes="512x512" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-512x512.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/apple-touch-icon.png" />
  <link rel="manifest" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/site.webmanifest" />
<?php wp_head(); ?>
</head>
<body>
  <div class="error-container">
    <div class="error-code">404</div>
    <h1>Oops! Page Not Found</h1>
    <p>The page you are looking for might have been removed, had its name changed, or is temporarily unavailable. Let's get you back on track!</p>
    <div class="btn-wrap">
      <a href="index.html" class="btn btn-hero-primary" style="border-radius:50px;">&larr; Back to Home</a>
      <a href="tel:+918512821525" class="btn btn-hero-call" style="border-radius:50px;"><i class="fa-solid fa-phone"></i> Call Us Now</a>
    </div>
  </div>
<?php wp_footer(); ?>
</body>
</html>









