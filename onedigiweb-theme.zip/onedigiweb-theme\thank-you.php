﻿<?php
/**
 * Template Name: Thank You
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
  <meta name="description" content="Thank you for getting in touch with ONEDIGIWEB Marketing Solution. We have received your inquiry and will contact you shortly." />
  <meta name="robots" content="noindex, nofollow" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
  <style>
    body {
      background: var(--dark);
      color: white;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      font-family: var(--font-body);
      padding: 24px;
    }
    .thankyou-container {
      max-width: 600px;
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: var(--r-xl);
      padding: 50px 36px;
      backdrop-filter: blur(20px);
      box-shadow: 0 30px 100px rgba(0,0,0,0.5);
    }
    .success-icon {
      width: 90px;
      height: 90px;
      border-radius: 50%;
      background: linear-gradient(135deg, #10B981, #059669);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 30px rgba(16,185,129,0.4);
      font-size: 40px;
      margin-bottom: 24px;
      animation: popSuccess 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }
    h1 {
      font-family: var(--font);
      font-size: clamp(28px, 5vw, 42px);
      font-weight: 900;
      margin-bottom: 12px;
    }
    p {
      color: rgba(255,255,255,0.8);
      font-size: 16px;
      line-height: 1.6;
      margin-bottom: 30px;
    }
    .info-list {
      display: flex;
      flex-direction: column;
      gap: 12px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: var(--r);
      padding: 20px;
      text-align: left;
      margin-bottom: 30px;
    }
    .info-item {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 15px;
    }
    .info-item i {
      color: var(--accent);
      width: 20px;
    }
    .btn-wrap {
      display: flex;
      gap: 16px;
      justify-content: center;
      flex-wrap: wrap;
    }
    @keyframes popSuccess {
      0% { transform: scale(0); }
      70% { transform: scale(1.15); }
      100% { transform: scale(1); }
    }
  </style>
  <!-- Favicons -->
  <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" />
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-32x32.png" />
  <link rel="icon" type="image/png" sizes="48x48" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-48x48.png" />
  <link rel="icon" type="image/png" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-180x180.png" />
  <link rel="icon" type="image/png" sizes="512x512" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-512x512.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/apple-touch-icon.png" />
  <link rel="manifest" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/site.webmanifest" />
<?php wp_head(); ?>
</head>
<body>
  <div class="thankyou-container">
    <div class="success-icon"><i class="fa-solid fa-check"></i></div>
    <h1>&#127881; Submission Successful!</h1>
    <p>Thank you for getting in touch. We have received your details and our growth experts will review them. You will hear from us shortly.</p>
    
    <div class="info-list">
      <div class="info-item">
        <i class="fa-solid fa-phone"></i>
        <span><strong>Phone:</strong> +91 8512821525</span>
      </div>
      <div class="info-item">
        <i class="fa-solid fa-envelope"></i>
        <span><strong>Email:</strong> onedigiweb@gmail.com</span>
      </div>
      <div class="info-item">
        <i class="fa-solid fa-clock"></i>
        <span><strong>Response Time:</strong> Within 24 Business Hours</span>
      </div>
    </div>

    <div class="btn-wrap">
      <a href="index.html" class="btn btn-hero-primary" style="border-radius:50px;">&larr; Back to Home</a>
      <a href="https://wa.me/918512821525?text=Hi! I just submitted an inquiry on your website." class="btn btn-hero-wa" target="_blank" style="border-radius:50px;"><i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp</a>
    </div>
  </div>
<?php wp_footer(); ?>
</body>










