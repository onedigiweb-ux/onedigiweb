﻿<?php
// Fallback template
wp_redirect(home_url());
exit;
?>
