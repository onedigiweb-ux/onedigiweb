﻿<?php
/**
 * Template Name: About Us
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- ============================================================
       MARKETING INTEGRATIONS (Analytics, AdSense, Pinterest, Ads)
  ============================================================ -->
  <!-- Google Tag (gtag.js) - Google Analytics & Google Ads -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-XXXXXXXXXX'); // Replace with Google Analytics Measurement ID
    gtag('config', 'AW-YYYYYYYYY');  // Replace with Google Ads Conversion ID
  </script>

  <!-- Google AdSense -->
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-ZZZZZZZZZZZZZZZZ" crossorigin="anonymous"></script>

  <!-- Pinterest Tag -->
  <script>
    !function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(Array.prototype.slice.call(arguments))};var n=window.pintrk;n.queue=[],n.version="3.0";var t=document.createElement("script");t.async=!0,t.src=e;var r=document.getElementsByTagName("script")[0];r.parentNode.insertBefore(t,r)}}("https://s.pinterest.com/js/pinit.js");
    pintrk('load', 'PARTNER_ID'); // Replace with Pinterest Partner ID
    pintrk('page');
  </script>
  <noscript>
    <img height="1" width="1" style="display:none;" alt="" src="https://ct.pinterest.com/v3/?event=init&tid=PARTNER_ID&noscript=1" />
  </noscript>
  <!-- ============================================================ -->
  
  <meta name="description" content="Learn more about ONEDIGIWEB, India's leading digital marketing agency. Our mission, values, and expert team helping businesses grow online." />
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="https://onedigiweb.com/about-us.html" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" />
  <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>" />
  <style>
    .policy-hero { background: var(--dark); padding: 20px 0 60px; }
    .policy-hero h1 { font-family: var(--font); font-size: clamp(28px,4vw,46px); font-weight: 900; color: white; margin-bottom: 12px; }
    .policy-hero p { color: rgba(255,255,255,0.6); font-size: 16px; }
    .policy-content { padding: 70px 0; max-width: 860px; margin: 0 auto; }
    .policy-content h2 { font-family: var(--font); font-size: 22px; font-weight: 800; color: var(--dark); margin: 36px 0 12px; padding-left: 16px; border-left: 4px solid var(--p2); }
    .policy-content p { font-size: 16px; color: var(--gray); line-height: 1.8; margin-bottom: 14px; }
    .policy-content ul { padding-left: 24px; margin-bottom: 14px; }
    .policy-content ul li { font-size: 15px; color: var(--gray); line-height: 1.75; margin-bottom: 6px; }
    .policy-content a { color: var(--p1); }
    .policy-footer { background: var(--dark); padding: 28px 0; text-align: center; }
    .policy-footer p { color: rgba(255,255,255,0.75); font-size: 13px; }
    .policy-footer a { color: var(--accent); }
  </style>
  <!-- Favicons -->
  <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" />
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-32x32.png" />
  <link rel="icon" type="image/png" sizes="48x48" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-48x48.png" />
  <link rel="icon" type="image/png" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-180x180.png" />
  <link rel="icon" type="image/png" sizes="512x512" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-512x512.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/apple-touch-icon.png" />
  <link rel="manifest" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/site.webmanifest" />
<?php wp_head(); ?>
</head>
<body>
<!-- COMPONENT: HEADER -->
<header class="header" id="header">
  <nav class="navbar container">

    <!-- Logo -->
    <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="260" height="74" class="logo-img"></a>

    <!-- Nav Menu -->
    <ul class="nav-menu" id="navMenu" role="menubar">
      <li class="nav-item"><a href="#home" class="nav-link active" role="menuitem">Home</a></li>
      <li class="nav-item has-mega">
        <a href="#services" class="nav-link nav-link-arrow" role="menuitem">Services</a>
                        <div class="mega-menu tabbed-mega-menu" role="menu">
          <div class="mega-inner container">
            
            <!-- Top Category Tabs -->
            <div class="tmm-tabs-container">
              <div class="tmm-tabs">
                <button class="tmm-tab active" data-target="tmm-seo"><i class="fa-solid fa-magnifying-glass"></i> SEO Services</button>
                <button class="tmm-tab" data-target="tmm-dm"><i class="fa-solid fa-bullhorn"></i> Digital Marketing</button>
                <button class="tmm-tab" data-target="tmm-web"><i class="fa-solid fa-code"></i> Website Development</button>
                <button class="tmm-tab" data-target="tmm-app"><i class="fa-solid fa-mobile-screen"></i> App Marketing</button>
                <button class="tmm-tab" data-target="tmm-cm"><i class="fa-solid fa-pen-nib"></i> Content Marketing</button>
                <button class="tmm-tab" data-target="tmm-ppc"><i class="fa-solid fa-mouse-pointer"></i> Google Ads / PPC</button>
                <button class="tmm-tab" data-target="tmm-ar"><i class="fa-solid fa-chart-pie"></i> Analytics & Reporting</button>
                <button class="tmm-tab" data-target="tmm-gd"><i class="fa-solid fa-bezier-curve"></i> Graphic Design</button>
                <button class="tmm-tab" data-target="tmm-sd"><i class="fa-solid fa-laptop-code"></i> Software Development</button>
              </div>
            </div>

            <div class="tmm-body">
              <!-- Left side: Services List -->
              <div class="tmm-content-area">
                
                <!-- SEO -->
                <div class="tmm-content active" id="tmm-seo">
                  <div class="tmm-links-grid">
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>SEO Services</span></a>
                    <a href="local-seo-services.html" class="tmm-link"><i class="fa-solid fa-map-location-dot"></i><span>Local SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-gears"></i><span>Technical SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-cart-arrow-down"></i><span>Ecommerce SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Enterprise SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-robot"></i><span>AI SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-stethoscope"></i><span>SEO audit</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-link"></i><span>Link Building</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-triangle-exclamation"></i><span>Google Penalty Recovery</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-truck-fast"></i><span>SEO Migration</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-language"></i><span>Multilingual SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-globe"></i><span>International SEO</span></a>
                  </div>
                </div>

                <!-- Digital Marketing -->
                <div class="tmm-content" id="tmm-dm">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-brands fa-google"></i><span>Google Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-meta"></i><span>Meta Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-youtube"></i><span>YouTube Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-instagram"></i><span>Instagram Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-facebook"></i><span>Facebook Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-linkedin"></i><span>LinkedIn Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope-open-text"></i><span>Email Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-bullhorn"></i><span>Content Marketing</span></a>
                    <a href="lead-generation-services.html" class="tmm-link"><i class="fa-solid fa-magnet"></i><span>Lead Generation</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-shield-halved"></i><span>Online Reputation Management</span></a>
                  </div>
                </div>

                <!-- Website Development -->
                <div class="tmm-content" id="tmm-web">
                  <div class="tmm-links-grid">
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Business Website</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building-user"></i><span>Corporate Website</span></a>
                    <a href="wordpress-development.html" class="tmm-link"><i class="fa-brands fa-wordpress"></i><span>WordPress</span></a>
                    <a href="ecommerce-development.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Ecommerce Website</span></a>
                    <a href="shopify-development.html" class="tmm-link"><i class="fa-brands fa-shopify"></i><span>Shopify</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-react"></i><span>React</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-n"></i><span>Next.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-laravel"></i><span>Laravel</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-php"></i><span>Custom PHP</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-node-js"></i><span>Node.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-screwdriver-wrench"></i><span>Website Maintenance</span></a>
                  </div>
                </div>

                <!-- App Marketing -->
                <div class="tmm-content" id="tmm-app">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>App Store Optimization</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-download"></i><span>App Install Campaigns</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-star"></i><span>App Reviews & Ratings</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-chart-line"></i><span>App Analytics</span></a>
                  </div>
                </div>

                <!-- Content Marketing -->
                <div class="tmm-content" id="tmm-cm">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-pen-fancy"></i><span>Blog Writing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-file-lines"></i><span>Copywriting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-video"></i><span>Video Scripting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope"></i><span>Newsletter Writing</span></a>
                  </div>
                </div>

                <!-- Google Ads / PPC -->
                <div class="tmm-content" id="tmm-ppc">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-dollar"></i><span>Search Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Display Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Shopping Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-rotate-left"></i><span>Remarketing</span></a>
                  </div>
                </div>

                <!-- Analytics & Reporting -->
                <div class="tmm-content" id="tmm-ar">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-pie"></i><span>Google Analytics 4</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-column"></i><span>Custom Dashboards</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-filter"></i><span>Conversion Tracking</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>Data Audits</span></a>
                  </div>
                </div>

                <!-- Graphic Design -->
                <div class="tmm-content" id="tmm-gd">
                  <div class="tmm-links-grid">
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-bezier-curve"></i><span>Logo Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-award"></i><span>Brand Identity</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-object-group"></i><span>UI/UX Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Social Media Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-rectangle-list"></i><span>Banner Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-book-open"></i><span>Brochure Design</span></a>
                  </div>
                </div>

                <!-- Software Development -->
                <div class="tmm-content" id="tmm-sd">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-laptop-code"></i><span>Custom Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-users-gear"></i><span>CRM Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-network-wired"></i><span>ERP Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-android"></i><span>Android App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-apple"></i><span>iOS App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>Flutter App</span></a>
                  </div>
                </div>
              </div>

              <!-- Right Side CTA Card -->
              <div class="tmm-cta">
                <div class="tmm-cta-card">
                  <div class="tmm-cta-title">Grow Your Business with ONEDIGIWEB</div>
                  <div class="tmm-cta-bullets">
                    <span><i class="fa-solid fa-check"></i> Free Consultation</span>
                    <span><i class="fa-solid fa-check"></i> Expert Team</span>
                    <span><i class="fa-solid fa-check"></i> Custom Strategy</span>
                    <span><i class="fa-solid fa-check"></i> Transparent Pricing</span>
                  </div>
                  <div class="tmm-cta-actions">
                    <button class="btn btn-tmm-quote open-quote-trigger" onclick="document.getElementById('quotePopup').style.display='flex'">Get Free Quote</button>
                    <a href="https://wa.me/918512821525" class="btn btn-tmm-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a>
                  </div>
                  <div class="tmm-cta-footer"><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 100+ Projects</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 24x7 Support</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> Fast Delivery</span></div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </li>
      <li class="nav-item"><a href="#pricing" class="nav-link" role="menuitem">Pricing</a></li>
      <li class="nav-item"><a href="#portfolio" class="nav-link" role="menuitem">Portfolio</a></li>
      <li class="nav-item"><a href="#contact" class="nav-link" role="menuitem">Contact</a></li>
    </ul>

    <!-- Nav CTA -->
    <div class="nav-cta">
      <a href="tel:+918512821525" class="nav-cta-call">
        <i class="fa-solid fa-phone"></i> +91 8512821525
      </a>
      <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." target="_blank" class="nav-cta-wa">
        <i class="fa-brands fa-whatsapp"></i> WhatsApp
      </a>
      <button class="nav-cta-quote open-quote-trigger">
        <i class="fa-solid fa-rocket"></i> Free Consultation
      </button>
    </div>

    <!-- Hamburger -->
    <button class="hamburger" id="hamburger" aria-label="Toggle Menu" aria-expanded="false">
      <span class="ham-line"></span>
      <span class="ham-line"></span>
      <span class="ham-line"></span>
    </button>
  </nav>
</header>

<!-- END COMPONENT: HEADER -->

<section class="policy-hero">
  <div class="container">
    <div class="section-pill">About Us</div>
    <h1>About ONEDIGIWEB</h1>
    <p>Empowering Brands with Data-Driven Digital Marketing Solutions</p>
  </div>
</section>

<section>
  <div class="container policy-content">
    <p>Welcome to <strong>ONEDIGIWEB Marketing Solution</strong>, one of India's fastest-growing digital marketing and website development agencies. We are dedicated to providing cutting-edge solutions designed to help businesses optimize their online presence, attract high-quality leads, and increase sales.</p>

    <h2>Our Mission & Vision</h2>
    <p>At ONEDIGIWEB, our mission is to empower small, medium, and large enterprise businesses with custom-tailored marketing funnels and premium websites. We strive to offer transparent pricing, data-backed results, and persistent innovation to keep your business ahead of the competition in an ever-evolving digital landscape.</p>

    <h2>Why Choose ONEDIGIWEB?</h2>
    <ul>
      <li><strong>Result-Oriented Approach:</strong> We focus on metrics that matterâ€”conversions, leads, and ROIâ€”rather than vanity metrics.</li>
      <li><strong>Dedicated Expert Team:</strong> Our specialists have years of industry experience across SEO, Google Ads, WordPress, and Custom PHP development.</li>
      <li><strong>Transparent Communication:</strong> We provide real-time updates and detailed weekly/monthly reports so you always know your campaign status.</li>
      <li><strong>Custom Strategy:</strong> No two businesses are alike; we craft unique marketing and dev strategies specifically designed for your goals.</li>
    </ul>

    <h2>Our Core Services</h2>
    <p>We provide a comprehensive ecosystem of digital services under one roof:</p>
    <ul>
      <li><strong>Search Engine Optimization (SEO):</strong> Organic growth strategies to rank your brand #1 on Google.</li>
      <li><strong>Paid Advertising (PPC):</strong> Highly optimized Google Ads and Social Media ad campaigns.</li>
      <li><strong>Web Development:</strong> Clean, responsive business websites, WooCommerce stores, and custom software.</li>
      <li><strong>Branding & Design:</strong> Custom logo designs, marketing collateral, and UI/UX design.</li>
    </ul>

    <h2>Contact Our Team</h2>
    <p>Ready to start your digital growth journey? Get in touch with us today:</p>
    <ul>
      <li>Email: <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a></li>
      <li>Phone: <a href="tel:+918512821525">+91 8512821525</a></li>
      <li>Address: Delhi NCR, India</li>
    </ul>
  </div>
</section>

<!-- COMPONENT: FOOTER -->

<!-- ============================================================
     PORTFOLIO
============================================================ -->
<section class="section portfolio-section" id="portfolio" aria-label="Portfolio">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Portfolio</div>
      <h2 class="section-heading">Our <span class="grad-text">Work &amp; Results</span></h2>
      <p class="section-sub">Real projects, real results - see what we've delivered for our clients</p>
    </div>
    <div class="ptabs" role="tablist">
      <button class="ptab active" data-filter="all" role="tab">All Projects</button>
      <button class="ptab" data-filter="seo" role="tab">SEO</button>
      <button class="ptab" data-filter="web" role="tab">Websites</button>
      <button class="ptab" data-filter="ads" role="tab">Google Ads</button>
      <button class="ptab" data-filter="social" role="tab">Social Media</button>
    </div>
    <div class="port-grid">
      <div class="port-card port-item" data-cat="seo">
        <div class="port-thumb" style="background:linear-gradient(135deg,#5B21B6,#7C3AED)">
          <div class="pt-icon"><i class="fa-solid fa-magnifying-glass-chart" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Dental Clinic SEO</h4><p>300% Traffic Increase in 6 months</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">SEO</div><p>Ranked 15 keywords on Google Page 1, tripled organic traffic</p></div>
      </div>
      <div class="port-card port-item" data-cat="web">
        <div class="port-thumb" style="background:linear-gradient(135deg,#06B6D4,#0891B2)">
          <div class="pt-icon"><i class="fa-solid fa-laptop-code" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Ecommerce Website</h4><p>500+ Products, 2x Conversion Rate</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Website</div><p>Custom WooCommerce store with payment gateway integration</p></div>
      </div>
      <div class="port-card port-item" data-cat="ads">
        <div class="port-thumb" style="background:linear-gradient(135deg,#EA4335,#FBBC04)">
          <div class="pt-icon"><i class="fa-brands fa-google" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Google Ads Campaign</h4><p>Rs.2L Ad Spend = Rs.18L Revenue</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Google Ads</div><p>Real estate campaign with 9x ROAS in 3 months</p></div>
      </div>
      <div class="port-card port-item" data-cat="social">
        <div class="port-thumb" style="background:linear-gradient(135deg,#E1306C,#833AB4)">
          <div class="pt-icon"><i class="fa-brands fa-instagram" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Instagram Growth</h4><p>0 to 50K Followers in 4 months</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Social Media</div><p>Fashion brand Instagram account managed to explosive growth</p></div>
      </div>
      <div class="port-card port-item" data-cat="seo">
        <div class="port-thumb" style="background:linear-gradient(135deg,#10B981,#059669)">
          <div class="pt-icon"><i class="fa-solid fa-location-dot" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Local SEO - Restaurant</h4><p>#1 on Google Maps in 90 Days</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Local SEO</div><p>Restaurant ranked #1 for 8 local keywords, 40% more footfall</p></div>
      </div>
      <div class="port-card port-item" data-cat="web">
        <div class="port-thumb" style="background:linear-gradient(135deg,#F59E0B,#EF4444)">
          <div class="pt-icon"><i class="fa-solid fa-mobile-screen" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Mobile App Development</h4><p>10K+ Downloads in First Month</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">App Dev</div><p>React Native delivery app with real-time tracking and payments</p></div>
      </div>
    </div>
  </div>
</section>

<footer class="footer" id="footer" aria-label="Footer">
  <div class="footer-main container">
    <div class="footer-grid">

      <!-- Brand Column -->
      <div class="footer-brand">
        <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="260" height="74" class="logo-img"></a>
        <div class="footer-brand-tagline">Grow &bull; Rank &bull; Convert</div>
        <div class="footer-brand-services">SEO | Digital Marketing | Website Development</div>
        <p>India's trusted digital marketing agency helping businesses grow online with proven, data-driven strategies and dedicated round-the-clock support.</p>
        <div class="footer-brand-contacts">
          <a href="tel:+918512821525" class="fbc-item"><i class="fa-solid fa-phone"></i> +91 8512821525</a>
          <a href="mailto:onedigiweb@gmail.com" class="fbc-item"><i class="fa-solid fa-envelope"></i> onedigiweb@gmail.com</a>
          <a href="https://wa.me/918512821525" class="fbc-item" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp: +91 8512821525</a>
        </div>
        <div class="footer-socials">
          <a href="https://www.facebook.com/onedigiweb" target="_blank" class="fs-link fs-fb" title="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="https://www.instagram.com/onedigiweb" target="_blank" class="fs-link fs-ig" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://www.linkedin.com/company/onedigiweb" target="_blank" class="fs-link fs-li" title="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
          <a href="https://www.youtube.com/@onedigiweb" target="_blank" class="fs-link fs-yt" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
          <a href="https://wa.me/918512821525" target="_blank" class="fs-link fs-wa" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
        </div>
      </div>

      <!-- Quick Links -->
      <div class="footer-col">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="index.html#home"><i class="fa-solid fa-house fa-xs"></i> Home</a></li>
          <li><a href="index.html#services"><i class="fa-solid fa-briefcase fa-xs"></i> Services</a></li>
          <li><a href="index.html#pricing"><i class="fa-solid fa-tags fa-xs"></i> Pricing</a></li>
          <li><a href="index.html#portfolio"><i class="fa-solid fa-images fa-xs"></i> Portfolio</a></li>
          <li><a href="index.html#contact"><i class="fa-solid fa-envelope fa-xs"></i> Contact</a></li>
        </ul>
      </div>

      <!-- Services Links -->
      <div class="footer-col">
        <h4>Our Services</h4>
        <ul>
          <li><a href="seo-services.html"><i class="fa-solid fa-magnifying-glass fa-xs"></i> SEO Services</a></li>
          <li><a href="google-ads-services.html"><i class="fa-brands fa-google fa-xs"></i> Google Ads</a></li>
          <li><a href="social-media-marketing.html"><i class="fa-solid fa-share-nodes fa-xs"></i> Social Media Marketing</a></li>
          <li><a href="website-development.html"><i class="fa-solid fa-laptop-code fa-xs"></i> Website Development</a></li>
          <li><a href="ecommerce-development.html"><i class="fa-solid fa-cart-shopping fa-xs"></i> Ecommerce Development</a></li>
          <li><a href="app-development.html"><i class="fa-solid fa-mobile-screen fa-xs"></i> App Development</a></li>
          <li><a href="graphic-design-services.html"><i class="fa-solid fa-pen-nib fa-xs"></i> Graphic Design</a></li>
          <li><a href="lead-generation-services.html"><i class="fa-solid fa-chart-line fa-xs"></i> Lead Generation</a></li>
        </ul>
      </div>

      <!-- Contact + CTA -->
      <div class="footer-col">
        <h4>Contact Us</h4>
        <ul class="fc-contact">
          <li><a href="mailto:onedigiweb@gmail.com"><i class="fa-solid fa-envelope"></i> onedigiweb@gmail.com</a></li>
          <li><a href="tel:+918512821525"><i class="fa-solid fa-phone"></i> +91 8512821525</a></li>
          <li><a href="https://wa.me/918512821525" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a></li>
          <li><span><i class="fa-solid fa-clock"></i> Mon&ndash;Sat: 9AM&ndash;7PM</span></li>
        </ul>
        <button onclick="document.getElementById('quotePopup').style.display='flex'" class="footer-cta">
          <i class="fa-solid fa-rocket"></i> Get Free Quote
        </button>
      </div>
    </div>
  </div>

  <!-- Footer Bottom -->
  <div class="footer-bottom">
    <div class="container footer-bottom-inner">
      <p>&copy; 2026 ONEDIGIWEB Marketing Solution. All Rights Reserved.</p>
      <div class="footer-policy-links">
        <a href="privacy-policy.html">Privacy Policy</a>
        <span>&bull;</span>
        <a href="terms-and-conditions.html">Terms &amp; Conditions</a>
        <span>&bull;</span>
        <a href="refund-policy.html">Refund Policy</a>
        <span>&bull;</span>
        <a href="disclaimer.html">Disclaimer</a>
        <span>&bull;</span>
        <a href="about-us.html">About Us</a>
      </div>
    </div>
  </div>
</footer>

<!-- END COMPONENT: FOOTER -->
<!-- COMPONENT: POPUPS -->
<!-- Floating Glass FABs (Desktop/Mobile) -->
<div class="glass-fabs" id="glassFabs">
  <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." class="gfab gfab-wa" target="_blank" title="WhatsApp">
    <div class="gfab-pulse"></div>
    <i class="fa-brands fa-whatsapp" style="font-size:22px"></i>
    <span>WhatsApp</span>
  </a>
  <a href="tel:+918512821525" class="gfab gfab-call" title="Call Now">
    <i class="fa-solid fa-phone" style="font-size:18px"></i>
    <span>Call Now</span>
  </a>
  <button class="gfab gfab-top" id="backTop" onclick="window.scrollTo({top:0,behavior:'smooth'})" title="Back to Top">
    <i class="fa-solid fa-chevron-up" style="font-size:16px"></i>
    <span>Back to Top</span>
  </button>
</div>

<!-- Quote popup -->
<div class="popup-overlay quote-popup-overlay" id="quotePopup" style="display:none">
  <div class="quote-popup-box">
    <div class="qp-left"><div class="qp-left-inner" style="justify-content: flex-start; gap: 15px;"><div class="qp-brand" style="display:flex; justify-content:center; margin-bottom:10px;">
  <div class="custom-logo" style="transform:scale(0.8); transform-origin: left center; border:none; padding:0;">
    <div class="cl-icon"><div class="cl-icon-inner"><i class="fa-solid fa-globe cl-globe"></i></div></div>
    <div class="cl-text">
      <div class="cl-name" style="color:white;">ONEDIGIWEB</div>
      <div class="cl-divider" style="background-color:white;"></div>
      <div class="cl-tag" style="color:white;">Marketing Solution</div>
    </div>
  </div>
</div>
    <div class="qp-right">
      <button class="qp-close" onclick="document.getElementById('quotePopup').style.display='none'">x</button>
      <div class="qp-form-header"><h4>Get Your FREE Digital Strategy Session!</h4><p>Discover how your business can generate more traffic, quality leads, and sales.</p></div>
      <form class="qp-form" id="quoteForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
        <input type="hidden" name="_subject" value="New Consultation Inquiry | ONEDIGIWEB" />
        <input type="hidden" name="_captcha" value="false" />
        <input type="hidden" name="_next" value="https://onedigiweb.com/thank-you.html" />
        <input type="text" name="_honey" style="display:none" />
        <input type="hidden" name="Submission Date & Time" class="sub-date-time-field" value="" />
        <div class="qf-row"><div class="qf-group"><label>Full Name *</label><input type="text" name="Name" placeholder="Enter your full name" required /></div><div class="qf-group"><label>Mobile Number *</label><input type="tel" name="Mobile Number" placeholder="Enter mobile number" required /></div></div>
        <div class="qf-row"><div class="qf-group"><label>Email Address *</label><input type="email" name="Email" placeholder="your@email.com" required /></div><div class="qf-group"><label>Business Name</label><input type="text" name="Business Name" placeholder="Optional" /></div></div>
        
        <div class="qf-row"><div class="qf-group" style="grid-column: span 2;"><label>Select Service Interested In *</label><select name="Selected Service" required><option value="" disabled selected>Choose a service...</option><option value="SEO Services">SEO Services</option><option value="Google Ads">Google Ads</option><option value="Social Media Marketing">Social Media Marketing</option><option value="Website Development">Website Development</option><option value="Ecommerce Website">Ecommerce Website</option><option value="App Development">App Development</option><option value="Branding & Design">Branding &amp; Design</option><option value="Complete Digital Marketing">Complete Digital Marketing</option></select></div></div>
        <div class="qf-group"><label>Message / Requirement</label><textarea name="Message" rows="3" placeholder="Tell us about your business goals..."></textarea></div>
        <button type="submit" class="btn btn-hero-primary btn-full qf-submit" id="qfSubmitBtn"><i class="fa-solid fa-rocket"></i> Claim My Free Strategy Session</button>
      </form>
    </div>
  </div>
</div>

<!-- Script -->
<script src="script.js"></script>
<?php wp_footer(); ?>
</body>
</html>











