﻿<?php
/**
 * Template Name: Disclaimer
 */
?>
<?php get_header(); ?>


<section class="policy-hero">
  <div class="container">
    <div class="section-pill">Legal</div>
    <h1>Disclaimer</h1>
    <p>Last Updated: June 28, 2026</p>
  </div>
</section>

<section>
  <div class="container policy-content">
    <p>Welcome to <strong>ONEDIGIWEB Marketing Solution</strong>. The information provided on this website (https://onedigiweb.com) is for general informational purposes only. All information on the site is provided in good faith, however we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the site.</p>

    <h2>1. Professional Disclaimer</h2>
    <p>The site cannot and does not contain digital marketing, search engine optimization (SEO), or business growth advice. The marketing information is provided for general informational and educational purposes only and is not a substitute for professional advice. Accordingly, before taking any actions based upon such information, we encourage you to consult with the professionals at ONEDIGIWEB.</p>

    <h2>2. Results Disclaimer (Case Studies & Testimonials)</h2>
    <p>The site may contain testimonials and case studies reflecting real-life experiences and results of users of our services. However, these experiences and results are personal to those particular users, and may not necessarily be representative of all users of our services. We do not claim, and you should not assume, that all users will have the same experiences or results. YOUR INDIVIDUAL RESULTS MAY VARY.</p>

    <h2>3. External Links Disclaimer</h2>
    <p>The site may contain (or you may be sent through the site) links to other websites or content belonging to or originating from third parties. Such external links are not investigated, monitored, or checked for accuracy, adequacy, validity, reliability, availability, or completeness by us. We do not warrant, endorse, guarantee, or assume responsibility for the accuracy or reliability of any information offered by third-party websites linked through the site.</p>

    <h2>4. Limitation of Liability</h2>
    <p>Under no circumstance shall we have any liability to you for any loss or damage of any kind incurred as a result of the use of the site or reliance on any information provided on the site. Your use of the site and your reliance on any information on the site is solely at your own risk.</p>

    <h2>5. Contact Us</h2>
    <p>If you have any questions or require further details about this disclaimer, please contact us at:</p>
    <ul>
      <li>Email: <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a></li>
      <li>Phone: +91 8512821525</li>
      <li>Address: A-88, New Delhi, India</li>
    </ul>
  </div>
</section>


<?php get_footer(); ?>
