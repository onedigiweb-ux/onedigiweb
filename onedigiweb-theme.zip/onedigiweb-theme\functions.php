<?php
/**
 * ONEDIGIWEB Theme Functions
 */

if ( ! function_exists( 'onedigiweb_setup' ) ) :
	function onedigiweb_setup() {
		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the document title.
		add_theme_support( 'title-tag' );

		// Enable support for Post Thumbnails on posts and pages.
		add_theme_support( 'post-thumbnails' );

		// Register Navigation Menus
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary Menu', 'onedigiweb' ),
			'footer'  => esc_html__( 'Footer Menu', 'onedigiweb' ),
		) );

		// HTML5 support
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		) );
	}
endif;
add_action( 'after_setup_theme', 'onedigiweb_setup' );

/**
 * Enqueue scripts and styles.
 */
function onedigiweb_scripts() {
	// Font Awesome
	wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0' );

	// Theme Styles
	wp_enqueue_style( 'onedigiweb-style', get_stylesheet_uri(), array(), filemtime( get_template_directory() . '/style.css' ) );

	// Theme Scripts
	wp_enqueue_script( 'onedigiweb-script', get_template_directory_uri() . '/script.js', array(), filemtime( get_template_directory() . '/script.js' ), true );
}
add_action( 'wp_enqueue_scripts', 'onedigiweb_scripts' );

/**
 * Disable WordPress emojis to improve performance
 */
function onedigiweb_disable_emojis() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'onedigiweb_disable_emojis' );
