﻿<?php
/**
 * Template Name: Technical Seo Services
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
  <meta name="description" content="ONEDIGIWEB offers technical SEO services in India." />
  <meta name="keywords" content="Technical SEO Services India" />
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="https://onedigiweb.com/technical-seo-services.html" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
  <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>" />
  <style>
    .sp-hero { background: linear-gradient(135deg, #0F172A, #1E1035); padding: 20px 0 80px; color: white; }
    .sp-content-section { padding: 80px 0; }
    .sp-overview { background: #f8fafc; }
    .sp-process { background: white; }
    .sp-pricing { background: #f8fafc; }
    .sp-faq { background: white; }
    .section-title { font-size: 32px; font-weight: 800; color: #0F172A; text-align: center; margin-bottom: 40px; }
    
    /* Layout */
    .sp-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 40px; }
    @media (max-width: 992px) { .sp-layout { grid-template-columns: 1fr; } }
    
    /* Content Blocks */
    .sp-box { background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); margin-bottom: 30px; }
    .sp-box h3 { font-size: 24px; font-weight: 800; margin-bottom: 15px; color: var(--p1); }
    .sp-box ul { padding-left: 20px; line-height: 1.8; color: #475569; }
    
    /* Sidebar Form */
    .sp-form-card { background: white; border-radius: 12px; padding: 30px; border-top: 4px solid var(--p1); box-shadow: 0 20px 50px rgba(0,0,0,0.1); position: sticky; top: 100px; }
    .sp-form-card h4 { font-size: 20px; font-weight: 800; margin-bottom: 20px; }
    .sp-input { width: 100%; padding: 12px 16px; border: 1px solid #cbd5e1; border-radius: 8px; margin-bottom: 15px; font-family: inherit; }
    .sp-btn { width: 100%; padding: 15px; background: var(--p1); color: white; border: none; border-radius: 8px; font-weight: 700; cursor: pointer; transition: 0.3s; }
    .sp-btn:hover { background: var(--dark); }
    
    /* CTA Banner */
    .sp-cta-banner { background: var(--p1); color: white; padding: 60px 0; text-align: center; border-radius: 16px; margin: 60px 0; }
    .sp-cta-banner h3 { font-size: 32px; font-weight: 800; margin-bottom: 20px; }
    .sp-cta-banner p { font-size: 18px; margin-bottom: 30px; opacity: 0.9; }
    .btn-white { background: white; color: var(--p1); padding: 14px 28px; border-radius: 50px; font-weight: 700; display: inline-block; text-decoration: none; }
  </style>
  <!-- Favicons -->
  <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" />
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-32x32.png" />
  <link rel="icon" type="image/png" sizes="48x48" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-48x48.png" />
  <link rel="icon" type="image/png" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-180x180.png" />
  <link rel="icon" type="image/png" sizes="512x512" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-512x512.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/apple-touch-icon.png" />
  <link rel="manifest" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/site.webmanifest" />
<?php wp_head(); ?>
</head>
<body>

  <!-- HEADER -->
  <header class="header" id="header">
  <nav class="navbar container">

    <!-- Logo -->
    <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="260" height="74" class="logo-img"></a>

    <!-- Nav Menu -->
    <ul class="nav-menu" id="navMenu" role="menubar">
      <li class="nav-item"><a href="#home" class="nav-link active" role="menuitem">Home</a></li>
      <li class="nav-item has-mega">
        <a href="#services" class="nav-link nav-link-arrow" role="menuitem">Services</a>
                        <div class="mega-menu tabbed-mega-menu" role="menu">
          <div class="mega-inner container">
            
            <!-- Top Category Tabs -->
            <div class="tmm-tabs-container">
              <div class="tmm-tabs">
                <button class="tmm-tab active" data-target="tmm-seo"><i class="fa-solid fa-magnifying-glass"></i> SEO Services</button>
                <button class="tmm-tab" data-target="tmm-dm"><i class="fa-solid fa-bullhorn"></i> Digital Marketing</button>
                <button class="tmm-tab" data-target="tmm-web"><i class="fa-solid fa-code"></i> Website Development</button>
                <button class="tmm-tab" data-target="tmm-app"><i class="fa-solid fa-mobile-screen"></i> App Marketing</button>
                <button class="tmm-tab" data-target="tmm-cm"><i class="fa-solid fa-pen-nib"></i> Content Marketing</button>
                <button class="tmm-tab" data-target="tmm-ppc"><i class="fa-solid fa-mouse-pointer"></i> Google Ads / PPC</button>
                <button class="tmm-tab" data-target="tmm-ar"><i class="fa-solid fa-chart-pie"></i> Analytics & Reporting</button>
                <button class="tmm-tab" data-target="tmm-gd"><i class="fa-solid fa-bezier-curve"></i> Graphic Design</button>
                <button class="tmm-tab" data-target="tmm-sd"><i class="fa-solid fa-laptop-code"></i> Software Development</button>
              </div>
            </div>

            <div class="tmm-body">
              <!-- Left side: Services List -->
              <div class="tmm-content-area">
                
                <!-- SEO -->
                <div class="tmm-content active" id="tmm-seo">
                  <div class="tmm-links-grid">
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>SEO Services</span></a>
                    <a href="local-seo-services.html" class="tmm-link"><i class="fa-solid fa-map-location-dot"></i><span>Local SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-gears"></i><span>Technical SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-cart-arrow-down"></i><span>Ecommerce SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Enterprise SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-robot"></i><span>AI SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-stethoscope"></i><span>SEO audit</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-link"></i><span>Link Building</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-triangle-exclamation"></i><span>Google Penalty Recovery</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-truck-fast"></i><span>SEO Migration</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-language"></i><span>Multilingual SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-globe"></i><span>International SEO</span></a>
                  </div>
                </div>

                <!-- Digital Marketing -->
                <div class="tmm-content" id="tmm-dm">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-brands fa-google"></i><span>Google Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-meta"></i><span>Meta Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-youtube"></i><span>YouTube Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-instagram"></i><span>Instagram Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-facebook"></i><span>Facebook Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-linkedin"></i><span>LinkedIn Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope-open-text"></i><span>Email Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-bullhorn"></i><span>Content Marketing</span></a>
                    <a href="lead-generation-services.html" class="tmm-link"><i class="fa-solid fa-magnet"></i><span>Lead Generation</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-shield-halved"></i><span>Online Reputation Management</span></a>
                  </div>
                </div>

                <!-- Website Development -->
                <div class="tmm-content" id="tmm-web">
                  <div class="tmm-links-grid">
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Business Website</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building-user"></i><span>Corporate Website</span></a>
                    <a href="wordpress-development.html" class="tmm-link"><i class="fa-brands fa-wordpress"></i><span>WordPress</span></a>
                    <a href="ecommerce-development.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Ecommerce Website</span></a>
                    <a href="shopify-development.html" class="tmm-link"><i class="fa-brands fa-shopify"></i><span>Shopify</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-react"></i><span>React</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-n"></i><span>Next.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-laravel"></i><span>Laravel</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-php"></i><span>Custom PHP</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-node-js"></i><span>Node.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-screwdriver-wrench"></i><span>Website Maintenance</span></a>
                  </div>
                </div>

                <!-- App Marketing -->
                <div class="tmm-content" id="tmm-app">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>App Store Optimization</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-download"></i><span>App Install Campaigns</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-star"></i><span>App Reviews & Ratings</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-chart-line"></i><span>App Analytics</span></a>
                  </div>
                </div>

                <!-- Content Marketing -->
                <div class="tmm-content" id="tmm-cm">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-pen-fancy"></i><span>Blog Writing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-file-lines"></i><span>Copywriting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-video"></i><span>Video Scripting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope"></i><span>Newsletter Writing</span></a>
                  </div>
                </div>

                <!-- Google Ads / PPC -->
                <div class="tmm-content" id="tmm-ppc">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-dollar"></i><span>Search Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Display Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Shopping Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-rotate-left"></i><span>Remarketing</span></a>
                  </div>
                </div>

                <!-- Analytics & Reporting -->
                <div class="tmm-content" id="tmm-ar">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-pie"></i><span>Google Analytics 4</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-column"></i><span>Custom Dashboards</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-filter"></i><span>Conversion Tracking</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>Data Audits</span></a>
                  </div>
                </div>

                <!-- Graphic Design -->
                <div class="tmm-content" id="tmm-gd">
                  <div class="tmm-links-grid">
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-bezier-curve"></i><span>Logo Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-award"></i><span>Brand Identity</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-object-group"></i><span>UI/UX Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Social Media Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-rectangle-list"></i><span>Banner Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-book-open"></i><span>Brochure Design</span></a>
                  </div>
                </div>

                <!-- Software Development -->
                <div class="tmm-content" id="tmm-sd">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-laptop-code"></i><span>Custom Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-users-gear"></i><span>CRM Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-network-wired"></i><span>ERP Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-android"></i><span>Android App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-apple"></i><span>iOS App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>Flutter App</span></a>
                  </div>
                </div>
              </div>

              <!-- Right Side CTA Card -->
              <div class="tmm-cta">
                <div class="tmm-cta-card">
                  <div class="tmm-cta-title">Grow Your Business with ONEDIGIWEB</div>
                  <div class="tmm-cta-bullets">
                    <span><i class="fa-solid fa-check"></i> Free Consultation</span>
                    <span><i class="fa-solid fa-check"></i> Expert Team</span>
                    <span><i class="fa-solid fa-check"></i> Custom Strategy</span>
                    <span><i class="fa-solid fa-check"></i> Transparent Pricing</span>
                  </div>
                  <div class="tmm-cta-actions">
                    <button class="btn btn-tmm-quote open-quote-trigger" onclick="document.getElementById('quotePopup').style.display='flex'">Get Free Quote</button>
                    <a href="https://wa.me/918512821525" class="btn btn-tmm-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a>
                  </div>
                  <div class="tmm-cta-footer"><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 100+ Projects</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 24x7 Support</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> Fast Delivery</span></div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </li>
      <li class="nav-item"><a href="#pricing" class="nav-link" role="menuitem">Pricing</a></li>
      <li class="nav-item"><a href="#portfolio" class="nav-link" role="menuitem">Portfolio</a></li>
      <li class="nav-item"><a href="#contact" class="nav-link" role="menuitem">Contact</a></li>
    </ul>

    <!-- Nav CTA -->
    <div class="nav-cta">
      <a href="tel:+918512821525" class="nav-cta-call">
        <i class="fa-solid fa-phone"></i> +91 8512821525
      </a>
      <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." target="_blank" class="nav-cta-wa">
        <i class="fa-brands fa-whatsapp"></i> WhatsApp
      </a>
      <button class="nav-cta-quote open-quote-trigger">
        <i class="fa-solid fa-rocket"></i> Free Consultation
      </button>
    </div>

    <!-- Hamburger -->
    <button class="hamburger" id="hamburger" aria-label="Toggle Menu" aria-expanded="false">
      <span class="ham-line"></span>
      <span class="ham-line"></span>
      <span class="ham-line"></span>
    </button>
  </nav>
</header>

  <!-- HERO -->
  <section class="sp-hero">
    <div class="container">
      <div style="font-size: 14px; opacity: 0.6; margin-bottom: 20px;">Home > Services > Technical SEO</div>
      <h1 style="font-size: 48px; font-weight: 900; margin-bottom: 20px;">Technical SEO Services in India</h1>
      <h2 style="font-size: 22px; font-weight: 400; opacity: 0.8; margin-bottom: 40px; max-width: 800px;">Optimize Your Website Architecture for Google</h2>
      <div style="display: flex; gap: 15px;">
        <a href="#inquiry" class="btn-white">Get a Free Quote</a>
        <a href="https://wa.me/918512821525" class="btn-white" style="background:#25D366;color:white;"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
      </div>
    </div>
  </section>

  <!-- MAIN CONTENT -->
  <section class="sp-content-section sp-overview">
    <div class="container sp-layout">
      <!-- Left Content -->
      <div class="sp-main">
        
        <div class="sp-box">
          <h3>Overview of Technical SEO</h3>
          <p>Our Technical SEO solutions are designed to help your business achieve maximum digital growth. We utilize cutting-edge strategies, data-driven methodologies, and an expert team to ensure you get the best ROI.</p>
        </div>

        <div class="sp-box">
          <h3>Key Features & Benefits</h3>
          <ul>
            <li>Customized strategies tailored to your business goals.</li>
            <li>Transparent reporting and regular performance updates.</li>
            <li>Dedicated account managers providing 24/7 support.</li>
            <li>Data-driven approach to maximize conversion rates.</li>
            <li>Scalable solutions that grow alongside your business.</li>
          </ul>
        </div>

        <div class="sp-box">
          <h3>Our Process</h3>
          <p>We follow a proven 4-step process to deliver success:</p>
          <ol style="padding-left: 20px; line-height: 1.8; color: #475569;">
            <li><strong>Discovery:</strong> Understanding your business, goals, and target audience.</li>
            <li><strong>Strategy:</strong> Developing a customized action plan.</li>
            <li><strong>Execution:</strong> Implementing the strategies with precision.</li>
            <li><strong>Optimization:</strong> Continuous monitoring and refining for better results.</li>
          </ol>
        </div>

        <div class="sp-cta-banner">
          <h3>Ready to Grow Your Business?</h3>
          <p>Partner with ONEDIGIWEB for premium Technical SEO solutions.</p>
          <a href="tel:+918512821525" class="btn-white"><i class="fa-solid fa-phone"></i> Call +91 8512821525</a>
        </div>

        <div class="sp-box">
          <h3>Frequently Asked Questions</h3>
          <div style="margin-bottom: 20px;">
            <strong>What is the cost of Technical SEO?</strong>
            <p>Our pricing is highly customizable based on your requirements. Please contact us for a customized quote.</p>
          </div>
          <div>
            <strong>How long does it take to see results?</strong>
            <p>The timeline varies depending on the specific service and your industry, but our team works diligently to deliver fast, sustainable results.</p>
          </div>
        </div>
      </div>

      <!-- Right Sidebar -->
      <div class="sp-sidebar" id="inquiry">
        <div class="sp-form-card">
          <h4>Inquire About Technical SEO</h4>
          <p style="font-size:14px; color:#64748b; margin-bottom:20px;">Fill out the form below and our team will get back to you within 30 minutes.</p>
          <form action="mailto:onedigiweb@gmail.com?subject=Inquiry for Technical SEO" method="POST" enctype="text/plain">
            <input type="hidden" name="Service" value="Technical SEO">
            <input type="text" name="Name" class="sp-input" placeholder="Full Name" required>
            <input type="email" name="Email" class="sp-input" placeholder="Email Address" required>
            <input type="tel" name="Phone" class="sp-input" placeholder="Phone Number" required>
            <textarea name="Message" class="sp-input" placeholder="Tell us about your project..." rows="4" required></textarea>
            <button type="submit" class="sp-btn">Send Inquiry</button>
          </form>
        </div>
      </div>
    </div>
  </section>

<?php wp_footer(); ?>
</body>
</html>





