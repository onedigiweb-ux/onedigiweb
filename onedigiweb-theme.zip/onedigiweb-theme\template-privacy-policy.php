﻿<?php
/**
 * Template Name: Privacy Policy
 */
?>
<?php get_header(); ?>


<section class="policy-hero">
  <div class="container">
    <div class="section-pill">Legal</div>
    <h1>Privacy Policy</h1>
    <p>Last Updated: June 24, 2026 &nbsp;&middot;&nbsp; Effective Date: June 24, 2026</p>
  </div>
</section>

<section>
  <div class="container policy-content">
    <p>Welcome to <strong>ONEDIGIWEB Marketing Solution</strong> ("Company", "we", "our", "us"). We are committed to protecting your personal information and your right to privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.</p>

    <h2>1. Information We Collect</h2>
    <p>We may collect information about you in a variety of ways. The information we may collect includes:</p>
    <ul>
      <li><strong>Personal Data:</strong> Name, email address, phone number, and company name provided through contact forms, quote requests, or newsletter signup.</li>
      <li><strong>Usage Data:</strong> Browser type, IP address, pages visited, time spent on pages, referring URLs, and other diagnostic data collected automatically.</li>
      <li><strong>Cookies:</strong> We use cookies and similar tracking technologies to track activity on our website and improve user experience.</li>
    </ul>

    <h2>2. How We Use Your Information</h2>
    <p>We use the information we collect in the following ways:</p>
    <ul>
      <li>To provide, operate, and maintain our services</li>
      <li>To respond to your consultation requests and inquiries</li>
      <li>To send promotional communications (only with your consent)</li>
      <li>To improve our website and services based on your feedback</li>
      <li>To comply with legal obligations</li>
    </ul>

    <h2>3. How We Share Your Information</h2>
    <p>We do not sell, trade, or rent your personal information to third parties. We may share data with:</p>
    <ul>
      <li><strong>Service Providers:</strong> Third-party vendors who help us operate our business (e.g., email service providers, analytics tools).</li>
      <li><strong>Legal Requirements:</strong> If required by law or to protect our rights.</li>
    </ul>

    <h2>4. Data Security</h2>
    <p>We implement industry-standard security measures to protect your personal information. However, no method of transmission over the internet is 100% secure. While we strive to use commercially acceptable means to protect your data, we cannot guarantee absolute security.</p>

    <h2>5. Cookies Policy</h2>
    <p>Our website uses cookies to enhance your experience. You can instruct your browser to refuse all cookies or indicate when a cookie is being sent. However, some website features may not function properly without cookies.</p>

    <h2>6. Third-Party Websites</h2>
    <p>Our website may contain links to third-party websites. We are not responsible for the privacy practices of those websites and encourage you to review their privacy policies.</p>

    <h2>7. Children's Privacy</h2>
    <p>Our services are not directed to children under 13 years of age. We do not knowingly collect personal information from children under 13.</p>

    <h2>8. Your Rights</h2>
    <p>You have the right to:</p>
    <ul>
      <li>Access the personal information we hold about you</li>
      <li>Request correction of inaccurate data</li>
      <li>Request deletion of your personal data</li>
      <li>Opt out of marketing communications at any time</li>
    </ul>

    <h2>9. Contact Us</h2>
    <p>If you have questions about this Privacy Policy, please contact us:</p>
    <ul>
      <li><i class="fa-solid fa-envelope"></i> Email: <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a></li>
      <li><i class="fa-solid fa-phone"></i> Phone: <a href="tel:+918512821525">+91 8512821525</a></li>
      <li><i class="fa-brands fa-whatsapp"></i> WhatsApp: <a href="https://wa.me/918512821525" target="_blank">Chat with Us</a></li>
    </ul>
  </div>
</section>


<?php get_footer(); ?>
