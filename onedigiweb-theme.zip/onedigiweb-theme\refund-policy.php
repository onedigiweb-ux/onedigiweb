﻿<?php
/**
 * Template Name: Refund Policy
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- ============================================================
       MARKETING INTEGRATIONS (Analytics, AdSense, Pinterest, Ads)
  ============================================================ -->
  <!-- Google Tag (gtag.js) - Google Analytics & Google Ads -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-XXXXXXXXXX'); // Replace with Google Analytics Measurement ID
    gtag('config', 'AW-YYYYYYYYY');  // Replace with Google Ads Conversion ID
  </script>

  <!-- Google AdSense -->
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-ZZZZZZZZZZZZZZZZ" crossorigin="anonymous"></script>

  <!-- Pinterest Tag -->
  <script>
    !function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(Array.prototype.slice.call(arguments))};var n=window.pintrk;n.queue=[],n.version="3.0";var t=document.createElement("script");t.async=!0,t.src=e;var r=document.getElementsByTagName("script")[0];r.parentNode.insertBefore(t,r)}}("https://s.pinterest.com/js/pinit.js");
    pintrk('load', 'PARTNER_ID'); // Replace with Pinterest Partner ID
    pintrk('page');
  </script>
  <noscript>
    <img height="1" width="1" style="display:none;" alt="" src="https://ct.pinterest.com/v3/?event=init&tid=PARTNER_ID&noscript=1" />
  </noscript>
  <!-- ============================================================ -->
  
  <meta name="description" content="Read ONEDIGIWEB's Refund Policy. Understand our refund and cancellation terms for digital marketing, website development and other services." />
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="https://onedigiweb.com/refund-policy.html" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" />
  <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>" />
  <style>
    .policy-hero { background: var(--dark); padding: 20px 0 60px; }
    .policy-hero h1 { font-family: var(--font); font-size: clamp(28px,4vw,46px); font-weight: 900; color: white; margin-bottom: 12px; }
    .policy-hero p { color: rgba(255,255,255,0.6); font-size: 16px; }
    .policy-content { padding: 70px 0; max-width: 860px; margin: 0 auto; }
    .policy-content h2 { font-family: var(--font); font-size: 22px; font-weight: 800; color: var(--dark); margin: 36px 0 12px; padding-left: 16px; border-left: 4px solid var(--p2); }
    .policy-content p { font-size: 16px; color: var(--gray); line-height: 1.8; margin-bottom: 14px; }
    .policy-content ul { padding-left: 24px; margin-bottom: 14px; }
    .policy-content ul li { font-size: 15px; color: var(--gray); line-height: 1.75; margin-bottom: 6px; }
    .policy-content a { color: var(--p1); }
    .policy-footer { background: var(--dark); padding: 28px 0; text-align: center; }
    .policy-footer p { color: rgba(255,255,255,0.75); font-size: 13px; }
    .policy-footer a { color: var(--accent); }
  </style>
  <!-- Favicons -->
  <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" />
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-32x32.png" />
  <link rel="icon" type="image/png" sizes="48x48" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-48x48.png" />
  <link rel="icon" type="image/png" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-180x180.png" />
  <link rel="icon" type="image/png" sizes="512x512" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-512x512.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/apple-touch-icon.png" />
  <link rel="manifest" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/site.webmanifest" />
<?php wp_head(); ?>
</head>
<body>
<!-- COMPONENT: HEADER -->
<header class="header" id="header">
  <nav class="navbar container">

    <!-- Logo -->
    <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="260" height="74" class="logo-img"></a>

    <!-- Nav Menu -->
    <ul class="nav-menu" id="navMenu" role="menubar">
      <li class="nav-item"><a href="#home" class="nav-link active" role="menuitem">Home</a></li>
      <li class="nav-item has-mega">
        <a href="#services" class="nav-link nav-link-arrow" role="menuitem">Services</a>
                        <div class="mega-menu tabbed-mega-menu" role="menu">
          <div class="mega-inner container">
            
            <!-- Top Category Tabs -->
            <div class="tmm-tabs-container">
              <div class="tmm-tabs">
                <button class="tmm-tab active" data-target="tmm-seo"><i class="fa-solid fa-magnifying-glass"></i> SEO Services</button>
                <button class="tmm-tab" data-target="tmm-dm"><i class="fa-solid fa-bullhorn"></i> Digital Marketing</button>
                <button class="tmm-tab" data-target="tmm-web"><i class="fa-solid fa-code"></i> Website Development</button>
                <button class="tmm-tab" data-target="tmm-app"><i class="fa-solid fa-mobile-screen"></i> App Marketing</button>
                <button class="tmm-tab" data-target="tmm-cm"><i class="fa-solid fa-pen-nib"></i> Content Marketing</button>
                <button class="tmm-tab" data-target="tmm-ppc"><i class="fa-solid fa-mouse-pointer"></i> Google Ads / PPC</button>
                <button class="tmm-tab" data-target="tmm-ar"><i class="fa-solid fa-chart-pie"></i> Analytics & Reporting</button>
                <button class="tmm-tab" data-target="tmm-gd"><i class="fa-solid fa-bezier-curve"></i> Graphic Design</button>
                <button class="tmm-tab" data-target="tmm-sd"><i class="fa-solid fa-laptop-code"></i> Software Development</button>
              </div>
            </div>

            <div class="tmm-body">
              <!-- Left side: Services List -->
              <div class="tmm-content-area">
                
                <!-- SEO -->
                <div class="tmm-content active" id="tmm-seo">
                  <div class="tmm-links-grid">
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>SEO Services</span></a>
                    <a href="local-seo-services.html" class="tmm-link"><i class="fa-solid fa-map-location-dot"></i><span>Local SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-gears"></i><span>Technical SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-cart-arrow-down"></i><span>Ecommerce SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Enterprise SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-robot"></i><span>AI SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-stethoscope"></i><span>SEO audit</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-link"></i><span>Link Building</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-triangle-exclamation"></i><span>Google Penalty Recovery</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-truck-fast"></i><span>SEO Migration</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-language"></i><span>Multilingual SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-globe"></i><span>International SEO</span></a>
                  </div>
                </div>

                <!-- Digital Marketing -->
                <div class="tmm-content" id="tmm-dm">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-brands fa-google"></i><span>Google Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-meta"></i><span>Meta Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-youtube"></i><span>YouTube Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-instagram"></i><span>Instagram Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-facebook"></i><span>Facebook Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-linkedin"></i><span>LinkedIn Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope-open-text"></i><span>Email Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-bullhorn"></i><span>Content Marketing</span></a>
                    <a href="lead-generation-services.html" class="tmm-link"><i class="fa-solid fa-magnet"></i><span>Lead Generation</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-shield-halved"></i><span>Online Reputation Management</span></a>
                  </div>
                </div>

                <!-- Website Development -->
                <div class="tmm-content" id="tmm-web">
                  <div class="tmm-links-grid">
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Business Website</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building-user"></i><span>Corporate Website</span></a>
                    <a href="wordpress-development.html" class="tmm-link"><i class="fa-brands fa-wordpress"></i><span>WordPress</span></a>
                    <a href="ecommerce-development.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Ecommerce Website</span></a>
                    <a href="shopify-development.html" class="tmm-link"><i class="fa-brands fa-shopify"></i><span>Shopify</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-react"></i><span>React</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-n"></i><span>Next.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-laravel"></i><span>Laravel</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-php"></i><span>Custom PHP</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-node-js"></i><span>Node.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-screwdriver-wrench"></i><span>Website Maintenance</span></a>
                  </div>
                </div>

                <!-- App Marketing -->
                <div class="tmm-content" id="tmm-app">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>App Store Optimization</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-download"></i><span>App Install Campaigns</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-star"></i><span>App Reviews & Ratings</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-chart-line"></i><span>App Analytics</span></a>
                  </div>
                </div>

                <!-- Content Marketing -->
                <div class="tmm-content" id="tmm-cm">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-pen-fancy"></i><span>Blog Writing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-file-lines"></i><span>Copywriting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-video"></i><span>Video Scripting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope"></i><span>Newsletter Writing</span></a>
                  </div>
                </div>

                <!-- Google Ads / PPC -->
                <div class="tmm-content" id="tmm-ppc">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-dollar"></i><span>Search Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Display Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Shopping Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-rotate-left"></i><span>Remarketing</span></a>
                  </div>
                </div>

                <!-- Analytics & Reporting -->
                <div class="tmm-content" id="tmm-ar">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-pie"></i><span>Google Analytics 4</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-column"></i><span>Custom Dashboards</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-filter"></i><span>Conversion Tracking</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>Data Audits</span></a>
                  </div>
                </div>

                <!-- Graphic Design -->
                <div class="tmm-content" id="tmm-gd">
                  <div class="tmm-links-grid">
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-bezier-curve"></i><span>Logo Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-award"></i><span>Brand Identity</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-object-group"></i><span>UI/UX Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Social Media Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-rectangle-list"></i><span>Banner Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-book-open"></i><span>Brochure Design</span></a>
                  </div>
                </div>

                <!-- Software Development -->
                <div class="tmm-content" id="tmm-sd">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-laptop-code"></i><span>Custom Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-users-gear"></i><span>CRM Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-network-wired"></i><span>ERP Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-android"></i><span>Android App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-apple"></i><span>iOS App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>Flutter App</span></a>
                  </div>
                </div>
              </div>

              <!-- Right Side CTA Card -->
              <div class="tmm-cta">
                <div class="tmm-cta-card">
                  <div class="tmm-cta-title">Grow Your Business with ONEDIGIWEB</div>
                  <div class="tmm-cta-bullets">
                    <span><i class="fa-solid fa-check"></i> Free Consultation</span>
                    <span><i class="fa-solid fa-check"></i> Expert Team</span>
                    <span><i class="fa-solid fa-check"></i> Custom Strategy</span>
                    <span><i class="fa-solid fa-check"></i> Transparent Pricing</span>
                  </div>
                  <div class="tmm-cta-actions">
                    <button class="btn btn-tmm-quote open-quote-trigger" onclick="document.getElementById('quotePopup').style.display='flex'">Get Free Quote</button>
                    <a href="https://wa.me/918512821525" class="btn btn-tmm-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a>
                  </div>
                  <div class="tmm-cta-footer"><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 100+ Projects</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 24x7 Support</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> Fast Delivery</span></div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </li>
      <li class="nav-item"><a href="#pricing" class="nav-link" role="menuitem">Pricing</a></li>
      <li class="nav-item"><a href="#portfolio" class="nav-link" role="menuitem">Portfolio</a></li>
      <li class="nav-item"><a href="#contact" class="nav-link" role="menuitem">Contact</a></li>
    </ul>

    <!-- Nav CTA -->
    <div class="nav-cta">
      <a href="tel:+918512821525" class="nav-cta-call">
        <i class="fa-solid fa-phone"></i> +91 8512821525
      </a>
      <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." target="_blank" class="nav-cta-wa">
        <i class="fa-brands fa-whatsapp"></i> WhatsApp
      </a>
      <button class="nav-cta-quote open-quote-trigger">
        <i class="fa-solid fa-rocket"></i> Free Consultation
      </button>
    </div>

    <!-- Hamburger -->
    <button class="hamburger" id="hamburger" aria-label="Toggle Menu" aria-expanded="false">
      <span class="ham-line"></span>
      <span class="ham-line"></span>
      <span class="ham-line"></span>
    </button>
  </nav>
</header>

<!-- END COMPONENT: HEADER -->

<section class="policy-hero">
  <div class="container">
    <div class="section-pill" style="margin-bottom:16px;">Legal</div>
    <h1>Refund Policy</h1>
    <p>Last Updated: June 24, 2026 &nbsp;&middot;&nbsp; Effective Date: June 24, 2026</p>
  </div>
</section>

<section>
  <div class="container policy-content">
    <p>At <strong>ONEDIGIWEB Marketing Solution</strong>, we are committed to client satisfaction. This Refund Policy explains when and how refunds are processed for our digital marketing and development services.</p>

    <h2>1. Monthly Service Retainers (SEO, Social Media, Google Ads)</h2>
    <p>For ongoing monthly service retainers:</p>
    <ul>
      <li>Monthly fees paid in advance are non-refundable once work has commenced for that month</li>
      <li>Cancellation requests must be submitted at least 15 days before the next billing cycle</li>
      <li>If you cancel before any work has been done for the upcoming month, you may receive a full refund</li>
      <li>Partial month refunds are not provided once services have been delivered</li>
    </ul>

    <h2>2. One-Time Projects (Website Development, App Development, Graphic Design)</h2>
    <p>For one-time project engagements:</p>
    <ul>
      <li><strong>Before project start:</strong> 100% refund of advance payment if cancelled before work begins</li>
      <li><strong>After project start (0-25% complete):</strong> 50% refund of advance payment</li>
      <li><strong>After 25% completion:</strong> No refund is provided as significant work has been invested</li>
      <li>All work completed to date will be delivered to the client upon cancellation</li>
    </ul>

    <h2>3. Google Ads and Meta Ads</h2>
    <p>Please note that advertising budgets paid directly to Google or Meta (Facebook) platforms are:</p>
    <ul>
      <li>Non-refundable by ONEDIGIWEB as they are direct payments to Google/Meta</li>
      <li>Governed by Google's and Meta's own refund policies</li>
      <li>ONEDIGIWEB's management fees are separate and subject to the monthly retainer policy above</li>
    </ul>

    <h2>4. Eligibility for Refund</h2>
    <p>Refunds may be considered in the following circumstances:</p>
    <ul>
      <li>Failure to deliver agreed services within the committed timeline without prior notice</li>
      <li>Technical defects in delivered websites that cannot be resolved within 30 days</li>
      <li>Duplicate payments made by error</li>
    </ul>

    <h2>5. Non-Refundable Items</h2>
    <p>The following are not eligible for refund:</p>
    <ul>
      <li>Domain registration and hosting fees paid to third parties on behalf of the client</li>
      <li>Third-party tool subscriptions or licenses purchased for the project</li>
      <li>Rush delivery fees</li>
      <li>Services already delivered and approved by the client</li>
    </ul>

    <h2>6. Refund Process</h2>
    <p>To request a refund:</p>
    <ul>
      <li>Email your request to <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a> with your project details</li>
      <li>Our team will review your request within 3-5 business days</li>
      <li>If approved, refunds are processed within 7-10 business days to the original payment method</li>
    </ul>

    <h2>7. Contact Us</h2>
    <p>For refund-related queries, please contact us:</p>
    <ul>
      <li><i class="fa-solid fa-envelope" style="color:var(--p2)"></i> Email: <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a></li>
      <li><i class="fa-solid fa-phone" style="color:var(--p2)"></i> Phone: <a href="tel:+918512821525">+91 8512821525</a></li>
      <li><i class="fa-brands fa-whatsapp" style="color:#25D366"></i> WhatsApp: <a href="https://wa.me/918512821525" target="_blank">Chat with Us</a></li>
    </ul>
  </div>
</section>

<!-- COMPONENT: FOOTER -->

<!-- ============================================================
     PORTFOLIO
============================================================ -->
<section class="section portfolio-section" id="portfolio" aria-label="Portfolio">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Portfolio</div>
      <h2 class="section-heading">Our <span class="grad-text">Work &amp; Results</span></h2>
      <p class="section-sub">Real projects, real results - see what we've delivered for our clients</p>
    </div>
    <div class="ptabs" role="tablist">
      <button class="ptab active" data-filter="all" role="tab">All Projects</button>
      <button class="ptab" data-filter="seo" role="tab">SEO</button>
      <button class="ptab" data-filter="web" role="tab">Websites</button>
      <button class="ptab" data-filter="ads" role="tab">Google Ads</button>
      <button class="ptab" data-filter="social" role="tab">Social Media</button>
    </div>
    <div class="port-grid">
      <div class="port-card port-item" data-cat="seo">
        <div class="port-thumb" style="background:linear-gradient(135deg,#5B21B6,#7C3AED)">
          <div class="pt-icon"><i class="fa-solid fa-magnifying-glass-chart" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Dental Clinic SEO</h4><p>300% Traffic Increase in 6 months</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">SEO</div><p>Ranked 15 keywords on Google Page 1, tripled organic traffic</p></div>
      </div>
      <div class="port-card port-item" data-cat="web">
        <div class="port-thumb" style="background:linear-gradient(135deg,#06B6D4,#0891B2)">
          <div class="pt-icon"><i class="fa-solid fa-laptop-code" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Ecommerce Website</h4><p>500+ Products, 2x Conversion Rate</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Website</div><p>Custom WooCommerce store with payment gateway integration</p></div>
      </div>
      <div class="port-card port-item" data-cat="ads">
        <div class="port-thumb" style="background:linear-gradient(135deg,#EA4335,#FBBC04)">
          <div class="pt-icon"><i class="fa-brands fa-google" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Google Ads Campaign</h4><p>Rs.2L Ad Spend = Rs.18L Revenue</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Google Ads</div><p>Real estate campaign with 9x ROAS in 3 months</p></div>
      </div>
      <div class="port-card port-item" data-cat="social">
        <div class="port-thumb" style="background:linear-gradient(135deg,#E1306C,#833AB4)">
          <div class="pt-icon"><i class="fa-brands fa-instagram" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Instagram Growth</h4><p>0 to 50K Followers in 4 months</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Social Media</div><p>Fashion brand Instagram account managed to explosive growth</p></div>
      </div>
      <div class="port-card port-item" data-cat="seo">
        <div class="port-thumb" style="background:linear-gradient(135deg,#10B981,#059669)">
          <div class="pt-icon"><i class="fa-solid fa-location-dot" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Local SEO - Restaurant</h4><p>#1 on Google Maps in 90 Days</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Local SEO</div><p>Restaurant ranked #1 for 8 local keywords, 40% more footfall</p></div>
      </div>
      <div class="port-card port-item" data-cat="web">
        <div class="port-thumb" style="background:linear-gradient(135deg,#F59E0B,#EF4444)">
          <div class="pt-icon"><i class="fa-solid fa-mobile-screen" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Mobile App Development</h4><p>10K+ Downloads in First Month</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">App Dev</div><p>React Native delivery app with real-time tracking and payments</p></div>
      </div>
    </div>
  </div>
</section>

<footer class="footer" id="footer" aria-label="Footer">
  <div class="footer-main container">
    <div class="footer-grid">

      <!-- Brand Column -->
      <div class="footer-brand">
        <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="260" height="74" class="logo-img"></a>
        <div class="footer-brand-tagline">Grow &bull; Rank &bull; Convert</div>
        <div class="footer-brand-services">SEO | Digital Marketing | Website Development</div>
        <p>India's trusted digital marketing agency helping businesses grow online with proven, data-driven strategies and dedicated round-the-clock support.</p>
        <div class="footer-brand-contacts">
          <a href="tel:+918512821525" class="fbc-item"><i class="fa-solid fa-phone"></i> +91 8512821525</a>
          <a href="mailto:onedigiweb@gmail.com" class="fbc-item"><i class="fa-solid fa-envelope"></i> onedigiweb@gmail.com</a>
          <a href="https://wa.me/918512821525" class="fbc-item" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp: +91 8512821525</a>
        </div>
        <div class="footer-socials">
          <a href="https://www.facebook.com/onedigiweb" target="_blank" class="fs-link fs-fb" title="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="https://www.instagram.com/onedigiweb" target="_blank" class="fs-link fs-ig" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://www.linkedin.com/company/onedigiweb" target="_blank" class="fs-link fs-li" title="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
          <a href="https://www.youtube.com/@onedigiweb" target="_blank" class="fs-link fs-yt" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
          <a href="https://wa.me/918512821525" target="_blank" class="fs-link fs-wa" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
        </div>
      </div>

      <!-- Quick Links -->
      <div class="footer-col">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="index.html#home"><i class="fa-solid fa-house fa-xs"></i> Home</a></li>
          <li><a href="index.html#services"><i class="fa-solid fa-briefcase fa-xs"></i> Services</a></li>
          <li><a href="index.html#pricing"><i class="fa-solid fa-tags fa-xs"></i> Pricing</a></li>
          <li><a href="index.html#portfolio"><i class="fa-solid fa-images fa-xs"></i> Portfolio</a></li>
          <li><a href="index.html#contact"><i class="fa-solid fa-envelope fa-xs"></i> Contact</a></li>
        </ul>
      </div>

      <!-- Services Links -->
      <div class="footer-col">
        <h4>Our Services</h4>
        <ul>
          <li><a href="seo-services.html"><i class="fa-solid fa-magnifying-glass fa-xs"></i> SEO Services</a></li>
          <li><a href="google-ads-services.html"><i class="fa-brands fa-google fa-xs"></i> Google Ads</a></li>
          <li><a href="social-media-marketing.html"><i class="fa-solid fa-share-nodes fa-xs"></i> Social Media Marketing</a></li>
          <li><a href="website-development.html"><i class="fa-solid fa-laptop-code fa-xs"></i> Website Development</a></li>
          <li><a href="ecommerce-development.html"><i class="fa-solid fa-cart-shopping fa-xs"></i> Ecommerce Development</a></li>
          <li><a href="app-development.html"><i class="fa-solid fa-mobile-screen fa-xs"></i> App Development</a></li>
          <li><a href="graphic-design-services.html"><i class="fa-solid fa-pen-nib fa-xs"></i> Graphic Design</a></li>
          <li><a href="lead-generation-services.html"><i class="fa-solid fa-chart-line fa-xs"></i> Lead Generation</a></li>
        </ul>
      </div>

      <!-- Contact + CTA -->
      <div class="footer-col">
        <h4>Contact Us</h4>
        <ul class="fc-contact">
          <li><a href="mailto:onedigiweb@gmail.com"><i class="fa-solid fa-envelope"></i> onedigiweb@gmail.com</a></li>
          <li><a href="tel:+918512821525"><i class="fa-solid fa-phone"></i> +91 8512821525</a></li>
          <li><a href="https://wa.me/918512821525" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a></li>
          <li><span><i class="fa-solid fa-clock"></i> Mon&ndash;Sat: 9AM&ndash;7PM</span></li>
        </ul>
        <button onclick="document.getElementById('quotePopup').style.display='flex'" class="footer-cta">
          <i class="fa-solid fa-rocket"></i> Get Free Quote
        </button>
      </div>
    </div>
  </div>

  <!-- Footer Bottom -->
  <div class="footer-bottom">
    <div class="container footer-bottom-inner">
      <p>&copy; 2026 ONEDIGIWEB Marketing Solution. All Rights Reserved.</p>
      <div class="footer-policy-links">
        <a href="privacy-policy.html">Privacy Policy</a>
        <span>&bull;</span>
        <a href="terms-and-conditions.html">Terms &amp; Conditions</a>
        <span>&bull;</span>
        <a href="refund-policy.html">Refund Policy</a>
        <span>&bull;</span>
        <a href="disclaimer.html">Disclaimer</a>
        <span>&bull;</span>
        <a href="about-us.html">About Us</a>
      </div>
    </div>
  </div>
</footer>

<!-- END COMPONENT: FOOTER -->
<!-- COMPONENT: POPUPS -->
<!-- Floating Glass FABs (Desktop/Mobile) -->
<div class="glass-fabs" id="glassFabs">
  <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." class="gfab gfab-wa" target="_blank" title="WhatsApp">
    <div class="gfab-pulse"></div>
    <i class="fa-brands fa-whatsapp" style="font-size:22px"></i>
    <span>WhatsApp</span>
  </a>
  <a href="tel:+918512821525" class="gfab gfab-call" title="Call Now">
    <i class="fa-solid fa-phone" style="font-size:18px"></i>
    <span>Call Now</span>
  </a>
  <button class="gfab gfab-top" id="backTop" onclick="window.scrollTo({top:0,behavior:'smooth'})" title="Back to Top">
    <i class="fa-solid fa-chevron-up" style="font-size:16px"></i>
    <span>Back to Top</span>
  </button>
</div>

<!-- Mobile Sticky Bar -->
<div class="mobile-sticky-bar" id="mobileStickyBar">
  <a href="tel:+918512821525" class="msb-btn msb-call"><i class="fa-solid fa-phone"></i> Call Now</a>
  <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." class="msb-btn msb-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
  <button class="msb-btn msb-quote open-quote-trigger"><i class="fa-solid fa-file-invoice"></i> Get Quote</button>
</div>

<!-- Free Strategy Session Popup -->
<div class="popup-overlay quote-popup-overlay" id="quotePopup" style="display:none" role="dialog" aria-modal="true" aria-label="Free Strategy Session Form">
  <div class="nq-popup-box">
    <button class="popup-x" id="closeQuotePopup"><i class="fa-solid fa-xmark"></i></button>
    <div class="nq-header">
      <div class="nq-label">FREE SEO CONSULTATION</div>
      <div class="nq-icon-wrap"><i class="fa-solid fa-chart-column"></i></div>
    </div>
    <h3 class="nq-title">Ready to rank higher?</h3>
    
    <form class="nq-form" id="quoteForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
      <input type="hidden" name="_subject" value="New Lead - FREE SEO Consultation Request" />
      <input type="hidden" name="_captcha" value="false" />
      <input type="hidden" name="_template" value="table" />
      <input type="hidden" name="_next" value="https://onedigiweb.com/thank-you.html" />
      <input type="text" name="_honey" style="display:none" />
      <input type="hidden" name="Submission Date & Time" class="sub-date-time-field" value="" />
      
      <div class="nq-field">
        <input type="text" id="qfName" name="Name" placeholder="Name" required />
      </div>
      <div class="nq-field">
        <input type="email" id="qfEmail" name="Email" placeholder="Email" required />
      </div>
      <div class="nq-field">
        <input type="tel" id="qfPhone" name="Mobile Number" placeholder="Phone" required />
      </div>
      <div class="nq-field">
        <input type="url" id="qfWebsite" name="Website" placeholder="Website" />
      </div>
      
      <button type="submit" class="nq-submit" id="qfSubmitBtn">
        Get a Free SEO Consultation <i class="fa-solid fa-arrow-right"></i>
      </button>
      
      <div class="nq-footer-text">No pressure. No generic sales pitch.</div>
    </form>
  </div>
</div>

<!-- Success / Thank You Popup -->
<div class="popup-overlay" id="thankYouPopup" style="display:none">
  <div class="popup-box ty-popup-box" style="max-width:500px;">
    <button class="popup-x" onclick="document.getElementById('thankYouPopup').style.display='none';document.body.style.overflow=''"><i class="fa-solid fa-xmark"></i></button>
    <div class="ty-animation">
      <div class="ty-circle"><i class="fa-solid fa-check" style="font-size:36px;color:white"></i></div>
    </div>
    <h3>&#127881; Thank You!</h3>
    <p>Your request has been submitted successfully.<br>Our team will contact you shortly on your phone number or email.</p>
    <div class="ty-info">
      <div class="ty-info-item"><i class="fa-solid fa-phone" style="color:var(--accent)"></i><span>+91 8512821525</span></div>
      <div class="ty-info-item"><i class="fa-solid fa-envelope" style="color:var(--accent)"></i><span>onedigiweb@gmail.com</span></div>
      <div class="ty-info-item"><i class="fa-solid fa-clock" style="color:var(--accent)"></i><span>Response within 24 hours</span></div>
    </div>
    <div class="wpb-btns">
      <a href="https://wa.me/918512821525?text=Hi! I just claimed my free digital strategy session on ONEDIGIWEB." class="btn btn-hero-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp</a>
      <button onclick="document.getElementById('thankYouPopup').style.display='none';document.body.style.overflow=''" class="btn btn-hero-call">Close Window</button>
    </div>
  </div>
</div>

<!-- Premium Newsletter Popup -->
<div class="popup-overlay" id="newsletterPopup" style="display:none" role="dialog" aria-modal="true" aria-label="Newsletter Subscription">
  <div class="newsletter-popup-box">
    <!-- Left Side -->
    <div class="np-left">
      <div class="qp-brand">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" style="width: 200px; height: auto; max-width: 100%; object-fit: contain;">
      </div>
      <h3>Stay Updated With Digital Marketing Trends</h3>
      <p>Subscribe to receive the latest SEO tips, Google Ads updates, website development insights, exclusive offers and digital marketing news directly in your inbox.</p>
    </div>
    <!-- Right Side -->
    <div class="np-right">
      <div class="np-card" style="position:relative;">
        <button class="qp-close" id="closeNewsletterPopup" style="top:12px; right:12px;"><i class="fa-solid fa-xmark"></i></button>
        <form class="np-form" id="newsletterPopupForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
          <input type="hidden" name="_subject" value="New Subscriber - Premium Newsletter | ONEDIGIWEB" />
          <input type="hidden" name="_captcha" value="false" />
          <input type="hidden" name="_template" value="table" />
          <input type="text" name="_honey" style="display:none" />
          
          <div class="np-field">
            <label><i class="fa-solid fa-user"></i> Full Name *</label>
            <input type="text" name="Subscriber Name" placeholder="Enter your name" required />
          </div>
          <div class="np-field">
            <label><i class="fa-solid fa-envelope"></i> Email Address *</label>
            <input type="email" name="Subscriber Email" placeholder="your@email.com" required />
          </div>
          <div class="np-field">
            <label><i class="fa-solid fa-phone"></i> Mobile Number (Optional)</label>
            <input type="tel" name="Subscriber Phone" placeholder="Enter mobile number" />
          </div>
          <button type="submit" class="np-submit" style="border:none; width: 100%;">Subscribe Now</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- END COMPONENT: POPUPS -->

<script src="script.js"></script>

1
</html>














