﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- ============================================================
       MARKETING INTEGRATIONS (Analytics, AdSense, Pinterest, Ads)
  ============================================================ -->
  <!-- Google Tag (gtag.js) - Google Analytics & Google Ads -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-XXXXXXXXXX'); // Replace with Google Analytics Measurement ID
    gtag('config', 'AW-YYYYYYYYY');  // Replace with Google Ads Conversion ID
  </script>

  <!-- Google AdSense -->
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-ZZZZZZZZZZZZZZZZ" crossorigin="anonymous"></script>

  <!-- Pinterest Tag -->
  <script>
    !function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(Array.prototype.slice.call(arguments))};var n=window.pintrk;n.queue=[],n.version="3.0";var t=document.createElement("script");t.async=!0,t.src=e;var r=document.getElementsByTagName("script")[0];r.parentNode.insertBefore(t,r)}}("https://s.pinterest.com/js/pinit.js");
    pintrk('load', 'PARTNER_ID'); // Replace with Pinterest Partner ID
    pintrk('page');
  </script>
  <noscript>
    <img height="1" width="1" style="display:none;" alt="" src="https://ct.pinterest.com/v3/?event=init&tid=PARTNER_ID&noscript=1" />
  </noscript>
  <!-- ============================================================ -->

  <!-- Primary SEO -->
  
  <meta name="description" content="ONEDIGIWEB Marketing Solution - Best Digital Marketing Agency in India. SEO Services, Google Ads, Social Media Marketing, Website Development, App Development &amp; Lead Generation." />
  <meta name="keywords" content="digital marketing agency India, SEO company India, Google Ads agency, social media marketing, website development company, app development, lead generation, ONEDIGIWEB" />
  <meta name="robots" content="index, follow" />
  <meta name="author" content="ONEDIGIWEB Marketing Solution" />
  <meta name="theme-color" content="#6D28D9" />
  <link rel="canonical" href="https://onedigiweb.com/" />

  <!-- Favicons -->
  <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" />
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-32x32.png" />
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-16x16.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/apple-touch-icon.png" />
  <link rel="manifest" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/site.webmanifest" />

  <!-- Open Graph -->
  <meta property="og:title" content="ONEDIGIWEB Marketing Solution | Digital Marketing Agency India" />
  <meta property="og:description" content="Best Digital Marketing Agency in India - SEO, Google Ads, Social Media, Website Development &amp; More." />
  <meta property="og:image" content="assets/images/og-image.png" />
  <meta property="og:image:width" content="1200" />
  <meta property="og:image:height" content="630" />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="ONEDIGIWEB Marketing Solution" />
  <meta property="og:locale" content="en_IN" />

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="ONEDIGIWEB Marketing Solution" />
  <meta name="twitter:description" content="Best Digital Marketing Agency in India - SEO, Google Ads, Website Development &amp; More." />
  <meta name="twitter:image" content="assets/images/og-image.png" />

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Font Awesome 6 Pro (Free CDN) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" />

  <!-- Stylesheet -->
  <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>" />

  <!-- Structured Data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "ONEDIGIWEB Marketing Solution",
    "description": "Best Digital Marketing Agency in India offering SEO, Google Ads, Social Media Marketing, Website Development, App Development and Graphic Design.",
    "email": "onedigiweb@gmail.com",
    "telephone": "+918512821525",
    "openingHours": "Mo-Sa 09:00-19:00",
    "priceRange": "Rs.Rs.",
    "image": "assets/images/onedigiweb-marketing-solution-logo.png",
    "address": { "@type": "PostalAddress", "addressCountry": "IN" },
    "sameAs": ["https://wa.me/918512821525"]
  }
  </script>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {"@type":"Question","name":"How long does SEO take?","acceptedAnswer":{"@type":"Answer","text":"Usually 3-6 months for significant results depending on competition and website quality."}},
      {"@type":"Question","name":"Do you provide ongoing support?","acceptedAnswer":{"@type":"Answer","text":"Yes, 24/7 dedicated support via WhatsApp, email and phone for all clients."}},
      {"@type":"Question","name":"Can you redesign my existing website?","acceptedAnswer":{"@type":"Answer","text":"Yes, we offer complete website redesign and development services with modern, mobile-first design."}},
      {"@type":"Question","name":"What is your minimum project budget?","acceptedAnswer":{"@type":"Answer","text":"Our services start from Rs.9,999/month. We offer flexible plans for businesses of all sizes."}}
    ]
  }
  </script>
<?php wp_head(); ?>
</head>
<body>



<!-- ============================================================
     HEADER / MEGA NAV
============================================================ -->
<!-- COMPONENT: HEADER -->
<header class="header" id="header">
  <nav class="navbar container">

    <!-- Logo -->
    <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="260" height="74" class="logo-img"></a>

    <!-- Nav Menu -->
    <ul class="nav-menu" id="navMenu" role="menubar">
      <li class="nav-item"><a href="#home" class="nav-link active" role="menuitem">Home</a></li>
      <li class="nav-item has-mega">
        <a href="#services" class="nav-link nav-link-arrow" role="menuitem">Services</a>
                        <div class="mega-menu tabbed-mega-menu" role="menu">
          <div class="mega-inner container">
            
            <!-- Top Category Tabs -->
            <div class="tmm-tabs-container">
              <div class="tmm-tabs">
                <button class="tmm-tab active" data-target="tmm-seo"><i class="fa-solid fa-magnifying-glass"></i> SEO Services</button>
                <button class="tmm-tab" data-target="tmm-dm"><i class="fa-solid fa-bullhorn"></i> Digital Marketing</button>
                <button class="tmm-tab" data-target="tmm-web"><i class="fa-solid fa-code"></i> Website Development</button>
                <button class="tmm-tab" data-target="tmm-app"><i class="fa-solid fa-mobile-screen"></i> App Marketing</button>
                <button class="tmm-tab" data-target="tmm-cm"><i class="fa-solid fa-pen-nib"></i> Content Marketing</button>
                <button class="tmm-tab" data-target="tmm-ppc"><i class="fa-solid fa-mouse-pointer"></i> Google Ads / PPC</button>
                <button class="tmm-tab" data-target="tmm-ar"><i class="fa-solid fa-chart-pie"></i> Analytics & Reporting</button>
                <button class="tmm-tab" data-target="tmm-gd"><i class="fa-solid fa-bezier-curve"></i> Graphic Design</button>
                <button class="tmm-tab" data-target="tmm-sd"><i class="fa-solid fa-laptop-code"></i> Software Development</button>
              </div>
            </div>

            <div class="tmm-body">
              <!-- Left side: Services List -->
              <div class="tmm-content-area">
                
                <!-- SEO -->
                <div class="tmm-content active" id="tmm-seo">
                  <div class="tmm-links-grid">
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>SEO Services</span></a>
                    <a href="local-seo-services.html" class="tmm-link"><i class="fa-solid fa-map-location-dot"></i><span>Local SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-gears"></i><span>Technical SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-cart-arrow-down"></i><span>Ecommerce SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Enterprise SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-robot"></i><span>AI SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-stethoscope"></i><span>SEO audit</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-link"></i><span>Link Building</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-triangle-exclamation"></i><span>Google Penalty Recovery</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-truck-fast"></i><span>SEO Migration</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-language"></i><span>Multilingual SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-globe"></i><span>International SEO</span></a>
                  </div>
                </div>

                <!-- Digital Marketing -->
                <div class="tmm-content" id="tmm-dm">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-brands fa-google"></i><span>Google Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-meta"></i><span>Meta Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-youtube"></i><span>YouTube Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-instagram"></i><span>Instagram Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-facebook"></i><span>Facebook Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-linkedin"></i><span>LinkedIn Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope-open-text"></i><span>Email Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-bullhorn"></i><span>Content Marketing</span></a>
                    <a href="lead-generation-services.html" class="tmm-link"><i class="fa-solid fa-magnet"></i><span>Lead Generation</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-shield-halved"></i><span>Online Reputation Management</span></a>
                  </div>
                </div>

                <!-- Website Development -->
                <div class="tmm-content" id="tmm-web">
                  <div class="tmm-links-grid">
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Business Website</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building-user"></i><span>Corporate Website</span></a>
                    <a href="wordpress-development.html" class="tmm-link"><i class="fa-brands fa-wordpress"></i><span>WordPress</span></a>
                    <a href="ecommerce-development.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Ecommerce Website</span></a>
                    <a href="shopify-development.html" class="tmm-link"><i class="fa-brands fa-shopify"></i><span>Shopify</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-react"></i><span>React</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-n"></i><span>Next.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-laravel"></i><span>Laravel</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-php"></i><span>Custom PHP</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-node-js"></i><span>Node.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-screwdriver-wrench"></i><span>Website Maintenance</span></a>
                  </div>
                </div>

                <!-- App Marketing -->
                <div class="tmm-content" id="tmm-app">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>App Store Optimization</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-download"></i><span>App Install Campaigns</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-star"></i><span>App Reviews & Ratings</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-chart-line"></i><span>App Analytics</span></a>
                  </div>
                </div>

                <!-- Content Marketing -->
                <div class="tmm-content" id="tmm-cm">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-pen-fancy"></i><span>Blog Writing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-file-lines"></i><span>Copywriting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-video"></i><span>Video Scripting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope"></i><span>Newsletter Writing</span></a>
                  </div>
                </div>

                <!-- Google Ads / PPC -->
                <div class="tmm-content" id="tmm-ppc">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-dollar"></i><span>Search Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Display Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Shopping Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-rotate-left"></i><span>Remarketing</span></a>
                  </div>
                </div>

                <!-- Analytics & Reporting -->
                <div class="tmm-content" id="tmm-ar">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-pie"></i><span>Google Analytics 4</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-column"></i><span>Custom Dashboards</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-filter"></i><span>Conversion Tracking</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>Data Audits</span></a>
                  </div>
                </div>

                <!-- Graphic Design -->
                <div class="tmm-content" id="tmm-gd">
                  <div class="tmm-links-grid">
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-bezier-curve"></i><span>Logo Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-award"></i><span>Brand Identity</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-object-group"></i><span>UI/UX Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Social Media Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-rectangle-list"></i><span>Banner Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-book-open"></i><span>Brochure Design</span></a>
                  </div>
                </div>

                <!-- Software Development -->
                <div class="tmm-content" id="tmm-sd">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-laptop-code"></i><span>Custom Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-users-gear"></i><span>CRM Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-network-wired"></i><span>ERP Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-android"></i><span>Android App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-apple"></i><span>iOS App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>Flutter App</span></a>
                  </div>
                </div>
              </div>

              <!-- Right Side CTA Card -->
              <div class="tmm-cta">
                <div class="tmm-cta-card">
                  <div class="tmm-cta-title">Grow Your Business with ONEDIGIWEB</div>
                  <div class="tmm-cta-bullets">
                    <span><i class="fa-solid fa-check"></i> Free Consultation</span>
                    <span><i class="fa-solid fa-check"></i> Expert Team</span>
                    <span><i class="fa-solid fa-check"></i> Custom Strategy</span>
                    <span><i class="fa-solid fa-check"></i> Transparent Pricing</span>
                  </div>
                  <div class="tmm-cta-actions">
                    <button class="btn btn-tmm-quote open-quote-trigger" onclick="document.getElementById('quotePopup').style.display='flex'">Get Free Quote</button>
                    <a href="https://wa.me/918512821525" class="btn btn-tmm-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a>
                  </div>
                  <div class="tmm-cta-footer"><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 100+ Projects</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 24x7 Support</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> Fast Delivery</span></div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </li>
      <li class="nav-item"><a href="#pricing" class="nav-link" role="menuitem">Pricing</a></li>
      <li class="nav-item"><a href="#portfolio" class="nav-link" role="menuitem">Portfolio</a></li>
      <li class="nav-item"><a href="#contact" class="nav-link" role="menuitem">Contact</a></li>
    </ul>

    <!-- Nav CTA -->
    <div class="nav-cta">
      <a href="tel:+918512821525" class="nav-cta-call">
        <i class="fa-solid fa-phone"></i> +91 8512821525
      </a>
      <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." target="_blank" class="nav-cta-wa">
        <i class="fa-brands fa-whatsapp"></i> WhatsApp
      </a>
      <button class="nav-cta-quote open-quote-trigger">
        <i class="fa-solid fa-rocket"></i> Free Consultation
      </button>
    </div>

    <!-- Hamburger -->
    <button class="hamburger" id="hamburger" aria-label="Toggle Menu" aria-expanded="false">
      <span class="ham-line"></span>
      <span class="ham-line"></span>
      <span class="ham-line"></span>
    </button>
  </nav>
</header>

<!-- END COMPONENT: HEADER -->

<!-- Mobile nav overlay -->
<div class="nav-overlay" id="navOverlay"></div>

<!-- ============================================================
     HERO SECTION
============================================================ -->
<section class="hero" id="home" aria-label="Hero Banner">
  <canvas class="hero-canvas" id="heroCanvas"></canvas>
  <div class="hero-glow hero-glow-1"></div>
  <div class="hero-glow hero-glow-2"></div>
  <div class="hero-glow hero-glow-3"></div>
  <div class="hero-grid-overlay"></div>

  <!-- Hero Slider Main Wrapper -->
  <div class="hero-slider-container" id="heroSliderContainer">
    <div class="hero-slides-wrapper" id="heroSlidesWrapper">
      <!-- Slide 1 -->
      <div class="hero-slide active" data-index="0">
        <div class="container hero-container">
          <div class="hero-left">
            <div class="hero-badge" style="background: rgba(6,182,212,0.15); border-color: rgba(6,182,212,0.3); color: #06B6D4;">
              <span class="hb-dot" style="background:#06B6D4;"></span>
              <span>SEO Services</span>
            </div>
            <h1 class="hero-title" style="margin-bottom:12px;">
              Grow Your Business With <span class="grad-hero-text">Smart Digital Marketing</span>
            </h1>
            <h2 class="hero-sub" style="font-weight:700; font-size:1.35rem; letter-spacing:1px; color:#ffffff; opacity:0.95; margin-bottom:28px;">
              Rank Higher on Google &amp; Generate More Leads
            </h2>
            <div class="hero-ctas">
              <button class="btn btn-hero-primary open-quote-trigger" style="border-radius:12px; background:#5B21B6; color:#fff;">
                <i class="fa-solid fa-rocket"></i> Get Free Consultation
              </button>
              <a href="#services" class="btn btn-hero-call" style="border-radius:12px; background:#fff; color:#5B21B6; border:1px solid #E2E8F0;">
                View Services
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- Slide 2 -->
      <div class="hero-slide" data-index="1">
        <div class="container hero-container">
          <div class="hero-left">
            <div class="hero-badge" style="background: rgba(79,70,229,0.15); border-color: rgba(79,70,229,0.3); color: #818cf8;">
              <span class="hb-dot" style="background:#818cf8;"></span>
              <span>Website Development</span>
            </div>
            <h1 class="hero-title" style="margin-bottom:12px;">
              Grow Your Business With <span class="grad-hero-text">Smart Digital Marketing</span>
            </h1>
            <h2 class="hero-sub" style="font-weight:700; font-size:1.35rem; letter-spacing:1px; color:#ffffff; opacity:0.95; margin-bottom:28px;">
              Professional Websites That Convert Visitors Into Customers
            </h2>
            <div class="hero-ctas">
              <button class="btn btn-hero-primary open-quote-trigger" style="border-radius:12px; background:#5B21B6; color:#fff;">
                <i class="fa-solid fa-rocket"></i> Get Free Consultation
              </button>
              <a href="#services" class="btn btn-hero-call" style="border-radius:12px; background:#fff; color:#5B21B6; border:1px solid #E2E8F0;">
                View Services
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- Slide 3 -->
      <div class="hero-slide" data-index="2">
        <div class="container hero-container">
          <div class="hero-left">
            <div class="hero-badge" style="background: rgba(6,182,212,0.15); border-color: rgba(6,182,212,0.3); color: #06B6D4;">
              <span class="hb-dot" style="background:#06B6D4;"></span>
              <span>Digital Marketing</span>
            </div>
            <h1 class="hero-title" style="margin-bottom:12px;">
              Grow Your Business With <span class="grad-hero-text">Smart Digital Marketing</span>
            </h1>
            <h2 class="hero-sub" style="font-weight:700; font-size:1.35rem; letter-spacing:1px; color:#ffffff; opacity:0.95; margin-bottom:28px;">
              Grow Your Business With Data-Driven Marketing
            </h2>
            <div class="hero-ctas">
              <button class="btn btn-hero-primary open-quote-trigger" style="border-radius:12px; background:#5B21B6; color:#fff;">
                <i class="fa-solid fa-rocket"></i> Get Free Consultation
              </button>
              <a href="#services" class="btn btn-hero-call" style="border-radius:12px; background:#fff; color:#5B21B6; border:1px solid #E2E8F0;">
                View Services
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- Slide 4 -->
      <div class="hero-slide" data-index="3">
        <div class="container hero-container">
          <div class="hero-left">
            <div class="hero-badge" style="background: rgba(79,70,229,0.15); border-color: rgba(79,70,229,0.3); color: #818cf8;">
              <span class="hb-dot" style="background:#818cf8;"></span>
              <span>Google Ads</span>
            </div>
            <h1 class="hero-title" style="margin-bottom:12px;">
              Grow Your Business With <span class="grad-hero-text">Smart Digital Marketing</span>
            </h1>
            <h2 class="hero-sub" style="font-weight:700; font-size:1.35rem; letter-spacing:1px; color:#ffffff; opacity:0.95; margin-bottom:28px;">
              Get Instant Traffic &amp; High Quality Leads
            </h2>
            <div class="hero-ctas">
              <button class="btn btn-hero-primary open-quote-trigger" style="border-radius:12px; background:#5B21B6; color:#fff;">
                <i class="fa-solid fa-rocket"></i> Get Free Consultation
              </button>
              <a href="#services" class="btn btn-hero-call" style="border-radius:12px; background:#fff; color:#5B21B6; border:1px solid #E2E8F0;">
                View Services
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Dots Indicator (Required for JS) -->
    <div class="hero-dots" id="heroDots" style="display: none;">
      <span class="hero-dot active" data-index="0"></span>
      <span class="hero-dot" data-index="1"></span>
      <span class="hero-dot" data-index="2"></span>
      <span class="hero-dot" data-index="3"></span>
    </div>
  </div>
  <!-- Static Form Overlay Right Side -->
  <div class="hero-static-form-wrapper">
    <div class="container hero-form-container">
      <div class="hero-form-card">
          <div class="hfc-header">
            <div class="hfc-title"><i class="fa-solid fa-bolt" style="color:var(--p1); margin-right:5px;"></i> Instant Consultation</div>
            <div class="hfc-subtitle">Fill in details for a call-back within 30 minutes.</div>
          </div>
          <form class="hfc-form" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST" id="heroLeadForm">
            <input type="hidden" name="_subject" value="New Lead - Hero Section | ONEDIGIWEB">
            <input type="hidden" name="_captcha" value="false">
            <input type="hidden" name="_template" value="table">
            <input type="text" name="_honey" style="display:none">
            <input type="text" name="name" class="hfc-input" placeholder="Full Name" required>
            <input type="tel" name="phone" class="hfc-input" placeholder="Phone Number (10 Digits)" pattern="[0-9]{10}" required>
            <input type="email" name="email" class="hfc-input" placeholder="Email Address" required>
            <select name="service" class="hfc-input hfc-select" required>
              <option value="" disabled selected>Select Required Service</option>
              <option value="seo">SEO Services</option>
              <option value="web">Website Development</option>
              <option value="ads">Google & Meta Ads</option>
              <option value="social">Social Media Marketing</option>
              <option value="other">Other Digital Services</option>
            </select>
            <button type="submit" class="hfc-submit"><i class="fa-solid fa-bolt"></i> Get Instant Quote</button>
          </form>
          <div class="hfc-footer">
            <i class="fa-solid fa-shield-halved" style="color:var(--p2);"></i> 
            <span>We respect your privacy. By submitting, you agree to our <a href="privacy-policy.html">Privacy Policy</a>.</span>
          </div>
        </div>
      </div>
    </div>
  </div>



</section>

<!-- ============================================================
     TRUST BAR - Trusted By Businesses
============================================================ -->
<div class="trust-bar">
  <div class="container trust-bar-inner">
    <span class="tb-label">Trusted By</span>
    <div class="tb-items">
      <div class="tb-item"><i class="fa-solid fa-building"></i> Startups</div>
      <div class="tb-sep">&bull;</div>
      <div class="tb-item"><i class="fa-solid fa-store"></i> Local Businesses</div>
      <div class="tb-sep">&bull;</div>
      <div class="tb-item"><i class="fa-solid fa-chart-pie"></i> Growing Brands</div>
      <div class="tb-sep">&bull;</div>
      <div class="tb-item"><i class="fa-solid fa-cart-shopping"></i> Ecommerce Stores</div>
      <div class="tb-sep">&bull;</div>
      <div class="tb-item"><i class="fa-solid fa-hospital"></i> Clinics &amp; Hospitals</div>
      <div class="tb-sep">&bull;</div>
      <div class="tb-item"><i class="fa-solid fa-graduation-cap"></i> Educational Institutes</div>
      <div class="tb-sep">&bull;</div>
      <div class="tb-item"><i class="fa-solid fa-hotel"></i> Hotels &amp; Resorts</div>
    </div>
    <div class="tb-rating">
      <span class="tb-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span>
      <span class="tb-rating-text">Google Rated Agency</span>
    </div>
  </div>
</div>

<!-- ============================================================
     COUNTER SECTION
============================================================ -->
<section class="counter-section" id="stats" aria-label="Statistics">
  <div class="container">
    <div class="counter-grid">
      <div class="counter-card" data-count="500" data-suffix="+">
        <div class="cc-icon"><i class="fa-solid fa-rocket"></i></div>
        <div class="cc-number" id="c1">0+</div>
        <div class="cc-label">Projects Completed</div>
        <div class="cc-bar"></div>
      </div>
      <div class="counter-card" data-count="250" data-suffix="+">
        <div class="cc-icon"><i class="fa-solid fa-face-smile"></i></div>
        <div class="cc-number" id="c2">0+</div>
        <div class="cc-label">Happy Clients</div>
        <div class="cc-bar"></div>
      </div>
      <div class="counter-card" data-count="98" data-suffix="%">
        <div class="cc-icon"><i class="fa-solid fa-gem"></i></div>
        <div class="cc-number" id="c3">0%</div>
        <div class="cc-label">Client Satisfaction</div>
        <div class="cc-bar"></div>
      </div>
      <div class="counter-card">
        <div class="cc-icon"><i class="fa-solid fa-clock"></i></div>
        <div class="cc-number">24/7</div>
        <div class="cc-label">Support Available</div>
        <div class="cc-bar"></div>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     OUR SERVICES
============================================================ -->
<section class="section services-preview" id="services" aria-label="Our Services">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Our Services</div>
      <h2 class="section-heading">Complete <span class="grad-text">Digital Solutions</span><br/>For Your Business</h2>
      <p class="section-sub">Everything you need to dominate online &mdash; under one roof</p>
    </div>
    <div class="sp-grid">
      <a href="seo-services.html" class="sp-card" id="seo">
        <div class="sp-glow"></div>
        <div class="sp-icon-wrap"><i class="fa-solid fa-magnifying-glass-chart"></i></div>
        <h3>SEO Services</h3>
        <p>Rank higher on Google &amp; drive organic traffic with proven SEO strategies</p>
        <div class="sp-tags"><span>Local SEO</span><span>Technical SEO</span><span>Link Building</span></div>
        <div class="sp-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      </a>
      <a href="social-media-marketing.html" class="sp-card" id="smm">
        <div class="sp-glow"></div>
        <div class="sp-icon-wrap"><i class="fa-solid fa-share-nodes"></i></div>
        <h3>Social Media Marketing</h3>
        <p>Build brand presence on Instagram, Facebook, LinkedIn &amp; grow your audience</p>
        <div class="sp-tags"><span>Instagram</span><span>Facebook</span><span>LinkedIn</span></div>
        <div class="sp-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      </a>
      <a href="website-development.html" class="sp-card" id="website-dev">
        <div class="sp-glow"></div>
        <div class="sp-icon-wrap"><i class="fa-solid fa-laptop-code"></i></div>
        <h3>Website Development</h3>
        <p>Fast, mobile-first, conversion-optimized websites that generate leads 24/7</p>
        <div class="sp-tags"><span>WordPress</span><span>Custom</span><span>Landing Pages</span></div>
        <div class="sp-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      </a>
      <a href="ecommerce-development.html" class="sp-card" id="ecommerce">
        <div class="sp-glow"></div>
        <div class="sp-icon-wrap"><i class="fa-solid fa-cart-shopping"></i></div>
        <h3>Ecommerce Development</h3>
        <p>Powerful online stores with seamless shopping experience &amp; payment integration</p>
        <div class="sp-tags"><span>WooCommerce</span><span>Shopify</span><span>Custom</span></div>
        <div class="sp-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      </a>
      <a href="google-ads-services.html" class="sp-card" id="google-ads">
        <div class="sp-glow"></div>
        <div class="sp-icon-wrap"><i class="fa-brands fa-google"></i></div>
        <h3>Google Ads / PPC</h3>
        <p>Get instant targeted traffic &amp; maximum ROI with Google Ads campaigns</p>
        <div class="sp-tags"><span>Search Ads</span><span>Display</span><span>Shopping</span></div>
        <div class="sp-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      </a>
      <a href="app-development.html" class="sp-card" id="app-dev">
        <div class="sp-glow"></div>
        <div class="sp-icon-wrap"><i class="fa-solid fa-mobile-screen"></i></div>
        <h3>App Development</h3>
        <p>Native iOS &amp; Android apps and cross-platform solutions for your business</p>
        <div class="sp-tags"><span>iOS</span><span>Android</span><span>React Native</span></div>
        <div class="sp-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      </a>
      <a href="graphic-design-services.html" class="sp-card" id="graphic">
        <div class="sp-glow"></div>
        <div class="sp-icon-wrap"><i class="fa-solid fa-pen-nib"></i></div>
        <h3>Graphic Design</h3>
        <p>Professional logo, brand identity, social media graphics &amp; marketing materials</p>
        <div class="sp-tags"><span>Logo Design</span><span>Branding</span><span>Social Media</span></div>
        <div class="sp-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      </a>
      <a href="lead-generation-services.html" class="sp-card" id="leads">
        <div class="sp-glow"></div>
        <div class="sp-icon-wrap"><i class="fa-solid fa-indian-rupee-sign"></i></div>
        <h3>Lead Generation</h3>
        <p>Get high-quality leads that convert into real paying customers for your business</p>
        <div class="sp-tags"><span>B2B Leads</span><span>B2C Leads</span><span>CRM</span></div>
        <div class="sp-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      </a>
    </div>
  </div>
</section>



<!-- ============================================================
     WHY CHOOSE US
============================================================ -->
<section class="section why-section" id="why" aria-label="Why Choose ONEDIGIWEB">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Why Us</div>
      <h2 class="section-heading">Why Choose <span class="grad-text">ONEDIGIWEB?</span></h2>
      <p class="section-sub">We don't just promise results - we deliver them, backed by data and proven strategies</p>
    </div>
    <div class="why-grid">
      <div class="why-card">
        <div class="wc-icon"><i class="fa-solid fa-chart-line"></i></div>
        <h3>Data-Driven Results</h3>
        <p>Every decision is backed by analytics. We track, measure and optimize for maximum ROI.</p>
      </div>
      <div class="why-card">
        <div class="wc-icon"><i class="fa-solid fa-certificate"></i></div>
        <h3>Certified Experts</h3>
        <p>Google, Meta &amp; HubSpot certified professionals with 5+ years of hands-on experience.</p>
      </div>
      <div class="why-card">
        <div class="wc-icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
        <h3>Fast Turnaround</h3>
        <p>Quick delivery without compromising quality. Launch your campaigns within 48 hours.</p>
      </div>
      <div class="why-card">
        <div class="wc-icon"><i class="fa-solid fa-headset"></i></div>
        <h3>24/7 Support</h3>
        <p>WhatsApp, email &amp; phone support available 24/7. We're always here when you need us.</p>
      </div>
      <div class="why-card">
        <div class="wc-icon"><i class="fa-solid fa-indian-rupee-sign"></i></div>
        <h3>Affordable Pricing</h3>
        <p>Premium quality digital services at competitive pricing with no hidden charges.</p>
      </div>
      <div class="why-card">
        <div class="wc-icon"><i class="fa-solid fa-handshake"></i></div>
        <h3>Transparent Reporting</h3>
        <p>Detailed monthly reports with clear metrics. Know exactly what we're doing &amp; why.</p>
      </div>
      <div class="why-card">
        <div class="wc-icon"><i class="fa-solid fa-mobile-screen-button"></i></div>
        <h3>Mobile-First Design</h3>
        <p>All our websites and campaigns are built mobile-first for maximum reach and conversions.</p>
      </div>
      <div class="why-card">
        <div class="wc-icon"><i class="fa-solid fa-shield-halved"></i></div>
        <h3>100% Satisfaction</h3>
        <p>98% client retention rate. We work until you're completely satisfied with the results.</p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     CLIENT LOGOS
============================================================ -->
<section class="section client-logos" id="clients" aria-label="Our Trusted Clients" style="padding: 40px 0; background: var(--light); overflow: hidden;">
  <div class="container">
    <p class="section-sub" style="text-align:center; margin-bottom:20px; font-weight: 600;">Trusted by 250+ Innovative Companies</p>
    <div class="marquee-wrapper">
      <div class="marquee-content">
        <div class="m-logo"><i class="fa-brands fa-amazon"></i><span>Amazon</span></div>
        <div class="m-logo"><i class="fa-brands fa-apple"></i><span>Apple</span></div>
        <div class="m-logo"><i class="fa-brands fa-google"></i><span>Google</span></div>
        <div class="m-logo"><i class="fa-brands fa-microsoft"></i><span>Microsoft</span></div>
        <div class="m-logo"><i class="fa-brands fa-spotify"></i><span>Spotify</span></div>
        <div class="m-logo"><i class="fa-brands fa-stripe"></i><span>Stripe</span></div>
        <div class="m-logo"><i class="fa-brands fa-slack"></i><span>Slack</span></div>
        <!-- Duplicate for loop -->
        <div class="m-logo"><i class="fa-brands fa-amazon"></i><span>Amazon</span></div>
        <div class="m-logo"><i class="fa-brands fa-apple"></i><span>Apple</span></div>
        <div class="m-logo"><i class="fa-brands fa-google"></i><span>Google</span></div>
        <div class="m-logo"><i class="fa-brands fa-microsoft"></i><span>Microsoft</span></div>
        <div class="m-logo"><i class="fa-brands fa-spotify"></i><span>Spotify</span></div>
        <div class="m-logo"><i class="fa-brands fa-stripe"></i><span>Stripe</span></div>
        <div class="m-logo"><i class="fa-brands fa-slack"></i><span>Slack</span></div>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     INDUSTRIES WE SERVE
============================================================ -->
<section class="industries-section section" id="industries" aria-label="Industries We Serve">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Industries</div>
      <h2 class="section-heading">Industries <span class="grad-text">We Serve</span></h2>
      <p class="section-sub">Tailored digital marketing and website solutions for your specific niche</p>
    </div>
    <div class="industry-grid">
      <div class="industry-card"><div class="industry-icon"><i class="fa-solid fa-house-chimney"></i></div><h3>Real Estate</h3></div>
      <div class="industry-card"><div class="industry-icon"><i class="fa-solid fa-stethoscope"></i></div><h3>Healthcare</h3></div>
      <div class="industry-card"><div class="industry-icon"><i class="fa-solid fa-cart-shopping"></i></div><h3>E-commerce</h3></div>
      <div class="industry-card"><div class="industry-icon"><i class="fa-solid fa-graduation-cap"></i></div><h3>Education</h3></div>
      <div class="industry-card"><div class="industry-icon"><i class="fa-solid fa-utensils"></i></div><h3>Restaurants</h3></div>
      <div class="industry-card"><div class="industry-icon"><i class="fa-solid fa-car"></i></div><h3>Automotive</h3></div>
      <div class="industry-card"><div class="industry-icon"><i class="fa-solid fa-plane"></i></div><h3>Travel & Tourism</h3></div>
      <div class="industry-card"><div class="industry-icon"><i class="fa-solid fa-briefcase"></i></div><h3>B2B Services</h3></div>
    </div>
  </div>
</section>

<!-- ============================================================
     OUR PROCESS
============================================================ -->
<section class="section process-section" id="process" aria-label="Our Process" style="background:var(--light);">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">How It Works</div>
      <h2 class="section-heading">Our Proven <span class="grad-text">4-Step Process</span></h2>
      <p class="section-sub">We follow a strategic approach to ensure guaranteed results for your business</p>
    </div>
    <div class="process-grid">
      <div class="process-step">
        <div class="ps-num">01</div>
        <h3>Discovery & Audit</h3>
        <p>We analyze your business, competitors, and current digital presence to identify growth opportunities.</p>
      </div>
      <div class="process-step">
        <div class="ps-num">02</div>
        <h3>Strategy & Planning</h3>
        <p>Our experts create a customized, data-driven strategy tailored to your specific goals and budget.</p>
      </div>
      <div class="process-step">
        <div class="ps-num">03</div>
        <h3>Execution</h3>
        <p>We implement the strategy across all channels - SEO, Ads, Web Dev - with precision and quality.</p>
      </div>
      <div class="process-step">
        <div class="ps-num">04</div>
        <h3>Reporting & Scaling</h3>
        <p>We track performance, provide transparent reports, and optimize campaigns to scale your ROI.</p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     TECHNOLOGY STACK
============================================================ -->
<section class="section tech-section" id="tech" aria-label="Technology Stack" style="background:var(--light);">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Technologies</div>
      <h2 class="section-heading">Our <span class="grad-text">Tech Stack</span></h2>
      <p class="section-sub">We use the latest and most reliable technologies to build your digital assets</p>
    </div>
    <div class="tech-grid">
      <div class="tech-item"><i class="fa-brands fa-wordpress"></i><span>WordPress</span></div>
      <div class="tech-item"><i class="fa-brands fa-shopify"></i><span>Shopify</span></div>
      <div class="tech-item"><i class="fa-brands fa-react"></i><span>React</span></div>
      <div class="tech-item"><i class="fa-brands fa-node-js"></i><span>Node.js</span></div>
      <div class="tech-item"><i class="fa-brands fa-php"></i><span>PHP</span></div>
      <div class="tech-item"><i class="fa-brands fa-laravel"></i><span>Laravel</span></div>
      <div class="tech-item"><i class="fa-brands fa-google"></i><span>Google Ads</span></div>
      <div class="tech-item"><i class="fa-brands fa-meta"></i><span>Meta Ads</span></div>
    </div>
  </div>
</section>

<!-- ============================================================
     DIGITAL MARKETING SERVICES (Detailed)
============================================================ -->
<section class="section dm-services" id="dm-services" aria-label="Digital Marketing Services">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Digital Marketing</div>
      <h2 class="section-heading">Our <span class="grad-text">Marketing Service</span> Packages</h2>
      <p class="section-sub">Proven digital marketing strategies tailored for Indian businesses</p>
    </div>
    <div class="dms-grid">
      <div class="dms-card">
        <div class="dms-header" style="background:linear-gradient(135deg,#5B21B6,#7C3AED)">
          <div class="dms-emoji"><i class="fa-solid fa-magnifying-glass-chart" style="font-size:28px;color:white"></i></div>
          <div><h3>SEO Services</h3><p class="dms-price">Starting &#8377;9,999/month</p></div>
        </div>
        <ul class="dms-list">
          <li>Local &amp; National SEO</li><li>Technical SEO Audit</li><li>Keyword Research &amp; Strategy</li>
          <li>On-Page &amp; Off-Page SEO</li><li>Link Building</li><li>Monthly Reports</li>
        </ul>
        <button class="dms-btn open-quote-trigger">Get Started <i class="fa-solid fa-arrow-right"></i></button>
      </div>
      <div class="dms-card">
        <div class="dms-header" style="background:linear-gradient(135deg,#E1306C,#833AB4)">
          <div class="dms-emoji"><i class="fa-solid fa-share-nodes" style="font-size:28px;color:white"></i></div>
          <div><h3>Social Media Marketing</h3><p class="dms-price">Starting &#8377;8,999/month</p></div>
        </div>
        <ul class="dms-list">
          <li>Instagram &amp; Facebook Marketing</li><li>LinkedIn Marketing</li><li>Content Creation &amp; Design</li>
          <li>Paid Social Campaigns</li><li>Community Management</li><li>Analytics Reports</li>
        </ul>
        <button class="dms-btn open-quote-trigger">Get Started <i class="fa-solid fa-arrow-right"></i></button>
      </div>
      <div class="dms-card">
        <div class="dms-header" style="background:linear-gradient(135deg,#EA4335,#FBBC04)">
          <div class="dms-emoji"><i class="fa-brands fa-google" style="font-size:28px;color:white"></i></div>
          <div><h3>Google Ads / PPC</h3><p class="dms-price">Starting &#8377;7,999/month</p></div>
        </div>
        <ul class="dms-list">
          <li>Search &amp; Display Ads</li><li>Shopping Ads</li><li>YouTube Ads</li>
          <li>Remarketing Campaigns</li><li>Conversion Tracking</li><li>ROI-Focused Strategy</li>
        </ul>
        <button class="dms-btn open-quote-trigger">Get Started <i class="fa-solid fa-arrow-right"></i></button>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     WEBSITE DEV PRICING
 ============================================================ -->
<!-- ============================================================
     PREMIUM PRICING SECTION
 ============================================================ -->
<section class="section pricing-section" id="pricing" aria-label="Pricing Plans">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Pricing Plans</div>
      <h2 class="section-heading">Affordable &amp; <span class="grad-text">Transparent Pricing</span></h2>
      <p class="section-sub">Choose a plan that fits your business goals. No hidden fees, cancel anytime.</p>
    </div>

    <!-- Pricing Tabs -->
    <div class="pricing-tabs-container">
      <div class="pricing-tabs" role="tablist">
        <button class="pricing-tab active" id="tabBtnMarketing" onclick="switchPricing('marketing')" role="tab" aria-selected="true">Digital Marketing</button>
        <button class="pricing-tab" id="tabBtnWebdev" onclick="switchPricing('webdev')" role="tab" aria-selected="false">Website Development</button>
        <button class="pricing-tab" id="tabBtnGoogleads" onclick="switchPricing('googleads')" role="tab" aria-selected="false">Google Ads</button>
      </div>
    </div>

    <!-- Digital Marketing Pricing Grid -->
    <div id="pricing-marketing" class="pricing-grid active">
      <!-- Starter Plan -->
      <div class="price-card">
        <div>
          <h3>Starter Plan</h3>
          <div class="plan-price">&#8377;9,999<span>/month</span></div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> SEO Optimization</li>
            <li><i class="fa-solid fa-circle-check"></i> Google Business Profile</li>
            <li><i class="fa-solid fa-circle-check"></i> Social Media Management</li>
            <li><i class="fa-solid fa-circle-check"></i> Monthly Report</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Get Started</button>
      </div>

      <!-- Professional Plan (Featured) -->
      <div class="price-card featured">
        <div class="plan-badge">Featured</div>
        <div>
          <h3>Professional Plan &#11088;</h3>
          <div class="plan-price">&#8377;19,999<span>/month</span></div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> Advanced SEO</li>
            <li><i class="fa-solid fa-circle-check"></i> Google Ads Management</li>
            <li><i class="fa-solid fa-circle-check"></i> Meta Ads</li>
            <li><i class="fa-solid fa-circle-check"></i> Content Marketing</li>
            <li><i class="fa-solid fa-circle-check"></i> Weekly Reports</li>
            <li><i class="fa-solid fa-circle-check"></i> Lead Generation</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Most Popular</button>
      </div>

      <!-- Enterprise Plan -->
      <div class="price-card">
        <div>
          <h3>Enterprise Plan</h3>
          <div class="plan-price">Custom Price</div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> Complete Digital Marketing</li>
            <li><i class="fa-solid fa-circle-check"></i> Dedicated Account Manager</li>
            <li><i class="fa-solid fa-circle-check"></i> AI Strategy</li>
            <li><i class="fa-solid fa-circle-check"></i> Unlimited Consultation</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Contact Us</button>
      </div>
    </div>

    <!-- Website Development Pricing Grid -->
    <div id="pricing-webdev" class="pricing-grid grid-4">
      <!-- Basic Website -->
      <div class="price-card">
        <div>
          <h3>Basic Website</h3>
          <div class="plan-price">Starting &#8377;14,999</div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> 5 Pages</li>
            <li><i class="fa-solid fa-circle-check"></i> Mobile Responsive</li>
            <li><i class="fa-solid fa-circle-check"></i> Contact Form</li>
            <li><i class="fa-solid fa-circle-check"></i> Basic SEO</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Get Started</button>
      </div>

      <!-- Business Website (Featured) -->
      <div class="price-card featured">
        <div class="plan-badge">Most Popular</div>
        <div>
          <h3>Business Website &#11088;</h3>
          <div class="plan-price">Starting &#8377;29,999</div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> 10-15 Pages</li>
            <li><i class="fa-solid fa-circle-check"></i> Admin Panel</li>
            <li><i class="fa-solid fa-circle-check"></i> Blog</li>
            <li><i class="fa-solid fa-circle-check"></i> Full SEO Setup</li>
            <li><i class="fa-solid fa-circle-check"></i> WhatsApp Integration</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Most Popular</button>
      </div>

      <!-- Ecommerce Website -->
      <div class="price-card">
        <div>
          <h3>Ecommerce Website</h3>
          <div class="plan-price">Starting &#8377;49,999</div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> Unlimited Products</li>
            <li><i class="fa-solid fa-circle-check"></i> Payment Gateway</li>
            <li><i class="fa-solid fa-circle-check"></i> Order Management</li>
            <li><i class="fa-solid fa-circle-check"></i> Admin Dashboard</li>
            <li><i class="fa-solid fa-circle-check"></i> SEO Optimized</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Get Started</button>
      </div>

      <!-- Custom Web Application -->
      <div class="price-card">
        <div>
          <h3>Custom Web Application</h3>
          <div class="plan-price">Custom Price</div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> Custom CRM</li>
            <li><i class="fa-solid fa-circle-check"></i> Enterprise ERP</li>
            <li><i class="fa-solid fa-circle-check"></i> Client Portal</li>
            <li><i class="fa-solid fa-circle-check"></i> Custom Dashboard</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Contact Us</button>
      </div>
    </div>

    <!-- Google Ads Pricing Grid -->
    <div id="pricing-googleads" class="pricing-grid">
      <!-- Search Ads -->
      <div class="price-card">
        <div>
          <h3>Search Ads Setup</h3>
          <div class="plan-price">&#8377;14,999<span>/month</span></div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> Keyword Research</li>
            <li><i class="fa-solid fa-circle-check"></i> Ad Copy Creation</li>
            <li><i class="fa-solid fa-circle-check"></i> Bid Management</li>
            <li><i class="fa-solid fa-circle-check"></i> Performance Tracking</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Get Started</button>
      </div>

      <!-- Display & Search (Featured) -->
      <div class="price-card featured">
        <div class="plan-badge">Featured</div>
        <div>
          <h3>Display & Search &#11088;</h3>
          <div class="plan-price">&#8377;24,999<span>/month</span></div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> Advanced Keyword Research</li>
            <li><i class="fa-solid fa-circle-check"></i> Display Network Ads</li>
            <li><i class="fa-solid fa-circle-check"></i> Retargeting Setup</li>
            <li><i class="fa-solid fa-circle-check"></i> A/B Testing</li>
            <li><i class="fa-solid fa-circle-check"></i> Weekly Optimization</li>
            <li><i class="fa-solid fa-circle-check"></i> ROI Reporting</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Most Popular</button>
      </div>

      <!-- Comprehensive Ads -->
      <div class="price-card">
        <div>
          <h3>Comprehensive Plan</h3>
          <div class="plan-price">Custom Price</div>
          <ul>
            <li><i class="fa-solid fa-circle-check"></i> Search, Display & Video Ads</li>
            <li><i class="fa-solid fa-circle-check"></i> Landing Page Optimization</li>
            <li><i class="fa-solid fa-circle-check"></i> Advanced Conversion Tracking</li>
            <li><i class="fa-solid fa-circle-check"></i> Dedicated Ad Manager</li>
          </ul>
        </div>
        <button class="plan-btn open-quote-trigger">Contact Us</button>
      </div>
    </div>

  </div>
</section>

<!-- ============================================================
     CASE STUDIES
============================================================ -->
<section class="case-studies-section section" id="casestudies">
  <div class="container">
    <div class="section-header text-center">
      <div class="section-pill">Our Success</div>
      <h2 class="section-heading">Proven <span class="grad-text">Case Studies</span></h2>
      <p class="section-desc">Real results we've achieved for our clients through data-driven strategies.</p>
    </div>
    <div class="cs-grid">
      <!-- Case Study 1 -->
      <div class="cs-card">
        <div class="cs-img"><img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=600&auto=format&fit=crop" alt="SEO Case Study"></div>
        <div class="cs-content">
          <span class="cs-cat">SEO Optimization</span>
          <h3>National E-Commerce Brand</h3>
          <div class="cs-metric">
            <span class="csm-value">+312%</span>
            <span class="csm-label">Organic Traffic<br>in 6 months</span>
          </div>
          <a href="#" class="cs-link">Read Case Study <i class="fa-solid fa-arrow-right"></i></a>
        </div>
      </div>
      <!-- Case Study 2 -->
      <div class="cs-card">
        <div class="cs-img"><img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=600&auto=format&fit=crop" alt="PPC Case Study"></div>
        <div class="cs-content">
          <span class="cs-cat">Google Ads</span>
          <h3>Local Healthcare Provider</h3>
          <div class="cs-metric">
            <span class="csm-value">-45%</span>
            <span class="csm-label">Cost Per Acquisition<br>(CPA)</span>
          </div>
          <a href="#" class="cs-link">Read Case Study <i class="fa-solid fa-arrow-right"></i></a>
        </div>
      </div>
      <!-- Case Study 3 -->
      <div class="cs-card">
        <div class="cs-img"><img src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=600&auto=format&fit=crop" alt="Web Dev Case Study"></div>
        <div class="cs-content">
          <span class="cs-cat">Web Development</span>
          <h3>B2B Tech Startup</h3>
          <div class="cs-metric">
            <span class="csm-value">+185%</span>
            <span class="csm-label">Lead Conversion<br>Rate Increase</span>
          </div>
          <a href="#" class="cs-link">Read Case Study <i class="fa-solid fa-arrow-right"></i></a>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- ============================================================
     PORTFOLIO
============================================================ -->
<section class="section portfolio-section" id="portfolio" aria-label="Portfolio">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Portfolio</div>
      <h2 class="section-heading">Our <span class="grad-text">Work &amp; Results</span></h2>
      <p class="section-sub">Real projects, real results - see what we've delivered for our clients</p>
    </div>
    <div class="ptabs" role="tablist">
      <button class="ptab active" data-filter="all" role="tab">All Projects</button>
      <button class="ptab" data-filter="seo" role="tab">SEO</button>
      <button class="ptab" data-filter="web" role="tab">Websites</button>
      <button class="ptab" data-filter="ads" role="tab">Google Ads</button>
      <button class="ptab" data-filter="social" role="tab">Social Media</button>
    </div>
    <div class="port-grid">
      <div class="port-card port-item" data-cat="seo">
        <div class="port-thumb" style="background:linear-gradient(135deg,#5B21B6,#7C3AED)">
          <div class="pt-icon"><i class="fa-solid fa-magnifying-glass-chart" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Dental Clinic SEO</h4><p>300% Traffic Increase in 6 months</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">SEO</div><p>Ranked 15 keywords on Google Page 1, tripled organic traffic</p></div>
      </div>
      <div class="port-card port-item" data-cat="web">
        <div class="port-thumb" style="background:linear-gradient(135deg,#06B6D4,#0891B2)">
          <div class="pt-icon"><i class="fa-solid fa-laptop-code" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Ecommerce Website</h4><p>500+ Products, 2x Conversion Rate</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Website</div><p>Custom WooCommerce store with payment gateway integration</p></div>
      </div>
      <div class="port-card port-item" data-cat="ads">
        <div class="port-thumb" style="background:linear-gradient(135deg,#EA4335,#FBBC04)">
          <div class="pt-icon"><i class="fa-brands fa-google" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Google Ads Campaign</h4><p>Rs.2L Ad Spend = Rs.18L Revenue</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Google Ads</div><p>Real estate campaign with 9x ROAS in 3 months</p></div>
      </div>
      <div class="port-card port-item" data-cat="social">
        <div class="port-thumb" style="background:linear-gradient(135deg,#E1306C,#833AB4)">
          <div class="pt-icon"><i class="fa-brands fa-instagram" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Instagram Growth</h4><p>0 to 50K Followers in 4 months</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Social Media</div><p>Fashion brand Instagram account managed to explosive growth</p></div>
      </div>
      <div class="port-card port-item" data-cat="seo">
        <div class="port-thumb" style="background:linear-gradient(135deg,#10B981,#059669)">
          <div class="pt-icon"><i class="fa-solid fa-location-dot" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Local SEO - Restaurant</h4><p>#1 on Google Maps in 90 Days</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">Local SEO</div><p>Restaurant ranked #1 for 8 local keywords, 40% more footfall</p></div>
      </div>
      <div class="port-card port-item" data-cat="web">
        <div class="port-thumb" style="background:linear-gradient(135deg,#F59E0B,#EF4444)">
          <div class="pt-icon"><i class="fa-solid fa-mobile-screen" style="font-size:40px;color:white"></i></div>
          <div class="pt-info"><h4>Mobile App Development</h4><p>10K+ Downloads in First Month</p></div>
        </div>
        <div class="port-meta"><div class="port-tag">App Dev</div><p>React Native delivery app with real-time tracking and payments</p></div>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     TESTIMONIALS
============================================================ -->
<section class="section testi-section dark-section" id="testimonials" aria-label="Client Testimonials">
  <div class="container">
    <div class="section-header">
      <div class="section-pill alt-pill">Testimonials</div>
      <h2 class="section-heading light-heading">What Our <span class="grad-text-cyan">Clients Say</span></h2>
      <p class="section-sub light-sub">Real reviews from real clients across India</p>
    </div>
    <div class="testi-slider-wrap">
      <div class="testi-track" id="testiTrack">
        <div class="testi-card">
          <div class="tc-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
          <p class="tc-text">"ONEDIGIWEB transformed our online presence. Our website traffic increased by 400% in just 4 months. Their SEO team is simply outstanding!"</p>
          <div class="tc-author">
            <div class="tc-av" style="background:linear-gradient(135deg,#f59e0b,#ef4444)">RK</div>
            <div><strong>Rajesh Kumar</strong><span>Owner, Kumar Dental Clinic, Mumbai</span></div>
          </div>
        </div>
        <div class="testi-card">
          <div class="tc-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
          <p class="tc-text">"Best investment we've made for our business! Google Ads campaign generated Rs.18 lakhs in revenue from just Rs.2 lakh ad spend. Excellent ROI!"</p>
          <div class="tc-author">
            <div class="tc-av" style="background:linear-gradient(135deg,#06b6d4,#3b82f6)">PS</div>
            <div><strong>Priya Sharma</strong><span>Founder, Sharma Real Estate, Delhi</span></div>
          </div>
        </div>
        <div class="testi-card">
          <div class="tc-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
          <p class="tc-text">"Our Instagram grew from 500 to 50,000 followers in 4 months. ONEDIGIWEB's social media team is creative, professional and result-driven."</p>
          <div class="tc-author">
            <div class="tc-av" style="background:linear-gradient(135deg,#ec4899,#8b5cf6)">AM</div>
            <div><strong>Anita Mehta</strong><span>CEO, Style Studio Fashion, Pune</span></div>
          </div>
        </div>
        <div class="testi-card">
          <div class="tc-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
          <p class="tc-text">"They built our ecommerce website in just 3 weeks. Sales doubled in the first month. 24/7 support is a huge plus. Highly recommend ONEDIGIWEB!"</p>
          <div class="tc-author">
            <div class="tc-av" style="background:linear-gradient(135deg,#10b981,#059669)">VG</div>
            <div><strong>Vikram Gupta</strong><span>Director, GuptaMart Online Store, Bangalore</span></div>
          </div>
        </div>
        <div class="testi-card">
          <div class="tc-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
          <p class="tc-text">"ONEDIGIWEB ranked our restaurant on #1 Google Maps position in just 90 days. Footfall increased by 40%. Amazing team with great communication."</p>
          <div class="tc-author">
            <div class="tc-av" style="background:linear-gradient(135deg,#f59e0b,#ef4444)">SK</div>
            <div><strong>Suresh Khanna</strong><span>Owner, Khanna Restaurant, Jaipur</span></div>
          </div>
        </div>
      </div>
    </div>
    <div class="testi-controls">
      <button class="tc-btn" id="tPrev" aria-label="Previous"><i class="fa-solid fa-chevron-left"></i></button>
      <div class="tc-dots" id="tDots"></div>
      <button class="tc-btn" id="tNext" aria-label="Next"><i class="fa-solid fa-chevron-right"></i></button>
    </div>
  </div>
</section>

<!-- ============================================================
     NEWSLETTER SECTION (lead collection)
============================================================ -->
<section class="nl-section" id="newsletter" aria-label="Newsletter Subscription">
  <div class="container">
    <div class="nl-layout">
      <div class="nl-info">
        <div class="nl-icon-wrap"><i class="fa-solid fa-paper-plane"></i></div>
        <h2>Stay Updated With Digital Marketing Tips</h2>
        <p>Get SEO updates, marketing strategies, website growth ideas and exclusive offers directly in your inbox.</p>
        <div class="nl-perks">
          <span><i class="fa-solid fa-circle-check"></i> Free Growth Tips &amp; Strategies</span>
          <span><i class="fa-solid fa-circle-check"></i> SEO Updates &amp; Algorithm Changes</span>
          <span><i class="fa-solid fa-circle-check"></i> Spam-Free Quality Information Only</span>
        </div>
      </div>
      <div class="nl-form-wrap">
        <form class="nl-form" id="nlForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
          <input type="hidden" name="_subject" value="New Newsletter Subscription - ONEDIGIWEB" />
          <input type="hidden" name="_captcha" value="false" />
          <input type="hidden" name="_template" value="table" />
          <input type="hidden" name="_next" value="https://onedigiweb.com/thank-you.html" />
          <input type="text" name="_honey" style="display:none" />
          <input type="hidden" name="Submission Date & Time" class="sub-date-time-field" value="" />
          
          <div class="nl-field">
            <i class="fa-solid fa-user nl-field-icon"></i>
            <input type="text" name="Full Name" placeholder="Full Name" required />
          </div>
          <div class="nl-field">
            <i class="fa-solid fa-envelope nl-field-icon"></i>
            <input type="email" name="Email Address" placeholder="Email Address" required />
          </div>
          <div class="nl-field">
            <i class="fa-solid fa-phone nl-field-icon"></i>
            <input type="tel" name="Mobile Number" placeholder="Mobile Number" required />
          </div>
          <button type="submit" class="btn nl-submit btn-full">Subscribe Now</button>
        </form>
        <div class="nl-note" style="margin-top:14px;"><i class="fa-solid fa-shield-halved"></i> We respect your privacy. No spam ever.</div>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     FAQ SECTION
============================================================ -->
<section class="section faq-section" id="faq" aria-label="Frequently Asked Questions">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">FAQ</div>
      <h2 class="section-heading">Frequently Asked <span class="grad-text">Questions</span></h2>
      <p class="section-sub">Everything you need to know about our services</p>
    </div>
    <div class="faq-list">
      <div class="faq-item">
        <button class="faq-q">How long does SEO take to show results? <span class="faq-ico"><i class="fa-solid fa-plus"></i></span></button>
        <div class="faq-a"><p>SEO typically shows significant results in 3-6 months depending on competition, domain authority and website quality. We provide monthly ranking reports so you can track progress every step of the way.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-q">What is your minimum budget for Google Ads? <span class="faq-ico"><i class="fa-solid fa-plus"></i></span></button>
        <div class="faq-a"><p>We recommend a minimum ad spend of &#8377;10,000/month plus our management fee of &#8377;7,999/month. This ensures enough data for optimization and meaningful results.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-q">Do you provide monthly reports? <span class="faq-ico"><i class="fa-solid fa-plus"></i></span></button>
        <div class="faq-a"><p>Yes! We provide detailed monthly performance reports with rankings, traffic, leads generated, ad performance, and actionable insights. Our team is also available for strategy calls anytime.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-q">How long does website development take? <span class="faq-ico"><i class="fa-solid fa-plus"></i></span></button>
        <div class="faq-a"><p>A basic business website takes 5-7 working days. WordPress sites take 7-14 days. Ecommerce websites take 2-4 weeks depending on the number of products and customizations required.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-q">Do you offer social media content creation? <span class="faq-ico"><i class="fa-solid fa-plus"></i></span></button>
        <div class="faq-a"><p>Yes! Our social media packages include professional graphic design, copywriting, hashtag research, scheduling and community management for Instagram, Facebook, LinkedIn and YouTube.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-q">What makes ONEDIGIWEB different from other agencies? <span class="faq-ico"><i class="fa-solid fa-plus"></i></span></button>
        <div class="faq-a"><p>We combine data-driven strategies with creative excellence. Our 98% client retention rate, certified team, 24/7 WhatsApp support, and transparent reporting sets us apart. We treat your business like our own.</p></div>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     LATEST BLOG
============================================================ -->
<section class="blog-section section" id="blog">
  <div class="container">
    <div class="section-header text-center">
      <div class="section-pill">Insights</div>
      <h2 class="section-heading">Latest <span class="grad-text">Articles</span></h2>
      <p class="section-desc">Stay updated with the latest digital marketing trends and strategies.</p>
    </div>
    <div class="blog-grid">
      <!-- Blog 1 -->
      <div class="blog-card">
        <div class="bc-img">
          <img src="https://images.unsplash.com/photo-1432821596592-e2c18b78144f?q=80&w=600&auto=format&fit=crop" alt="Blog Post">
          <div class="bc-date">12<span>Oct</span></div>
        </div>
        <div class="bc-content">
          <div class="bc-meta">
            <span><i class="fa-solid fa-folder"></i> SEO</span>
            <span><i class="fa-solid fa-user"></i> Admin</span>
          </div>
          <h3><a href="#">The Future of SEO: AI Search & Voice Optimization in 2026</a></h3>
          <p>Discover how artificial intelligence and voice search are fundamentally changing the SEO landscape and how you can prepare.</p>
          <a href="#" class="bc-link">Read More <i class="fa-solid fa-arrow-right"></i></a>
        </div>
      </div>
      <!-- Blog 2 -->
      <div class="blog-card">
        <div class="bc-img">
          <img src="https://images.unsplash.com/photo-1533750349088-cd871a92f312?q=80&w=600&auto=format&fit=crop" alt="Blog Post">
          <div class="bc-date">08<span>Oct</span></div>
        </div>
        <div class="bc-content">
          <div class="bc-meta">
            <span><i class="fa-solid fa-folder"></i> Paid Ads</span>
            <span><i class="fa-solid fa-user"></i> Admin</span>
          </div>
          <h3><a href="#">Maximizing ROI with Google Performance Max Campaigns</a></h3>
          <p>A comprehensive guide on leveraging Google's Performance Max campaigns to drive conversions across all channels.</p>
          <a href="#" class="bc-link">Read More <i class="fa-solid fa-arrow-right"></i></a>
        </div>
      </div>
      <!-- Blog 3 -->
      <div class="blog-card">
        <div class="bc-img">
          <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=600&auto=format&fit=crop" alt="Blog Post">
          <div class="bc-date">28<span>Sep</span></div>
        </div>
        <div class="bc-content">
          <div class="bc-meta">
            <span><i class="fa-solid fa-folder"></i> Social Media</span>
            <span><i class="fa-solid fa-user"></i> Admin</span>
          </div>
          <h3><a href="#">Building a Community-Driven Social Media Strategy</a></h3>
          <p>Stop broadcasting and start engaging. Learn how to build a loyal brand community on platforms like Instagram and LinkedIn.</p>
          <a href="#" class="bc-link">Read More <i class="fa-solid fa-arrow-right"></i></a>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- ============================================================
     CONTACT SECTION
============================================================ -->
<section class="section contact-section" id="contact" aria-label="Contact Us">
  <div class="container">
    <div class="section-header">
      <div class="section-pill">Contact Us</div>
      <h2 class="section-heading">Get In <span class="grad-text">Touch</span></h2>
      <p class="section-sub">Have a project in mind or want to grow your business online? Let's talk!</p>
    </div>
    
    <div class="contact-layout">
      <!-- Left Panel: Contact Info -->
      <div class="contact-card">
        <h3><i class="fa-solid fa-address-card" style="color:var(--p2)"></i> Contact Information</h3>
        <p style="color:var(--gray); margin-bottom: 24px; font-size: 14px;">Reach out to us directly or fill the form and we will get back to you shortly.</p>
        
        <div class="contact-items">
          <div class="contact-item">
            <div class="ci-ico"><i class="fa-solid fa-building"></i></div>
            <div>
              <strong>ONEDIGIWEB Marketing Solution</strong>
              <span>A-88, New Delhi, India</span>
            </div>
          </div>
          <div class="contact-item">
            <div class="ci-ico"><i class="fa-solid fa-phone"></i></div>
            <div>
              <strong>Phone Number</strong>
              <a href="tel:+918512821525">+91 8512821525</a>
            </div>
          </div>
          <div class="contact-item">
            <div class="ci-ico"><i class="fa-solid fa-envelope"></i></div>
            <div>
              <strong>Email Address</strong>
              <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a>
            </div>
          </div>
        </div>

        <!-- Social Links -->
        <div class="contact-social" style="margin-top: 30px;">
          <a href="https://www.facebook.com/onedigiweb" target="_blank" class="cs-btn cs-fb" title="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="https://www.instagram.com/onedigiweb" target="_blank" class="cs-btn cs-ig" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://www.linkedin.com/company/onedigiweb" target="_blank" class="cs-btn cs-li" title="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
          <a href="https://www.youtube.com/@onedigiweb" target="_blank" class="cs-btn cs-yt" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
          <a href="https://wa.me/918512821525" target="_blank" class="cs-btn cs-wa" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
        </div>
      </div>

      <!-- Right Panel: Inquiry Form -->
      <div class="consult-form-card" style="margin-top:0;">
        <div class="cfc-header" style="background:var(--g-main); padding: 24px 30px; color:white;">
          <h3 style="color:white; font-family:var(--font); font-size:20px; font-weight:800; display:flex; align-items:center; gap:8px; margin:0;"><i class="fa-solid fa-paper-plane"></i> Send An Inquiry</h3>
          <p style="color:rgba(255,255,255,0.8); font-size: 13px; margin: 4px 0 0 0;">Fill out the form below to get a free strategy and consultation.</p>
        </div>
        <form class="cfc-form" id="consultForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST" style="padding: 30px; display:flex; flex-direction:column; gap:16px;">
          <input type="hidden" name="_subject" value="New Contact Inquiry - ONEDIGIWEB" />
          <input type="hidden" name="_captcha" value="false" />
          <input type="hidden" name="_template" value="table" />
          <input type="hidden" name="_next" value="https://onedigiweb.com/thank-you.html" />
          <input type="text" name="_honey" style="display:none" />
          <input type="hidden" name="Submission Date & Time" class="sub-date-time-field" value="" />

          <div class="cf-row" style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
            <div class="cf-group" style="display:flex; flex-direction:column; gap:6px;">
              <label style="font-size:11px; font-weight:700; text-transform:uppercase; color:var(--dark3);"><i class="fa-solid fa-user"></i> Name *</label>
              <input type="text" name="Name" placeholder="Your Name" required style="padding:10px 14px; border:1.5px solid var(--border); border-radius:10px; font-size:14px; background:var(--light); outline:none;" />
            </div>
            <div class="cf-group" style="display:flex; flex-direction:column; gap:6px;">
              <label style="font-size:11px; font-weight:700; text-transform:uppercase; color:var(--dark3);"><i class="fa-solid fa-phone"></i> Phone *</label>
              <input type="tel" name="Phone" placeholder="Mobile Number" required style="padding:10px 14px; border:1.5px solid var(--border); border-radius:10px; font-size:14px; background:var(--light); outline:none;" />
            </div>
          </div>
          <div class="cf-row" style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
            <div class="cf-group" style="display:flex; flex-direction:column; gap:6px;">
              <label style="font-size:11px; font-weight:700; text-transform:uppercase; color:var(--dark3);"><i class="fa-solid fa-envelope"></i> Email *</label>
              <input type="email" name="Email" placeholder="your@email.com" required style="padding:10px 14px; border:1.5px solid var(--border); border-radius:10px; font-size:14px; background:var(--light); outline:none;" />
            </div>
            <div class="cf-group" style="display:flex; flex-direction:column; gap:6px;">
              <label style="font-size:11px; font-weight:700; text-transform:uppercase; color:var(--dark3);"><i class="fa-solid fa-list"></i> Select Service *</label>
              <select name="Selected Service" required style="padding:10px 14px; border:1.5px solid var(--border); border-radius:10px; font-size:14px; background:var(--light); outline:none; cursor:pointer;">
                <option value="" disabled selected>Select service...</option>
                <option value="SEO Services">SEO Services</option>
                <option value="Google Ads">Google Ads</option>
                <option value="Social Media Marketing">Social Media Marketing</option>
                <option value="Website Development">Website Development</option>
                <option value="Ecommerce Website">Ecommerce Website</option>
                <option value="App Development">App Development</option>
                <option value="Branding & Design">Branding &amp; Design</option>
                <option value="Complete Digital Marketing">Complete Digital Marketing</option>
              </select>
            </div>
          </div>
          <div class="cf-group" style="display:flex; flex-direction:column; gap:6px;">
            <label style="font-size:11px; font-weight:700; text-transform:uppercase; color:var(--dark3);"><i class="fa-solid fa-message"></i> Message</label>
            <textarea name="Message" rows="3" placeholder="Tell us about your project requirements..." style="padding:10px 14px; border:1.5px solid var(--border); border-radius:10px; font-size:14px; background:var(--light); outline:none; resize:vertical; min-height:80px;"></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-full" id="cfSubmit" style="font-weight:700; padding: 14px; border-radius:12px; margin-top:8px;">
            Get Free Consultation
          </button>
        </form>
      </div>
    </div>

  </div>
</section>

<!-- ============================================================
     FOOTER
============================================================ -->
<!-- COMPONENT: FOOTER -->
<footer class="footer" id="footer" aria-label="Footer">
  <div class="footer-main container">
    <div class="footer-grid">

      <!-- Brand Column -->
      <div class="footer-brand">
        <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="220" height="63" class="logo-img"></a>
        <div class="footer-brand-tagline">Grow &bull; Rank &bull; Convert</div>
        <div class="footer-brand-services">SEO | Digital Marketing | Website Development</div>
        <p>India's trusted digital marketing agency helping businesses grow online with proven, data-driven strategies and dedicated round-the-clock support.</p>
        <div class="footer-brand-contacts">
          <a href="tel:+918512821525" class="fbc-item"><i class="fa-solid fa-phone"></i> +91 8512821525</a>
          <a href="mailto:onedigiweb@gmail.com" class="fbc-item"><i class="fa-solid fa-envelope"></i> onedigiweb@gmail.com</a>
          <a href="https://wa.me/918512821525" class="fbc-item" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp: +91 8512821525</a>
        </div>
        <div class="footer-socials">
          <a href="https://www.facebook.com/onedigiweb" target="_blank" class="fs-link fs-fb" title="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="https://www.instagram.com/onedigiweb" target="_blank" class="fs-link fs-ig" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://www.linkedin.com/company/onedigiweb" target="_blank" class="fs-link fs-li" title="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
          <a href="https://www.youtube.com/@onedigiweb" target="_blank" class="fs-link fs-yt" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
          <a href="https://wa.me/918512821525" target="_blank" class="fs-link fs-wa" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
        </div>
      </div>

      <!-- Quick Links -->
      <div class="footer-col">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="#home"><i class="fa-solid fa-house fa-xs"></i> Home</a></li>
          <li><a href="#services"><i class="fa-solid fa-briefcase fa-xs"></i> Services</a></li>
          <li><a href="#pricing"><i class="fa-solid fa-tags fa-xs"></i> Pricing</a></li>
          <li><a href="#portfolio"><i class="fa-solid fa-images fa-xs"></i> Portfolio</a></li>
          <li><a href="#contact"><i class="fa-solid fa-envelope fa-xs"></i> Contact</a></li>
        </ul>
      </div>

      <!-- Services Links -->
      <div class="footer-col">
        <h4>Our Services</h4>
        <ul>
          <li><a href="seo-services.html"><i class="fa-solid fa-magnifying-glass fa-xs"></i> SEO Services</a></li>
          <li><a href="google-ads-services.html"><i class="fa-brands fa-google fa-xs"></i> Google Ads</a></li>
          <li><a href="social-media-marketing.html"><i class="fa-solid fa-share-nodes fa-xs"></i> Social Media Marketing</a></li>
          <li><a href="website-development.html"><i class="fa-solid fa-laptop-code fa-xs"></i> Website Development</a></li>
          <li><a href="ecommerce-development.html"><i class="fa-solid fa-cart-shopping fa-xs"></i> Ecommerce Development</a></li>
          <li><a href="app-development.html"><i class="fa-solid fa-mobile-screen fa-xs"></i> App Development</a></li>
          <li><a href="graphic-design-services.html"><i class="fa-solid fa-pen-nib fa-xs"></i> Graphic Design</a></li>
          <li><a href="lead-generation-services.html"><i class="fa-solid fa-chart-line fa-xs"></i> Lead Generation</a></li>
        </ul>
      </div>

      <!-- Contact + CTA -->
      <div class="footer-col">
        <h4>Contact Us</h4>
        <ul class="fc-contact">
          <li><a href="mailto:onedigiweb@gmail.com"><i class="fa-solid fa-envelope"></i> onedigiweb@gmail.com</a></li>
          <li><a href="tel:+918512821525"><i class="fa-solid fa-phone"></i> +91 8512821525</a></li>
          <li><a href="https://wa.me/918512821525" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a></li>
          <li><span><i class="fa-solid fa-clock"></i> Mon&ndash;Sat: 9AM&ndash;7PM</span></li>
        </ul>
        <button onclick="document.getElementById('quotePopup').style.display='flex'" class="footer-cta">
          <i class="fa-solid fa-rocket"></i> Get Free Quote
        </button>
      </div>
    </div>
  </div>

  <!-- Footer Bottom -->
  <div class="footer-bottom">
    <div class="container footer-bottom-inner">
      <p>&copy; 2026 ONEDIGIWEB Marketing Solution. All Rights Reserved.</p>
      <div class="footer-policy-links">
        <a href="privacy-policy.html">Privacy Policy</a>
        <span>&bull;</span>
        <a href="terms-and-conditions.html">Terms &amp; Conditions</a>
        <span>&bull;</span>
        <a href="refund-policy.html">Refund Policy</a>
        <span>&bull;</span>
        <a href="disclaimer.html">Disclaimer</a>
        <span>&bull;</span>
        <a href="about-us.html">About Us</a>
      </div>
    </div>
  </div>
</footer>

<!-- END COMPONENT: FOOTER -->

<!-- ============================================================
     FLOATING GLASS FABs (Desktop)
============================================================ -->
<!-- COMPONENT: POPUPS -->
<!-- Floating Glass FABs (Desktop/Mobile) -->
<div class="glass-fabs" id="glassFabs">
  <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." class="gfab gfab-wa" target="_blank" title="WhatsApp">
    <div class="gfab-pulse"></div>
    <i class="fa-brands fa-whatsapp" style="font-size:22px"></i>
    <span>WhatsApp</span>
  </a>
  <a href="tel:+918512821525" class="gfab gfab-call" title="Call Now">
    <i class="fa-solid fa-phone" style="font-size:18px"></i>
    <span>Call Now</span>
  </a>
  <button class="gfab gfab-top" id="backTop" onclick="window.scrollTo({top:0,behavior:'smooth'})" title="Back to Top">
    <i class="fa-solid fa-chevron-up" style="font-size:16px"></i>
    <span>Back to Top</span>
  </button>
</div>

<!-- Mobile Sticky Bar -->
<div class="mobile-sticky-bar" id="mobileStickyBar">
  <a href="tel:+918512821525" class="msb-btn msb-call"><i class="fa-solid fa-phone"></i> Call Now</a>
  <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." class="msb-btn msb-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
  <button class="msb-btn msb-quote open-quote-trigger"><i class="fa-solid fa-file-invoice"></i> Get Quote</button>
</div>

<!-- Free Strategy Session Popup -->
<div class="popup-overlay quote-popup-overlay" id="quotePopup" style="display:none" role="dialog" aria-modal="true" aria-label="Free Strategy Session Form">
  <div class="nq-popup-box">
    <button class="popup-x" id="closeQuotePopup"><i class="fa-solid fa-xmark"></i></button>
    <div class="nq-header">
      <div class="nq-label">FREE SEO CONSULTATION</div>
      <div class="nq-icon-wrap"><i class="fa-solid fa-chart-column"></i></div>
    </div>
    <h3 class="nq-title">Ready to rank higher?</h3>
    
    <form class="nq-form" id="quoteForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
      <input type="hidden" name="_subject" value="New Lead - FREE SEO Consultation Request" />
      <input type="hidden" name="_captcha" value="false" />
      <input type="hidden" name="_template" value="table" />
      <input type="hidden" name="_next" value="https://onedigiweb.com/thank-you.html" />
      <input type="text" name="_honey" style="display:none" />
      <input type="hidden" name="Submission Date & Time" class="sub-date-time-field" value="" />
      
      <div class="nq-field">
        <input type="text" id="qfName" name="Name" placeholder="Name" required />
      </div>
      <div class="nq-field">
        <input type="email" id="qfEmail" name="Email" placeholder="Email" required />
      </div>
      <div class="nq-field">
        <input type="tel" id="qfPhone" name="Mobile Number" placeholder="Phone" required />
      </div>
      <div class="nq-field">
        <input type="url" id="qfWebsite" name="Website" placeholder="Website" />
      </div>
      
      <button type="submit" class="nq-submit" id="qfSubmitBtn">
        Get a Free SEO Consultation <i class="fa-solid fa-arrow-right"></i>
      </button>
      
      <div class="nq-footer-text">No pressure. No generic sales pitch.</div>
    </form>
  </div>
</div>

<!-- Success / Thank You Popup -->
<div class="popup-overlay" id="thankYouPopup" style="display:none">
  <div class="popup-box ty-popup-box" style="max-width:500px;">
    <button class="popup-x" onclick="document.getElementById('thankYouPopup').style.display='none';document.body.style.overflow=''"><i class="fa-solid fa-xmark"></i></button>
    <div class="ty-animation">
      <div class="ty-circle"><i class="fa-solid fa-check" style="font-size:36px;color:white"></i></div>
    </div>
    <h3>&#127881; Thank You!</h3>
    <p>Your request has been submitted successfully.<br>Our team will contact you shortly on your phone number or email.</p>
    <div class="ty-info">
      <div class="ty-info-item"><i class="fa-solid fa-phone" style="color:var(--accent)"></i><span>+91 8512821525</span></div>
      <div class="ty-info-item"><i class="fa-solid fa-envelope" style="color:var(--accent)"></i><span>onedigiweb@gmail.com</span></div>
      <div class="ty-info-item"><i class="fa-solid fa-clock" style="color:var(--accent)"></i><span>Response within 24 hours</span></div>
    </div>
    <div class="wpb-btns">
      <a href="https://wa.me/918512821525?text=Hi! I just claimed my free digital strategy session on ONEDIGIWEB." class="btn btn-hero-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp</a>
      <button onclick="document.getElementById('thankYouPopup').style.display='none';document.body.style.overflow=''" class="btn btn-hero-call">Close Window</button>
    </div>
  </div>
</div>

<!-- Premium Newsletter Popup -->
<div class="popup-overlay" id="newsletterPopup" style="display:none" role="dialog" aria-modal="true" aria-label="Newsletter Subscription">
  <div class="newsletter-popup-box">
    <!-- Left Side -->
    <div class="np-left">
      <div class="qp-brand">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" style="width: 200px; height: auto; max-width: 100%; object-fit: contain;">
      </div>
      <h3>Stay Updated With Digital Marketing Trends</h3>
      <p>Subscribe to receive the latest SEO tips, Google Ads updates, website development insights, exclusive offers and digital marketing news directly in your inbox.</p>
    </div>
    <!-- Right Side -->
    <div class="np-right">
      <div class="np-card" style="position:relative;">
        <button class="qp-close" id="closeNewsletterPopup" style="top:12px; right:12px;"><i class="fa-solid fa-xmark"></i></button>
        <form class="np-form" id="newsletterPopupForm" action="https://formsubmit.co/onedigiweb@gmail.com" method="POST">
          <input type="hidden" name="_subject" value="New Subscriber - Premium Newsletter | ONEDIGIWEB" />
          <input type="hidden" name="_captcha" value="false" />
          <input type="hidden" name="_template" value="table" />
          <input type="text" name="_honey" style="display:none" />
          
          <div class="np-field">
            <label><i class="fa-solid fa-user"></i> Full Name *</label>
            <input type="text" name="Subscriber Name" placeholder="Enter your name" required />
          </div>
          <div class="np-field">
            <label><i class="fa-solid fa-envelope"></i> Email Address *</label>
            <input type="email" name="Subscriber Email" placeholder="your@email.com" required />
          </div>
          <div class="np-field">
            <label><i class="fa-solid fa-phone"></i> Mobile Number (Optional)</label>
            <input type="tel" name="Subscriber Phone" placeholder="Enter mobile number" />
          </div>
          <button type="submit" class="np-submit" style="border:none; width: 100%;">Subscribe Now</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="script.js"></script>
<?php wp_footer(); ?>
</body>
</html>













