﻿<?php
/**
 * Template Name: Terms And Conditions
 */
?>
<?php get_header(); ?>


<section class="policy-hero">
  <div class="container">
    <div class="section-pill" style="margin-bottom:16px;">Legal</div>
    <h1>Terms &amp; Conditions</h1>
    <p>Last Updated: June 24, 2026 &nbsp;&middot;&nbsp; Effective Date: June 24, 2026</p>
  </div>
</section>

<section>
  <div class="container policy-content">
    <p>Welcome to <strong>ONEDIGIWEB Marketing Solution</strong>. By accessing our website or using our services, you agree to be bound by these Terms and Conditions. Please read them carefully before engaging with our services.</p>

    <h2>1. Acceptance of Terms</h2>
    <p>By accessing and using the ONEDIGIWEB website and services, you accept and agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use our services.</p>

    <h2>2. Services</h2>
    <p>ONEDIGIWEB Marketing Solution provides digital marketing services including but not limited to:</p>
    <ul>
      <li>Search Engine Optimization (SEO)</li>
      <li>Google Ads / PPC Management</li>
      <li>Social Media Marketing</li>
      <li>Website Development and Design</li>
      <li>Ecommerce Development</li>
      <li>Mobile App Development</li>
      <li>Graphic Design and Branding</li>
      <li>Lead Generation Services</li>
    </ul>

    <h2>3. Client Obligations</h2>
    <p>Clients agree to:</p>
    <ul>
      <li>Provide accurate, complete and up-to-date information required for service delivery</li>
      <li>Make timely payments as per agreed terms and invoices</li>
      <li>Provide necessary access, credentials and approvals for project completion</li>
      <li>Review and approve deliverables within agreed timelines</li>
    </ul>

    <h2>4. Payment Terms</h2>
    <p>Payment terms are outlined in individual service agreements. Generally:</p>
    <ul>
      <li>Monthly services are billed at the beginning of each month</li>
      <li>One-time projects require 50% advance payment before work begins</li>
      <li>Remaining balance is due upon project completion</li>
      <li>Overdue payments may result in service suspension</li>
    </ul>

    <h2>5. Intellectual Property</h2>
    <p>All original content, designs and code created by ONEDIGIWEB for a client project become the client's property upon full payment. ONEDIGIWEB retains the right to showcase completed work in our portfolio unless explicitly restricted in writing.</p>

    <h2>6. Confidentiality</h2>
    <p>Both parties agree to keep confidential any proprietary information shared during the course of service delivery. This includes business data, strategies, and technical information.</p>

    <h2>7. Limitation of Liability</h2>
    <p>ONEDIGIWEB shall not be liable for indirect, incidental, special or consequential damages arising from the use of our services. Our liability is limited to the amount paid by the client for the specific service in question.</p>

    <h2>8. Service Guarantees</h2>
    <p>While we strive to deliver excellent results, specific outcomes such as Google rankings, leads generated or sales conversions cannot be guaranteed due to the dynamic nature of digital platforms. We commit to applying our best expertise and industry-standard practices.</p>

    <h2>9. Termination</h2>
    <p>Either party may terminate ongoing services with 30 days written notice. Upon termination, the client is responsible for payment for all work completed to date. ONEDIGIWEB will provide all deliverables completed up to the termination date.</p>

    <h2>10. Governing Law</h2>
    <p>These Terms and Conditions shall be governed by the laws of India. Any disputes shall be subject to the jurisdiction of courts in India.</p>

    <h2>11. Contact Us</h2>
    <p>For questions about these Terms and Conditions:</p>
    <ul>
      <li><i class="fa-solid fa-envelope" style="color:var(--p2)"></i> Email: <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a></li>
      <li><i class="fa-solid fa-phone" style="color:var(--p2)"></i> Phone: <a href="tel:+918512821525">+91 8512821525</a></li>
      <li><i class="fa-brands fa-whatsapp" style="color:#25D366"></i> WhatsApp: <a href="https://wa.me/918512821525" target="_blank">Chat with Us</a></li>
    </ul>
  </div>
</section>


<?php get_footer(); ?>
