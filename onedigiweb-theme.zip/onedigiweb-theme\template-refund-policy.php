﻿<?php
/**
 * Template Name: Refund Policy
 */
?>
<?php get_header(); ?>


<section class="policy-hero">
  <div class="container">
    <div class="section-pill" style="margin-bottom:16px;">Legal</div>
    <h1>Refund Policy</h1>
    <p>Last Updated: June 24, 2026 &nbsp;&middot;&nbsp; Effective Date: June 24, 2026</p>
  </div>
</section>

<section>
  <div class="container policy-content">
    <p>At <strong>ONEDIGIWEB Marketing Solution</strong>, we are committed to client satisfaction. This Refund Policy explains when and how refunds are processed for our digital marketing and development services.</p>

    <h2>1. Monthly Service Retainers (SEO, Social Media, Google Ads)</h2>
    <p>For ongoing monthly service retainers:</p>
    <ul>
      <li>Monthly fees paid in advance are non-refundable once work has commenced for that month</li>
      <li>Cancellation requests must be submitted at least 15 days before the next billing cycle</li>
      <li>If you cancel before any work has been done for the upcoming month, you may receive a full refund</li>
      <li>Partial month refunds are not provided once services have been delivered</li>
    </ul>

    <h2>2. One-Time Projects (Website Development, App Development, Graphic Design)</h2>
    <p>For one-time project engagements:</p>
    <ul>
      <li><strong>Before project start:</strong> 100% refund of advance payment if cancelled before work begins</li>
      <li><strong>After project start (0-25% complete):</strong> 50% refund of advance payment</li>
      <li><strong>After 25% completion:</strong> No refund is provided as significant work has been invested</li>
      <li>All work completed to date will be delivered to the client upon cancellation</li>
    </ul>

    <h2>3. Google Ads and Meta Ads</h2>
    <p>Please note that advertising budgets paid directly to Google or Meta (Facebook) platforms are:</p>
    <ul>
      <li>Non-refundable by ONEDIGIWEB as they are direct payments to Google/Meta</li>
      <li>Governed by Google's and Meta's own refund policies</li>
      <li>ONEDIGIWEB's management fees are separate and subject to the monthly retainer policy above</li>
    </ul>

    <h2>4. Eligibility for Refund</h2>
    <p>Refunds may be considered in the following circumstances:</p>
    <ul>
      <li>Failure to deliver agreed services within the committed timeline without prior notice</li>
      <li>Technical defects in delivered websites that cannot be resolved within 30 days</li>
      <li>Duplicate payments made by error</li>
    </ul>

    <h2>5. Non-Refundable Items</h2>
    <p>The following are not eligible for refund:</p>
    <ul>
      <li>Domain registration and hosting fees paid to third parties on behalf of the client</li>
      <li>Third-party tool subscriptions or licenses purchased for the project</li>
      <li>Rush delivery fees</li>
      <li>Services already delivered and approved by the client</li>
    </ul>

    <h2>6. Refund Process</h2>
    <p>To request a refund:</p>
    <ul>
      <li>Email your request to <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a> with your project details</li>
      <li>Our team will review your request within 3-5 business days</li>
      <li>If approved, refunds are processed within 7-10 business days to the original payment method</li>
    </ul>

    <h2>7. Contact Us</h2>
    <p>For refund-related queries, please contact us:</p>
    <ul>
      <li><i class="fa-solid fa-envelope" style="color:var(--p2)"></i> Email: <a href="mailto:onedigiweb@gmail.com">onedigiweb@gmail.com</a></li>
      <li><i class="fa-solid fa-phone" style="color:var(--p2)"></i> Phone: <a href="tel:+918512821525">+91 8512821525</a></li>
      <li><i class="fa-brands fa-whatsapp" style="color:#25D366"></i> WhatsApp: <a href="https://wa.me/918512821525" target="_blank">Chat with Us</a></li>
    </ul>
  </div>
</section>


<?php get_footer(); ?>
