﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- ============================================================
       MARKETING INTEGRATIONS (Analytics, AdSense, Pinterest, Ads)
  ============================================================ -->
  <!-- Google Tag (gtag.js) - Google Analytics & Google Ads -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-XXXXXXXXXX'); // Replace with Google Analytics Measurement ID
    gtag('config', 'AW-YYYYYYYYY');  // Replace with Google Ads Conversion ID
  </script>

  <!-- Google AdSense -->
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-ZZZZZZZZZZZZZZZZ" crossorigin="anonymous"></script>

  <!-- Pinterest Tag -->
  <script>
    !function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(Array.prototype.slice.call(arguments))};var n=window.pintrk;n.queue=[],n.version="3.0";var t=document.createElement("script");t.async=!0,t.src=e;var r=document.getElementsByTagName("script")[0];r.parentNode.insertBefore(t,r)}}("https://s.pinterest.com/js/pinit.js");
    pintrk('load', 'PARTNER_ID'); // Replace with Pinterest Partner ID
    pintrk('page');
  </script>
  <noscript>
    <img height="1" width="1" style="display:none;" alt="" src="https://ct.pinterest.com/v3/?event=init&tid=PARTNER_ID&noscript=1" />
  </noscript>
  <!-- ============================================================ -->

  <!-- Primary SEO -->
  
  <meta name="description" content="ONEDIGIWEB Marketing Solution - Best Digital Marketing Agency in India. SEO Services, Google Ads, Social Media Marketing, Website Development, App Development &amp; Lead Generation." />
  <meta name="keywords" content="digital marketing agency India, SEO company India, Google Ads agency, social media marketing, website development company, app development, lead generation, ONEDIGIWEB" />
  <meta name="robots" content="index, follow" />
  <meta name="author" content="ONEDIGIWEB Marketing Solution" />
  <meta name="theme-color" content="#6D28D9" />
  <link rel="canonical" href="https://onedigiweb.com/" />

  <!-- Favicons -->
  <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" />
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-32x32.png" />
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon-16x16.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/apple-touch-icon.png" />
  <link rel="manifest" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/site.webmanifest" />

  <!-- Open Graph -->
  <meta property="og:title" content="ONEDIGIWEB Marketing Solution | Digital Marketing Agency India" />
  <meta property="og:description" content="Best Digital Marketing Agency in India - SEO, Google Ads, Social Media, Website Development &amp; More." />
  <meta property="og:image" content="assets/images/og-image.png" />
  <meta property="og:image:width" content="1200" />
  <meta property="og:image:height" content="630" />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="ONEDIGIWEB Marketing Solution" />
  <meta property="og:locale" content="en_IN" />

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="ONEDIGIWEB Marketing Solution" />
  <meta name="twitter:description" content="Best Digital Marketing Agency in India - SEO, Google Ads, Website Development &amp; More." />
  <meta name="twitter:image" content="assets/images/og-image.png" />

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Font Awesome 6 Pro (Free CDN) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" />

  <!-- Stylesheet -->
  <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>" />

  <!-- Structured Data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "ONEDIGIWEB Marketing Solution",
    "description": "Best Digital Marketing Agency in India offering SEO, Google Ads, Social Media Marketing, Website Development, App Development and Graphic Design.",
    "email": "onedigiweb@gmail.com",
    "telephone": "+918512821525",
    "openingHours": "Mo-Sa 09:00-19:00",
    "priceRange": "Rs.Rs.",
    "image": "assets/images/onedigiweb-marketing-solution-logo.png",
    "address": { "@type": "PostalAddress", "addressCountry": "IN" },
    "sameAs": ["https://wa.me/918512821525"]
  }
  </script>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {"@type":"Question","name":"How long does SEO take?","acceptedAnswer":{"@type":"Answer","text":"Usually 3-6 months for significant results depending on competition and website quality."}},
      {"@type":"Question","name":"Do you provide ongoing support?","acceptedAnswer":{"@type":"Answer","text":"Yes, 24/7 dedicated support via WhatsApp, email and phone for all clients."}},
      {"@type":"Question","name":"Can you redesign my existing website?","acceptedAnswer":{"@type":"Answer","text":"Yes, we offer complete website redesign and development services with modern, mobile-first design."}},
      {"@type":"Question","name":"What is your minimum project budget?","acceptedAnswer":{"@type":"Answer","text":"Our services start from Rs.9,999/month. We offer flexible plans for businesses of all sizes."}}
    ]
  }
  </script>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>



<!-- ============================================================
     HEADER / MEGA NAV
============================================================ -->
<!-- COMPONENT: HEADER -->
<header class="header" id="header">
  <nav class="navbar container">

    <!-- Logo -->
    <a href="index.html" class="logo-link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/onedigiweb-marketing-solution-logo.png" alt="ONEDIGIWEB Marketing Solution Logo" title="ONEDIGIWEB Marketing Solution" width="260" height="74" class="logo-img"></a>

    <!-- Nav Menu -->
    <ul class="nav-menu" id="navMenu" role="menubar">
      <li class="nav-item"><a href="#home" class="nav-link active" role="menuitem">Home</a></li>
      <li class="nav-item has-mega">
        <a href="#services" class="nav-link nav-link-arrow" role="menuitem">Services</a>
                        <div class="mega-menu tabbed-mega-menu" role="menu">
          <div class="mega-inner container">
            
            <!-- Top Category Tabs -->
            <div class="tmm-tabs-container">
              <div class="tmm-tabs">
                <button class="tmm-tab active" data-target="tmm-seo"><i class="fa-solid fa-magnifying-glass"></i> SEO Services</button>
                <button class="tmm-tab" data-target="tmm-dm"><i class="fa-solid fa-bullhorn"></i> Digital Marketing</button>
                <button class="tmm-tab" data-target="tmm-web"><i class="fa-solid fa-code"></i> Website Development</button>
                <button class="tmm-tab" data-target="tmm-app"><i class="fa-solid fa-mobile-screen"></i> App Marketing</button>
                <button class="tmm-tab" data-target="tmm-cm"><i class="fa-solid fa-pen-nib"></i> Content Marketing</button>
                <button class="tmm-tab" data-target="tmm-ppc"><i class="fa-solid fa-mouse-pointer"></i> Google Ads / PPC</button>
                <button class="tmm-tab" data-target="tmm-ar"><i class="fa-solid fa-chart-pie"></i> Analytics & Reporting</button>
                <button class="tmm-tab" data-target="tmm-gd"><i class="fa-solid fa-bezier-curve"></i> Graphic Design</button>
                <button class="tmm-tab" data-target="tmm-sd"><i class="fa-solid fa-laptop-code"></i> Software Development</button>
              </div>
            </div>

            <div class="tmm-body">
              <!-- Left side: Services List -->
              <div class="tmm-content-area">
                
                <!-- SEO -->
                <div class="tmm-content active" id="tmm-seo">
                  <div class="tmm-links-grid">
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>SEO Services</span></a>
                    <a href="local-seo-services.html" class="tmm-link"><i class="fa-solid fa-map-location-dot"></i><span>Local SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-gears"></i><span>Technical SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-cart-arrow-down"></i><span>Ecommerce SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Enterprise SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-robot"></i><span>AI SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-stethoscope"></i><span>SEO audit</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-link"></i><span>Link Building</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-triangle-exclamation"></i><span>Google Penalty Recovery</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-truck-fast"></i><span>SEO Migration</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-language"></i><span>Multilingual SEO</span></a>
                    <a href="seo-services.html" class="tmm-link"><i class="fa-solid fa-globe"></i><span>International SEO</span></a>
                  </div>
                </div>

                <!-- Digital Marketing -->
                <div class="tmm-content" id="tmm-dm">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-brands fa-google"></i><span>Google Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-meta"></i><span>Meta Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-youtube"></i><span>YouTube Ads</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-instagram"></i><span>Instagram Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-facebook"></i><span>Facebook Marketing</span></a>
                    <a href="social-media-marketing.html" class="tmm-link"><i class="fa-brands fa-linkedin"></i><span>LinkedIn Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope-open-text"></i><span>Email Marketing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-bullhorn"></i><span>Content Marketing</span></a>
                    <a href="lead-generation-services.html" class="tmm-link"><i class="fa-solid fa-magnet"></i><span>Lead Generation</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-shield-halved"></i><span>Online Reputation Management</span></a>
                  </div>
                </div>

                <!-- Website Development -->
                <div class="tmm-content" id="tmm-web">
                  <div class="tmm-links-grid">
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building"></i><span>Business Website</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-building-user"></i><span>Corporate Website</span></a>
                    <a href="wordpress-development.html" class="tmm-link"><i class="fa-brands fa-wordpress"></i><span>WordPress</span></a>
                    <a href="ecommerce-development.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Ecommerce Website</span></a>
                    <a href="shopify-development.html" class="tmm-link"><i class="fa-brands fa-shopify"></i><span>Shopify</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-react"></i><span>React</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-n"></i><span>Next.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-laravel"></i><span>Laravel</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-php"></i><span>Custom PHP</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-brands fa-node-js"></i><span>Node.js</span></a>
                    <a href="website-development.html" class="tmm-link"><i class="fa-solid fa-screwdriver-wrench"></i><span>Website Maintenance</span></a>
                  </div>
                </div>

                <!-- App Marketing -->
                <div class="tmm-content" id="tmm-app">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>App Store Optimization</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-download"></i><span>App Install Campaigns</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-star"></i><span>App Reviews & Ratings</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-chart-line"></i><span>App Analytics</span></a>
                  </div>
                </div>

                <!-- Content Marketing -->
                <div class="tmm-content" id="tmm-cm">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-pen-fancy"></i><span>Blog Writing</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-file-lines"></i><span>Copywriting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-video"></i><span>Video Scripting</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-envelope"></i><span>Newsletter Writing</span></a>
                  </div>
                </div>

                <!-- Google Ads / PPC -->
                <div class="tmm-content" id="tmm-ppc">
                  <div class="tmm-links-grid">
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-dollar"></i><span>Search Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Display Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-cart-shopping"></i><span>Shopping Ads</span></a>
                    <a href="google-ads-services.html" class="tmm-link"><i class="fa-solid fa-rotate-left"></i><span>Remarketing</span></a>
                  </div>
                </div>

                <!-- Analytics & Reporting -->
                <div class="tmm-content" id="tmm-ar">
                  <div class="tmm-links-grid">
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-pie"></i><span>Google Analytics 4</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-chart-column"></i><span>Custom Dashboards</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-filter"></i><span>Conversion Tracking</span></a>
                    <a href="digital-marketing-services.html" class="tmm-link"><i class="fa-solid fa-magnifying-glass-chart"></i><span>Data Audits</span></a>
                  </div>
                </div>

                <!-- Graphic Design -->
                <div class="tmm-content" id="tmm-gd">
                  <div class="tmm-links-grid">
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-bezier-curve"></i><span>Logo Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-award"></i><span>Brand Identity</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-object-group"></i><span>UI/UX Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-image"></i><span>Social Media Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-rectangle-list"></i><span>Banner Design</span></a>
                    <a href="graphic-design-services.html" class="tmm-link"><i class="fa-solid fa-book-open"></i><span>Brochure Design</span></a>
                  </div>
                </div>

                <!-- Software Development -->
                <div class="tmm-content" id="tmm-sd">
                  <div class="tmm-links-grid">
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-laptop-code"></i><span>Custom Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-users-gear"></i><span>CRM Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-network-wired"></i><span>ERP Software</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-android"></i><span>Android App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-brands fa-apple"></i><span>iOS App</span></a>
                    <a href="app-development.html" class="tmm-link"><i class="fa-solid fa-mobile-screen"></i><span>Flutter App</span></a>
                  </div>
                </div>
              </div>

              <!-- Right Side CTA Card -->
              <div class="tmm-cta">
                <div class="tmm-cta-card">
                  <div class="tmm-cta-title">Grow Your Business with ONEDIGIWEB</div>
                  <div class="tmm-cta-bullets">
                    <span><i class="fa-solid fa-check"></i> Free Consultation</span>
                    <span><i class="fa-solid fa-check"></i> Expert Team</span>
                    <span><i class="fa-solid fa-check"></i> Custom Strategy</span>
                    <span><i class="fa-solid fa-check"></i> Transparent Pricing</span>
                  </div>
                  <div class="tmm-cta-actions">
                    <button class="btn btn-tmm-quote open-quote-trigger" onclick="document.getElementById('quotePopup').style.display='flex'">Get Free Quote</button>
                    <a href="https://wa.me/918512821525" class="btn btn-tmm-wa" target="_blank"><i class="fa-brands fa-whatsapp"></i> WhatsApp Now</a>
                  </div>
                  <div class="tmm-cta-footer"><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 100+ Projects</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> 24x7 Support</span><span><i class="fa-solid fa-star" style="color:#FBBF24"></i> Fast Delivery</span></div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </li>
      <li class="nav-item"><a href="#pricing" class="nav-link" role="menuitem">Pricing</a></li>
      <li class="nav-item"><a href="#portfolio" class="nav-link" role="menuitem">Portfolio</a></li>
      <li class="nav-item"><a href="#contact" class="nav-link" role="menuitem">Contact</a></li>
    </ul>

    <!-- Nav CTA -->
    <div class="nav-cta">
      <a href="tel:+918512821525" class="nav-cta-call">
        <i class="fa-solid fa-phone"></i> +91 8512821525
      </a>
      <a href="https://wa.me/918512821525?text=Hi%20ONEDIGIWEB!%20I%20need%20a%20free%20consultation." target="_blank" class="nav-cta-wa">
        <i class="fa-brands fa-whatsapp"></i> WhatsApp
      </a>
      <button class="nav-cta-quote open-quote-trigger">
        <i class="fa-solid fa-rocket"></i> Free Consultation
      </button>
    </div>

    <!-- Hamburger -->
    <button class="hamburger" id="hamburger" aria-label="Toggle Menu" aria-expanded="false">
      <span class="ham-line"></span>
      <span class="ham-line"></span>
      <span class="ham-line"></span>
    </button>
  </nav>
</header>

<!-- END COMPONENT: HEADER -->
